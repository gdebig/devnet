<?php 

return [
    'announcement'                         => 'Pengumuman',
    'success_register' => 'Berhasil melakukan pendaftaran, silahkan lakukan aktivasi dengan email anda',
    'process'   => 'Proses',
    'success_verification' => 'Berhasil menyimpan data verifikasi, silahkan tunggu respon dari admin',
    'next' => 'Selanjutnya',
    'previous' => 'Sebelumnya'
];

?>