<?php

return [
    'site_title' => 'LDO UI',
];
