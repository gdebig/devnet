<?php

return [
    'password' => 'Kata sandi minimal harus memiliki enam karakter dan cocok dengan konfirmasi.',
    'reset'    => 'Kata sandi anda sudah direset!',
    'sent'     => 'Kami sudah mengirim surel yang berisi tautan untuk mereset kata sandi Anda!',
    'token'    => 'Token pengaturan ulang kata sandi tidak sah.',
    'user'     => 'Kami tidak dapat menemukan pengguna dengan alamat surel tersebut.',
    'updated'  => 'Password anda sudah di ubah',
];
