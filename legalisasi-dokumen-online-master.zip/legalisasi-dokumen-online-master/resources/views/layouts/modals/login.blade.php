<div class="modal fade" id="loginModal" tabindex="-99" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content ">
        <div class="modal-body text-center" style="padding: 3rem 2rem">
            <h4 class="bold">Apakah Anda Mahasiswa atau Alumni?</h4>
            <br>
            <h5>Sebelum membuat pesanan legalisasi dokumen silahkan pilih status anda</h5>
            <br>
            <div class="row">
              <div class="col-md-6" style="padding-bottom: 1rem;">
                <a class="" href="{{ route('login') }}" style="padding: 0 0.5rem;">
                    <img src="{{asset('images/btn-login-alumni.svg')}}">
                </a>
              </div>
              <div class="col-md-6">
                <a class="" href="{{ route('ssoLogin') }}" style="padding: 0 0.5rem;">
                    <img src="{{asset('images/btn-login-student.svg')}}">
                </a>
              </div>
            </div>
        </div>
      </div>
    </div>
</div>