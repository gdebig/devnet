<div class="modal fade" id="registerModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content ">
        <div class="modal-body text-center" style="padding: 3rem 2rem">
            <h4 class="bold">Apakah Anda Mahasiswa atau Alumni?</h4>
            <br>
            <h5>Sebelum melakukan registrasi silahkan pilih status anda</h5>
            <br>
            <a class="" href="#" style="padding: 0 0.5rem;">
                <img src="{{asset('images/btn-login-alumni.svg')}}">
            </a>
            <a class="" href="#" style="padding: 0 0.5rem;">
                <img src="{{asset('images/btn-login-student.svg')}}">
            </a>
        </div>
      </div>
    </div>
</div>