@extends('layouts.userApp')
@section('content')
<div class="col-md-12">
    <div class="row justify-content-center" style="padding-top: 100px; min-height: 93vh">
        <div class="col-lg-4">
            <h1 class="text-center bold" style="padding-bottom: 2rem;">Login Alumni</h1>
            <div class="card card-borderless">
                <div class="card-body">
                    {{-- <p class="text-muted">{{ trans('global.login') }}</p> --}}
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @if(session('message'))
                        <div class="alert alert-info" role="alert">
                            {{ session('message') }}
                        </div>
                    @endif
                    @if(session('error'))
                        <div class="alert alert-danger" role="alert">
                            {{ session('error') }}
                        </div>
                    @endif
                    

                    <form method="POST" action="{{ route('login') }}">
                        @csrf
                        <div class="form-group">
                            <label class="form-label caps">{{ trans('cruds.user.fields.student_number') }}</label>
                            <div class="input-group mb-3">
                                <input id="student_number" name="student_number" type="text" class="form-control-lg form-control {{ $errors->has('student_number') ? ' is-invalid' : '' }}" required autocomplete="email" autofocus placeholder="{{ trans('cruds.user.fields.student_number') }}" value="{{ old('student_number', null) }}">
                                @if($errors->has('student_number'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('student_number') }}
                                    </div>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label caps">Password</label>
                            <div class="input-group mb-3">
                                <input id="password" name="password" type="password" class="form-control-lg form-control {{ $errors->has('password') ? ' is-invalid' : '' }}" required placeholder="{{ trans('global.login_password') }}">

                                @if($errors->has('password'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('password') }}
                                    </div>
                                @endif
                            </div>
                        </div>

                        <div class="input-group mb-4">
                            <div class="form-check checkbox">
                                <input class="form-check-input" name="remember" type="checkbox" id="remember" style="vertical-align: middle;" />
                                <label class="form-check-label" for="remember" style="vertical-align: middle;">
                                    {{ trans('global.remember_me') }}
                                </label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6 offset-6 text-right">
                                @if(Route::has('password.request'))
                                    <a class="btn btn-link px-0 bold" href="{{ route('password.request') }}">
                                        {{ trans('global.forgot_password') }}
                                    </a><br>
                                @endif
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-orange px-4 btn-block btn-lg caps bold">
                                    {{ trans('global.login') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection