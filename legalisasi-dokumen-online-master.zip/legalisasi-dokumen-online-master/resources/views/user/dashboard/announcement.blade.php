<div class="card">
    <div class="card-header bg-white">
        <h3 class="text-blue">
            {{ trans('user.announcement') }}
        </h3>
    </div>
    <div class="card-body announcement-body {{ isset($all) && $all === true ? 'announcement-body-all' : ''}}">
        @if(isset($announcements))
            @foreach($announcements as $announcement)
                <div class="card announcement-item">
                    <div class="card-body">
                        <span class="text-grey">{{$announcement->publish_date}}</span>
                        <br>
                        <span class="bold">{{$announcement->title}}</span>
                        <p>{!! $announcement->content !!}
                        </p>
                    </div>
                </div>
            @endforeach
        @else
            <div style="text-align: center; padding-top: 20%">
                <i class="fas fa-bullhorn fa-4x text-orange"></i>
                <br>&nbsp;
                <h6 class="bold"> Belum ada pengumuman </h6>

            </div>
        @endif
    </div>
    @if(!isset($all) || $all !== true)
        <div class="card-footer bg-white">
            <div class="pull-right">
                <a href="{{ route('announcement') }}" class="text-orange">
                    Lihat semua
                </a>
            </div>
        </div>
    @endif
</div>