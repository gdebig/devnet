<div class="c-app flex-row align-items-center" style="background-color: #172b4d; padding: 2rem 0">
    <div class="container">
        <div class="row">
            <div class="col-md-12" style="padding-bottom: 1rem">
                <h3 class="text-orange bolder">Alur Pemesanan</h3>
            </div>
            <div class="col-md-12">
                <div class="row flow">
                    <div class="flow-item">
                        <div class="flow-body">
                            <img class="flow-icon" src="{{asset('images/ic-flow-1.svg')}}">
                            <h6 class="text-white bolder">Buka Website Legalisir Online</h6>
                        </div>
                        <div class="flow-nav">
                            <i class="fas fa-chevron-right fa-2x text-white"></i>
                        </div>
                    </div>
                    <div class="flow-item">
                        <div class="flow-body">
                            <img class="flow-icon" src="{{asset('images/ic-flow-2.svg')}}">
                            <h6 class="text-white bolder">Klik button buat pesanan</h6>
                        </div>
                        <div class="flow-nav">
                            <i class="fas fa-chevron-right fa-2x text-white"></i>
                        </div>
                    </div>
                    <div class="flow-item">
                        <div class="flow-body">
                            <img class="flow-icon" src="{{asset('images/ic-flow-3.svg')}}">
                            <h6 class="text-white bolder">Isi form data diri</h6>
                        </div>
                        <div class="flow-nav">
                            <i class="fas fa-chevron-right fa-2x text-white"></i>
                        </div>
                    </div>
                    <div class="flow-item">
                        <div class="flow-body">
                            <img class="flow-icon" src="{{asset('images/ic-flow-4.svg')}}">
                            <h6 class="text-white bolder">Upload dokumen</h6>
                        </div>
                        <div class="flow-nav">
                            <i class="fas fa-chevron-right fa-2x text-white"></i>
                        </div>
                    </div>
                    <div class="flow-item">
                        <div class="flow-body">
                            <img class="flow-icon" src="{{asset('images/ic-flow-5.svg')}}">
                            <h6 class="text-white bolder">Bayar biaya legalisir</h6>
                        </div>
                        <div class="flow-nav">
                            <i class="fas fa-chevron-right fa-2x text-white"></i>
                        </div>
                    </div>
                    <div class="flow-item">
                        <div class="flow-body">
                            <img class="flow-icon" src="{{asset('images/ic-flow-6.svg')}}">
                            <h6 class="text-white bolder">Dokumen diantar ke rumah atau ambil ke FT UI</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>