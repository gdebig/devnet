<a target="_blank" class="btn btn-rounded btn-wa" 
   href={{"https://wa.me/".$number."?text=".$message}}>
    <i class="fa fa-whatsapp fa-2x"></i>
</a>