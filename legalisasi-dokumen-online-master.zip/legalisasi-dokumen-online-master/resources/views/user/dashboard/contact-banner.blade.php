<div class="c-app flex-row align-items-center" style="background-color: #fff; padding: 5rem 0">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h3 class="text-blue bolder">Kontak</h3>
                {{-- <h4 style="width: 80%">Kirimkan pertanyaanan anda mengenai legalisasi online kepada kami</h4> --}}
                <br>
                <div style="width: 70%">
                    <h5 class="bold">Pusat Administrasi Fakultas Teknik Universitas Indonesia</h5>
                    <h6>Alamat : Gedung GK Lantai 1 Fakultas Teknik UI</h6>
                    <h6>Email: paf@eng.ui.ac.id</h6>
                    <h6>Telepon : 6221-78887861</h6>
                    <h6>Faksimili : 6221-7863507</h6>
                    <h6>Hari Senin s.d Jumat : 08:00 - 16:00</h6>
                </div>
            </div>
            <div class="col-md-6">
                {{-- contact form --}}
                
            </div>
        </div>
    </div>
</div>