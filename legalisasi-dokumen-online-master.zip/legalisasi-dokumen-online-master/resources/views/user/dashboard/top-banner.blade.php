<div class="c-app flex-row align-items-center bg-home" style="background-image: url({{asset('images/bg-hero-home.jpg')}}); background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div style="">
                    <h1 class="bolder text-blue">
                        PAF FTUI Online
                    </h1>
                    <h4 style="width: 85%">
                        Kemudahan layanan dokumen via online
                    </h4>
                    <div class="row" style="padding-top: 5vh; padding-bottom: 10vh">
                        <div class="col-md-8">
                            <a href="#" class="btn btn-lg btn-block btn-orange" data-toggle="modal" data-target="#loginModal" data-action="createOrder">
                                <i class="fas fa-plus-circle"></i> Buat Pesanan
                            </a>
                        </div>
                        <div class="col-md-12" style="padding-top: 1.5rem">
                            <a href="#" class="text-orange" data-toggle="modal" data-target="#termModal">
                                Syarat dan Ketentuan
                            </a>
                            <span class="text-orange" style="margin: 0 1rem;">|</span>
                            <a href="#" class="text-orange" data-toggle="modal" data-target="#paymentGuideModal">
                                Petunjuk Pembayaran
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6" style="padding-bottom: 10vh">
                @include('user.dashboard.announcement', ['announcements' => App\Announcement::published()->latest()->limit(10)->get()])
            </div>
        </div>
    </div>
</div>