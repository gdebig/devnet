<ol>
    <li style="font-weight: 400;"><span style="font-weight: 400;">Dalam rangka meningkatkan pelayanan baik untuk mahasiswa maupun alumni Fakultas Teknik Universitas Indonesia, Pusat Administrasi Fakultas Teknik Universitas Indonesia (PAF FTUI) terhitung mulai tanggal 12 Oktober 2020 membuka pelayanan pemesanan legalisir ijazah, transkrip, dan berkas lainnya melalui PAF Online yang beralamat di </span><a href="http://paf.eng.ui.ac.id"><span style="font-weight: 400;">http://paf.eng.ui.ac.id</span></a><span style="font-weight: 400;">&nbsp;</span></li>
    <li style="font-weight: 400;"><span style="font-weight: 400;">Pelayanan dilakukan pada hari kerja dari Senin s.d Jum&rsquo;at pukul 08.00 hingga 16.00 WIB.</span></li>
    <li style="font-weight: 400;"><span style="font-weight: 400;">Pengguna yang dapat menggunakan PAF Online adalah mahasiswa aktif dan alumni Fakultas Teknik Universitas Indonesia.</span></li>
    <li style="font-weight: 400;"><span style="font-weight: 400;">Setiap pengguna yang ingin melakukan pemesanan dokumen legalisir harus melakukan registrasi. Untuk alumni wajib melakukan verifikasi data menggunakan scan ijazah dan transkrip nilai asli.</span></li>
    <li style="font-weight: 400;"><span style="font-weight: 400;">Setiap pemesanan dokumen legalisir harus memperhatikan Syarat dan ketentuan sbb :</span></li>
    <ol style="list-style-type: lower-alpha">
        <li style="font-weight: 400;"><span style="font-weight: 400;">Mengisi data pemesanan dengan benar dan jelas terutama alamat pengiriman jika menghendaki hasil pemesanan dokumen dikirimkan. PAF FTUI tidak bertanggungjawab jika dokumen yang dikirimkan tidak sampai karena kesalahan penulisan alamat / kurang jelas.</span></li>
        <li style="font-weight: 400;"><span style="font-weight: 400;">Melakukan pembayaran sesuai dengan jumlah yang ditagihkan</span></li>
        <li style="font-weight: 400;"><span style="font-weight: 400;">Memantau pesanan melalui website PAF Online dan email secara berkala</span></li>
    </ol>
</ol>
<p><span style="font-weight: 400;">Informasi lebih lanjut mengenai pelayanan ini dapat menghubungi PAF FTUI melalui:</span></p>
<div style="padding-left:1rem">
<p><span style="font-weight: 400;">Email: paf@eng.ui.ac.id</span></p>
<p><span style="font-weight: 400;">Telepon : 6221-78887861</span></p>
<p><span style="font-weight: 400;">Faksimili : 6221-7863507</span></p>
<p><span style="font-weight: 400;">Whatsapp: 0811-1707-1964</span></p>
</div>
<small><span style="font-weight: 400;">* Catatan: Syarat dan Ketentuan dapat berubah sewaktu-waktu.</span></small>