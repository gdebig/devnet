<ol style="margin-left:-1rem;">
    <div class="row">
        <div class="col-md-6">
            <img style="width:100%" src="{{asset('images/img-payment-guide-1.jpeg')}}">
        </div>
        <div class="col-md-6">
            <img style="width:100%" src="{{asset('images/img-payment-guide-2.jpeg')}}">
        </div>
    </div>
    <li style="font-weight: 400;"><span style="font-weight: 400;">PAF Online FTUI menggunakan Midtrans sebagai sistem pembayaran.</span></li>
    <br>
    <li style="font-weight: 400;"><span style="font-weight: 400;">Adapun metode pembayaran yang bisa dipilih adalah:</span></li>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <img style="width:100%" src="{{asset('images/img-payment-guide-3.jpeg')}}">
        </div>
    </div>
    <ol style="list-style-type: lower-alpha">
        <li style="font-weight: 400;"><span style="font-weight: 400;">ATM/Bank Transfer</span></li>
        <ol style="list-style-type: lower-roman">
            <li style="font-weight: 400;"><span style="font-weight: 400;">BNI Virtual Account (menu )</span></li>
            <li style="font-weight: 400;"><span style="font-weight: 400;">BRI Virtual Account (menu ATM/Bank Transfer)</span></li>
            <li style="font-weight: 400;"><span style="font-weight: 400;">BCA Virtual Account (menu ATM/Bank Transfer)</span></li>
            <li style="font-weight: 400;"><span style="font-weight: 400;">Mandiri Bill Payment (menu ATM/Bank Transfer)</span></li>
            <li style="font-weight: 400;"><span style="font-weight: 400;">Permata Virtual Account (menu ATM/Bank Transfer)</span></li>
        </ol>
        <li style="font-weight: 400;"><span style="font-weight: 400;">Gopay</span></li>
        <li style="font-weight: 400;"><span style="font-weight: 400;">QRIS</span></li>
    </ol>
    <br>
    <li style="font-weight: 400;"><span style="font-weight: 400;">Ikuti petunjuk pembayaran sesuai dengan petunjuk yang diarahkan oleh Midtrans.</span></li>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <img style="width:100%" src="{{asset('images/img-payment-guide-4.jpeg')}}">
        </div>
    </div>
    <br>
    <li style="font-weight: 400;"><span style="font-weight: 400;">Jika pembayaran telah selesai dilakukan, maka pesanan akan segera diproses oleh admin PAF Online.</span></li>
</ol>