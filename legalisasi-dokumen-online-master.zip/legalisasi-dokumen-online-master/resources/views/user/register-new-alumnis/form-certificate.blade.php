@extends('user.register-new-alumnis.layout')
@section('form')
    <form method="POST" action="{{ route('register-new-alumni.certificate.create') }}">
        @csrf
        <div class="form-group">
            <label class="required caps" for="name">{{ trans('cruds.user.fields.name') }}</label>
            <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" value="{{ old('name', $register->name ?? '') }}" required>
            @if($errors->has('name'))
                <div class="invalid-feedback">
                    {{ $errors->first('name') }}
                </div>
            @endif
        </div>

        <div class="form-group">
            <label class="required caps" for="student_number">{{ trans('cruds.user.fields.student_number') }}</label>
            <input class="form-control {{ $errors->has('student_number') ? 'is-invalid' : '' }}" type="text" name="student_number" id="student_number" value="{{ old('student_number', $register->student_number ?? '') }}" disabled>
            @if($errors->has('student_number'))
                <div class="invalid-feedback">
                    {{ $errors->first('student_number') }}
                </div>
            @endif
        </div>

        <div class="form-group">
            <label class="caps" for="study_program">{{ trans('cruds.user.fields.study_program') }}</label>
            <select name="study_program" id="study_program" class="form-control select2">
                {{-- <option value selected>{{ trans('cruds.order.fields.study_program') }}</option> --}}
                @foreach($studyPrograms as $key => $label)
                    <option value="{{ $label }}" {{ isset($register->study_program) && $register->study_program === $label ? 'selected' : ''}}>{{ $label }}</option>
                @endforeach
            </select>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps">{{ trans('cruds.user.fields.city_of_birth') }}</label>
                    <input id="city_of_birth" name="city_of_birth" type="text" class="form-control {{ $errors->has('city_of_birth') ? ' is-invalid' : '' }}" required placeholder="{{ trans('cruds.user.fields.city_of_birth') }}" value="{{ old('city_of_birth', $register->city_of_birth ?? '')}}">
                    @if($errors->has('city_of_birth'))
                        <div class="invalid-feedback">
                            {{ $errors->first('city_of_birth') }}
                        </div>
                    @endif
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps" for="date_of_birth">{{ trans('cruds.user.fields.date_of_birth') }}</label>
                    <input class="form-control date {{ $errors->has('date_of_birth') ? 'is-invalid' : '' }}" type="text" name="date_of_birth" id="date_of_birth" value="{{ old('date_of_birth', $register->date_of_birth ?? '') }}" required>
                    @if($errors->has('date_of_birth'))
                        <div class="invalid-feedback">
                            {{ $errors->first('date_of_birth') }}
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps">{{ trans('cruds.user.fields.graduated_date') }}</label>
                    <input id="graduated_date" name="graduated_date" type="text" class="form-control date {{ $errors->has('graduated_date') ? ' is-invalid' : '' }}" required placeholder="{{ trans('cruds.user.fields.graduated_date') }}" value="{{ old('graduated_date', $register->graduated_date ?? '')}}">
                    @if($errors->has('graduated_date'))
                        <div class="invalid-feedback">
                            {{ $errors->first('graduated_date') }}
                        </div>
                    @endif
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps" for="certificate_printed_number">{{ trans('cruds.user.fields.certificate_printed_number') }}</label>
                    <input class="form-control {{ $errors->has('certificate_printed_number') ? 'is-invalid' : '' }}" type="text" name="certificate_printed_number" id="certificate_printed_number" value="{{ old('certificate_printed_number', $register->certificate_printed_number ?? '') }}" required>
                    @if($errors->has('certificate_printed_number'))
                        <div class="invalid-feedback">
                            {{ $errors->first('certificate_printed_number') }}
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps">{{ trans('cruds.user.fields.certificate_number') }}</label>
                    <input id="certificate_number" name="certificate_number" type="text" class="form-control {{ $errors->has('certificate_number') ? ' is-invalid' : '' }}" placeholder="{{ trans('cruds.user.fields.certificate_number') }}" value="{{ old('certificate_number', $register->certificate_number ?? '')}}">
                    @if($errors->has('certificate_number'))
                        <div class="invalid-feedback">
                            {{ $errors->first('certificate_number') }}
                        </div>
                    @endif
                    <span class="help-block">
                        <i class="fas fa-exclamation-circle text-orange px-1"></i>Klik 
                        <a href="#" class="text-orange" data-target="#infoCertificateFileModal" data-toggle="modal">di sini</a> 
                        untuk melihat contoh nomor ijazah
                    </span>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps" for="certificate_degree">{{ trans('cruds.user.fields.certificate_degree') }}</label>
                    <input class="form-control {{ $errors->has('certificate_degree') ? 'is-invalid' : '' }}" type="text" name="certificate_degree" id="certificate_degree" value="{{ old('certificate_degree', $register->certificate_degree ?? '') }}" required placeholder="{{ trans('cruds.user.fields.certificate_degree') }}">
                    @if($errors->has('certificate_degree'))
                        <div class="invalid-feedback">
                            {{ $errors->first('certificate_degree') }}
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="certificate_file" class="required caps">{{ trans('cruds.user.fields.certificate_file') }}</label>
            <div class="needsclick dropzone {{ $errors->has('certificate_file') ? 'is-invalid' : '' }}" id="certificate_file-dropzone">
            </div>
            <span class="help-block">
                Jenis file yang diperbolehkan untuk upload (image : jpg, png, pdf)
            </span>
            @if($errors->has('certificate_file'))
                <div class="invalid-feedback">
                    {{ $errors->first('certificate_file') }}
                </div>
            @endif
        </div>

        <div class="row">
            <div class="col-6" style="padding-top: 1rem;">
                <a class="btn btn-outline-primary btn-block caps bold" href="{{route('register-new-alumni.account')}}">
                    {{ trans('user.previous') }}
                </a>
            </div>
            <div class="col-6" style="padding-top: 1rem;">
                <button type="submit" class="btn btn-orange btn-block caps bold">
                    {{ trans('user.next') }}
                </button>
            </div>
        </div>
    </form>
@include('user.verifications.modals.info-file', ['url' => 'images/img-certificate-file.svg', 'id' => 'infoCertificateFileModal'])
@endsection