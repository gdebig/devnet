@extends('user.register-new-alumnis.layout')
@section('form')
    <form method="POST" action="{{ route('register-new-alumni.transcript.create') }}">
        @csrf
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps">{{ trans('cruds.user.fields.transcript_number') }}</label>
                    <input id="transcript_number" name="transcript_number" type="text" class="form-control {{ $errors->has('transcript_number') ? ' is-invalid' : '' }}" placeholder="{{ trans('cruds.user.fields.transcript_number') }}" value="{{ old('transcript_number', $register->transcript_number ?? '')}}">
                    @if($errors->has('transcript_number'))
                        <div class="invalid-feedback">
                            {{ $errors->first('transcript_number') }}
                        </div>
                    @endif
                    <span class="help-block">
                        <i class="fas fa-exclamation-circle text-orange px-1"></i>
                        Klik 
                        <a href="#" class="text-orange" data-target="#infoTranscriptFileModal" data-toggle="modal">di sini</a> 
                        untuk melihat contoh nomor transkrip
                    </span>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps" for="gpa">{{ trans('cruds.user.fields.gpa') }}</label>
                    <input class="form-control {{ $errors->has('gpa') ? 'is-invalid' : '' }}" type="number" name="gpa" id="gpa" value="{{ old('gpa', $register->gpa ?? '') }}" required placeholder="3.50" step=".01" max="4">
                    @if($errors->has('gpa'))
                        <div class="invalid-feedback">
                            {{ $errors->first('gpa') }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="is_graduated" class="caps">{{ trans('cruds.user.fields.is_graduated') }}</label>
            <br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="is_graduated" id="is_graduated_true" value="1" {{ old('is_graduated') ? 'checked' : 'false' }}>
                <label class="form-check-label" for="is_graduated_true">
                    Lulus
                </label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="is_graduated" id="is_graduated_false" value="0" {{ !old('is_graduated') ? 'checked' : 'false' }}>
                <label class="form-check-label" for="is_graduated_false">
                    Tidak Lulus
                </label>
            </div>
            @if($errors->has('is_graduated'))
                <div class="invalid-feedback">
                    {{ $errors->first('is_graduated') }}
                </div>
            @endif
        </div>
        <div class="form-group">
            <label for="thesis_title" class="caps">{{ trans('cruds.user.fields.thesis_title') }}</label>
            <input class="form-control {{ $errors->has('thesis_title') ? 'is-invalid' : '' }}" type="text" name="thesis_title" id="thesis_title" value="{{ old('thesis_title', $register->thesis_title ?? '') }}" required placeholder="{{ trans('cruds.user.fields.thesis_title') }}">
            @if($errors->has('thesis_title'))
                <div class="invalid-feedback">
                    {{ $errors->first('thesis_title') }}
                </div>
            @endif
        </div>
        <div class="form-group">
            <label class="required caps" for="thesis_title_en">{{ trans('cruds.user.fields.thesis_title_en') }}</label>
            <input class="form-control {{ $errors->has('thesis_title_en') ? 'is-invalid' : '' }}" type="text" name="thesis_title_en" id="thesis_title_en" value="{{ old('thesis_title_en', $register->thesis_title_en ?? '') }}" required placeholder="{{ trans('cruds.user.fields.thesis_title_en') }}">
            @if($errors->has('thesis_title_en'))
                <div class="invalid-feedback">
                    {{ $errors->first('thesis_title_en') }}
                </div>
            @endif
        </div>

        <div class="form-group">
            <label class="required caps" for="transcript_file">{{ trans('cruds.user.fields.transcript_file') }}</label>
            <div class="needsclick dropzone {{ $errors->has('transcript_file') ? 'is-invalid' : '' }}" id="transcript_file-dropzone">
            </div>
            <span class="help-block">
                Jenis file yang diperbolehkan untuk upload (image : jpg, png, pdf)
            </span>
            @if($errors->has('transcript_file'))
                <div class="invalid-feedback">
                    {{ $errors->first('transcript_file') }}
                </div>
            @endif
        </div>
        <hr>
        <div class="form-group">
            <label for="signature_image" class="required caps">{{ trans('cruds.user.fields.signature_image') }}</label>
            <div class="text-center {{ $errors->has('signature_image') ? 'is-invalid' : '' }}" id="signature_pad">
                <section id="savedSignature">
                    <img src="" id="signature_preview" style="border: solid 1px #000;">
                    <input type="hidden" name="signature_image" id="signature_image">
                    <br>
                    <button class="btn btn-orange btn-sm" type="button" id="createSignature">
                        Ubah
                    </button>
                </section>
                <section id="canvasSignature" style="display: none;">
                    <canvas style="border: solid 1px #000;">
                    </canvas>
                    <br>
                    <div class="col">
                        <button class="btn btn-danger btn-sm" type="button" id="clearSignature">
                            Hapus
                        </button>
                        <button class="btn btn-orange btn-sm" type="button" id="saveSignature">
                            Simpan
                        </button>
                    </div>
                </section>
            </div>
            @if($errors->has('signature_image'))
                <div class="invalid-feedback">
                    {{ $errors->first('signature_image') }}
                </div>
            @endif
        </div>


        <div class="row">
            <div class="col-6" style="padding-top: 1rem;">
                <a class="btn btn-outline-primary btn-block caps bold" href="{{route('register-new-alumni.certificate')}}">
                    {{ trans('user.previous') }}
                </a>
            </div>
            <div class="col-6" style="padding-top: 1rem;">
                <button type="submit" class="btn btn-orange btn-block caps bold">
                    {{ trans('user.process') }}
                </button>
            </div>
        </div>
    </form>
@include('user.verifications.modals.info-file', ['url' => 'images/img-transcript-file.svg', 'id' => 'infoTranscriptFileModal'])
@endsection