@extends('user.register-new-alumnis.layout')
@section('form')
    <form method="POST" action="{{ route('register-new-alumni.account.create') }}">
        @csrf
        <div class="form-group">
            <label class="required" for="student_number">{{ trans('cruds.user.fields.student_number') }}</label>
            <input class="form-control {{ $errors->has('student_number') ? 'is-invalid' : '' }}" type="text" name="student_number" id="student_number" value="{{ old('student_number', $register->student_number ?? '') }}" required>
            @if($errors->has('student_number'))
                <div class="invalid-feedback">
                    {{ $errors->first('student_number') }}
                </div>
            @endif
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps">{{ trans('cruds.user.fields.email') }}</label>
                    <input id="email" name="email" type="email" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" required placeholder="{{ trans('cruds.user.fields.email') }}" value="{{ old('email', $register->email ?? '')}}">
                    @if($errors->has('email'))
                        <div class="invalid-feedback">
                            {{ $errors->first('email') }}
                        </div>
                    @endif
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps" for="phone_number">{{ trans('cruds.user.fields.phone_number') }}</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white">
                                +62
                            </span>
                        </div>
                        <input class="form-control {{ $errors->has('phone_number') ? 'is-invalid' : '' }}" type="number" name="phone_number" id="phone_number" value="{{ old('phone_number', $register->phone_number ?? '') }}" required>
                        @if($errors->has('phone_number'))
                            <div class="invalid-feedback">
                                {{ $errors->first('phone_number') }}
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="required caps">{{ trans('cruds.user.fields.password') }}</label>
            <div class="input-group mb-3">
                <input id="password" name="password" type="password" class="form-control append-right-borderless {{ $errors->has('password') ? ' is-invalid' : '' }}" required placeholder="{{ trans('cruds.user.fields.password') }}">
                <div class="input-group-append">
                    <button class="btn btn-outline-right visible-password" type="button"  data-target="password">
                        <i class="fas fa-eye-slash"></i>
                    </button>
                </div>
                @if($errors->has('password'))
                    <div class="invalid-feedback">
                        {{ $errors->first('password') }}
                    </div>
                @endif
            </div>
        </div>

        <div class="form-group">
            <label class="required caps">{{ trans('global.login_password_confirmation') }}</label>
            <div class="input-group mb-3">
                <input id="password_confirmation" name="password_confirmation" type="password" class="form-control append-right-borderless {{ $errors->has('password_confirmation') ? ' is-invalid' : '' }}" required placeholder="{{ trans('global.login_password_confirmation') }}">
                <div class="input-group-append">
                    <button class="btn btn-outline-right visible-password" type="button" data-target="password_confirmation">
                        <i class="fas fa-eye-slash"></i>
                    </button>
                </div>
                @if($errors->has('password_confirmation'))
                    <div class="invalid-feedback">
                        {{ $errors->first('password_confirmation') }}
                    </div>
                @endif
            </div>
        </div>

        <div class="form-group">
            <label class="required caps" for="address">{{ trans('cruds.user.fields.address') }}</label>
            <textarea class="form-control {{ $errors->has('address') ? 'is-invalid' : '' }}" name="address" id="address" required>{{ old('address', $register->address ?? '') }}</textarea>
            @if($errors->has('address'))
                <div class="invalid-feedback">
                    {{ $errors->first('address') }}
                </div>
            @endif
        </div>

        <div class="row">
            <div class="col-12" style="padding-top: 1rem;">
                <button type="submit" class="btn btn-orange btn-block caps bold">
                    {{ trans('user.next') }}
                </button>
            </div>
        </div>
    </form>
@endsection