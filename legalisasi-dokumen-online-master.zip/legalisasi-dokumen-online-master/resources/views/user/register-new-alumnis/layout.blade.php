@extends('layouts.userApp')
@section('content')
    {{-- form --}}
    <div class="col-md-12">
        <div class="row justify-content-center" style="padding-top: 150px; min-height: 93vh">
            <div class="col-md-12">
                <h1 class="text-center bold" style="padding-bottom: 2rem;">Register Alumni Baru</h1>
                @php(
                    $steps = [
                        ['name' => '1. Data Akun Alumni', 'route' => 'register-new-alumni.account'],
                        ['name' => '2. Data Ijazah Alumni', 'route' => 'register-new-alumni.certificate'],
                        ['name' => '3. Data Transkrip & TTD Alumni', 'route' => 'register-new-alumni.transcript'],
                    ]
                )
                @include('user.step-menu')
            </div>
            <div class="col-lg-4">
                <div class="card card-borderless">
                    <div class="card-body">
                        @if(session('message'))
                            <div class="alert alert-info" role="alert">
                                {{ session('message') }}
                            </div>
                        @endif
        
                        @yield('form')
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/signature_pad@2.3.2/dist/signature_pad.min.js"></script>
<script>
    $('#createSignature').on('click', function() {
        $('#savedSignature').css("display", "none")
        drawCanvasSignature()
    });

    var signaturePad = null;
    function drawCanvasSignature() {
        $('#canvasSignature').css("display", "block")
        var canvas = document.querySelector("canvas");

        signaturePad = new SignaturePad(canvas, {
            backgroundColor: 'rgb(255, 255, 255)'
        });
        console.log('draw canvas');
    }

    function hideCanvasSignature() {
        $('#canvasSignature').css("display", "none")
        signaturePad.off();
    }

    $('#clearSignature').on('click', function(event) {
        if(signaturePad) {
            signaturePad.clear();
        }
    })

    $('#saveSignature').on('click', function(event) {
        if(signaturePad) {
            var dataURL = signaturePad.toDataURL("image/jpeg");
            // generate image in form
            $('#signature_preview').attr('src', dataURL);
            $('#signature_image').attr('value', dataURL);
            hideCanvasSignature()
            $('#savedSignature').css("display", "block")
        }
    })

    // Returns signature image as data URL (see https://mdn.io/todataurl for the list of possible parameters)
    // signaturePad.toDataURL("image/jpeg"); // save image as JPEG

    // Clears the canvas
    // signaturePad.clear();

    // Returns true if canvas is empty, otherwise returns false
    // signaturePad.isEmpty();

    // Unbinds all event handlers
    // signaturePad.off();

    // Rebinds all event handlers
    // signaturePad.on();
</script>
<script>
    Dropzone.options.certificateFileDropzone = {
        url: "{{ route('user.storeMedia') }}",
        maxFilesize: 10, // MB
        acceptedFiles: '.pdf,.jpg,.png',
        maxFiles: 1,
        addRemoveLinks: true,
        headers: {
            'X-CSRF-TOKEN': "{{ csrf_token() }}"
        },
        params: {
            size: 5
        },
        success: function (file, response) {
            $('form').find('input[name="certificate_file"]').remove()
            $('form').append('<input type="hidden" name="certificate_file" value="' + response.name + '">')
        },
        removedfile: function (file) {
            file.previewElement.remove()
            if (file.status !== 'error') {
                $('form').find('input[name="certificate_file"]').remove()
                this.options.maxFiles = this.options.maxFiles + 1
            }
        },
        init: function () {
            @if(isset($register->certificate_file) && $register->certificate_file)
                var file = {!! json_encode($register->certificate_file) !!}
                    this.options.addedfile.call(this, file)
                file.previewElement.classList.add('dz-complete')
                $('form').append('<input type="hidden" name="certificate_file" value="' + file + '">')
                this.options.maxFiles = this.options.maxFiles - 1
            @endif
        },
        error: function (file, response) {
            if ($.type(response) === 'string') {
                var message = response //dropzone sends it's own error messages in string
            } else {
                var message = response.errors.file
            }
            file.previewElement.classList.add('dz-error')
            _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
            _results = []
            for (_i = 0, _len = _ref.length; _i < _len; _i++) {
                node = _ref[_i]
                _results.push(node.textContent = message)
            }

            return _results
        }
    }
</script>
<script>
    Dropzone.options.transcriptFileDropzone = {
        url: '{{ route('user.storeMedia') }}',
        maxFilesize: 10, // MB
        acceptedFiles: '.pdf,.jpg,.png',
        maxFiles: 1,
        addRemoveLinks: true,
        headers: {
            'X-CSRF-TOKEN': "{{ csrf_token() }}"
        },
        params: {
            size: 5
        },
        success: function (file, response) {
            $('form').find('input[name="transcript_file"]').remove()
            $('form').append('<input type="hidden" name="transcript_file" value="' + response.name + '">')
        },
        removedfile: function (file) {
            file.previewElement.remove()
            if (file.status !== 'error') {
                $('form').find('input[name="transcript_file"]').remove()
                this.options.maxFiles = this.options.maxFiles + 1
            }
        },
        init: function () {
            @if(isset($register->transcript_file) && $register->transcript_file)
                var file = {!! json_encode($register->transcript_file) !!}
                    this.options.addedfile.call(this, file)
                file.previewElement.classList.add('dz-complete')
                $('form').append('<input type="hidden" name="transcript_file" value="' + file + '">')
                this.options.maxFiles = this.options.maxFiles - 1
            @endif
        },
        error: function (file, response) {
            if ($.type(response) === 'string') {
                var message = response //dropzone sends it's own error messages in string
            } else {
                var message = response.errors.file
            }
            file.previewElement.classList.add('dz-error')
            _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
            _results = []
            for (_i = 0, _len = _ref.length; _i < _len; _i++) {
                node = _ref[_i]
                _results.push(node.textContent = message)
            }

            return _results
        }
    }
</script>
@endsection