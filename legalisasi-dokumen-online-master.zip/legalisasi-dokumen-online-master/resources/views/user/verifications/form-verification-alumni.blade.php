@extends('layouts.userApp')
@section('title', 'Verifikasi Alumni')
@section('subtitle', 'Halaman verifikasi ini diperuntuhkan untuk alumni yang lulus sebelum periode saat ini')
@section('content')
    <div class="card card-borderless">
        <div class="card-body">
            @if(session('message'))
                <div class="alert alert-info" role="alert">
                    {{ session('message') }}
                </div>
            @endif

            <form method="POST" action="{{ route('user.verification.store') }}">
                @csrf

                {{-- studyPrograms --}}
                <div class="form-group">
                    <label class="caps" for="study_program">{{ trans('cruds.user.fields.study_program') }}</label>
                    <select name="study_program" id="study_program" class="form-control select2">
                        {{-- <option value selected>{{ trans('cruds.order.fields.study_program') }}</option> --}}
                        @foreach($studyPrograms as $key => $label)
                            <option value="{{ $label }}" {{ $user->study_program === $label ? 'selected' : ''}}>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label class="caps" for="student_number">{{ trans('cruds.user.fields.student_number') }}</label>
                    <input class="form-control {{ $errors->has('student_number') ? 'is-invalid' : '' }}" type="text" name="student_number" id="student_number" value="{{ $user->student_number }}" required placeholder="{{ trans('cruds.user.fields.student_number') }}" disabled>
                    @if($errors->has('student_number'))
                        <div class="invalid-feedback">
                            {{ $errors->first('student_number') }}
                        </div>
                    @endif
                </div>
                <div class="form-group">
                    <label class="required caps" for="certificate_number">{{ trans('cruds.user.fields.certificate_number') }}</label>
                    <input class="form-control {{ $errors->has('certificate_number') ? 'is-invalid' : '' }}" type="text" name="certificate_number" id="certificate_number" value="{{ old('certificate_number', $user->certificate_number) }}" required placeholder="{{ trans('cruds.user.fields.certificate_number') }}">
                    @if($errors->has('certificate_number'))
                        <div class="invalid-feedback">
                            {{ $errors->first('certificate_number') }}
                        </div>
                    @endif
                    <span class="help-block">
                        <i class="fas fa-exclamation-circle text-orange px-1"></i>Klik 
                        <a href="#" class="text-orange" data-target="#infoCertificateFileModal" data-toggle="modal">di sini</a> 
                        untuk melihat contoh nomor ijazah
                    </span>
                </div>
                <div class="form-group">
                    <label for="certificate_file">{{ trans('cruds.user.fields.certificate_file') }}</label>
                    <div class="needsclick dropzone {{ $errors->has('certificate_file') ? 'is-invalid' : '' }}" id="certificate_file-dropzone">
                    </div>
                    <span class="help-block">
                        Jenis file yang diperbolehkan untuk upload (image : jpg, png, pdf)
                    </span>
                    @if($errors->has('certificate_file'))
                        <div class="invalid-feedback">
                            {{ $errors->first('certificate_file') }}
                        </div>
                    @endif
                </div>
                <hr>
                <div class="form-group">
                    <label class="required caps" for="transcript_number">{{ trans('cruds.user.fields.transcript_number') }}</label>
                    <input id="transcript_number" name="transcript_number" type="text" class="form-control {{ $errors->has('transcript_number') ? ' is-invalid' : '' }}" required placeholder="{{ trans('cruds.user.fields.transcript_number') }}" value="{{ old('transcript_number', $user->transcript_number)}}">
                    @if($errors->has('transcript_number'))
                        <div class="invalid-feedback">
                            {{ $errors->first('transcript_number') }}
                        </div>
                    @endif
                    <span class="help-block">
                        <i class="fas fa-exclamation-circle text-orange px-1"></i>
                        Klik 
                        <a href="#" class="text-orange" data-target="#infoTranscriptFileModal" data-toggle="modal">di sini</a> 
                        untuk melihat contoh nomor transkrip
                    </span>
                </div>
                <div class="form-group">
                    <label for="transcript_file">{{ trans('cruds.user.fields.transcript_file') }}</label>
                    <div class="needsclick dropzone {{ $errors->has('transcript_file') ? 'is-invalid' : '' }}" id="transcript_file-dropzone">
                    </div>
                    <span class="help-block">
                        Jenis file yang diperbolehkan untuk upload (image : jpg, png, pdf)
                    </span>
                    @if($errors->has('transcript_file'))
                        <div class="invalid-feedback">
                            {{ $errors->first('transcript_file') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-12" style="padding-top: 1rem;">
                        <button type="submit" class="btn btn-orange px-4 btn-block btn-lg caps bold">
                            {{ trans('user.process') }}
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@include('user.verifications.modals.info-file', ['url' => 'images/img-certificate-file.svg', 'id' => 'infoCertificateFileModal'])
@include('user.verifications.modals.info-file', ['url' => 'images/img-transcript-file.svg', 'id' => 'infoTranscriptFileModal'])
@endsection

@section('scripts')
<script>
    Dropzone.options.certificateFileDropzone = {
        url: "{{ route('user.storeMedia') }}",
        maxFilesize: 10, // MB
        acceptedFiles: '.pdf,.jpg,.png',
        maxFiles: 1,
        addRemoveLinks: true,
        headers: {
            'X-CSRF-TOKEN': "{{ csrf_token() }}"
        },
        params: {
            size: 5
        },
        success: function (file, response) {
            $('form').find('input[name="certificate_file"]').remove()
            $('form').append('<input type="hidden" name="certificate_file" value="' + response.name + '">')
        },
        removedfile: function (file) {
            file.previewElement.remove()
            if (file.status !== 'error') {
                $('form').find('input[name="certificate_file"]').remove()
                this.options.maxFiles = this.options.maxFiles + 1
            }
        },
        init: function () {
            @if(isset($user) && $user->certificate_file)
                var file = {!! json_encode($user->certificate_file) !!}
                    this.options.addedfile.call(this, file)
                file.previewElement.classList.add('dz-complete')
                $('form').append('<input type="hidden" name="certificate_file" value="' + file.file_name + '">')
                this.options.maxFiles = this.options.maxFiles - 1
            @endif
        },
        error: function (file, response) {
            if ($.type(response) === 'string') {
                var message = response //dropzone sends it's own error messages in string
            } else {
                var message = response.errors.file
            }
            file.previewElement.classList.add('dz-error')
            _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
            _results = []
            for (_i = 0, _len = _ref.length; _i < _len; _i++) {
                node = _ref[_i]
                _results.push(node.textContent = message)
            }

            return _results
        }
    }
</script>
<script>
    Dropzone.options.transcriptFileDropzone = {
        url: '{{ route('user.storeMedia') }}',
        maxFilesize: 10, // MB
        acceptedFiles: '.pdf,.jpg,.png',
        maxFiles: 1,
        addRemoveLinks: true,
        headers: {
            'X-CSRF-TOKEN': "{{ csrf_token() }}"
        },
        params: {
            size: 5
        },
        success: function (file, response) {
            $('form').find('input[name="transcript_file"]').remove()
            $('form').append('<input type="hidden" name="transcript_file" value="' + response.name + '">')
        },
        removedfile: function (file) {
            file.previewElement.remove()
            if (file.status !== 'error') {
                $('form').find('input[name="transcript_file"]').remove()
                this.options.maxFiles = this.options.maxFiles + 1
            }
        },
        init: function () {
            @if(isset($user) && $user->transcript_file)
                var file = {!! json_encode($user->transcript_file) !!}
                    this.options.addedfile.call(this, file)
                file.previewElement.classList.add('dz-complete')
                $('form').append('<input type="hidden" name="transcript_file" value="' + file.file_name + '">')
                this.options.maxFiles = this.options.maxFiles - 1
            @endif
        },
        error: function (file, response) {
            if ($.type(response) === 'string') {
                var message = response //dropzone sends it's own error messages in string
            } else {
                var message = response.errors.file
            }
            file.previewElement.classList.add('dz-error')
            _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
            _results = []
            for (_i = 0, _len = _ref.length; _i < _len; _i++) {
                node = _ref[_i]
                _results.push(node.textContent = message)
            }

            return _results
        }
    }
</script>
@endsection