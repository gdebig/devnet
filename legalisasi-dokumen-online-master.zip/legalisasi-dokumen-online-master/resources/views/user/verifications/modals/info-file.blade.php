<div class="modal fade" id="{{$id}}" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
      <div class="modal-content ">
        <div class="modal-body">
            <img src="{{asset($url)}}" style="width: 100%">
        </div>
      </div>
    </div>
</div>