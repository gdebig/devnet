@extends('layouts.userApp')
@section('title', 'Beranda Profil')
@section('content')
    @include('user.menu')
    @include('user.profiles.verification-status', ['status' => Auth::user()->status])
    @if(session('message'))
        <div class="alert alert-info" role="alert">
            {{ session('message') }}
        </div>
    @endif
    @include('user.profiles.form-personal', ['user' => Auth::user()])
    @include('user.profiles.form-address', ['user' => Auth::user()])
@endsection

@section('scripts')
<script>
</script>
@endsection