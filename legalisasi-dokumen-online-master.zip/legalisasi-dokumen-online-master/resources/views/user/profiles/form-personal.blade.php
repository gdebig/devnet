<div class="card card-borderless">
    <div class="card-body">
        <div class="col">
            <h6 class="bold caps">Data Diri</h6>
            <form action="{{ route('user.profile.update') }}" method="POST">
                @csrf
                <input type="hidden" class="form-control" value="{{ $user->id }}" name="id">
                <div class="form-group">
                    <label for="name">{{ trans('cruds.user.fields.name') }}</label>
                    <input type="text" class="form-control" id="name" placeholder="{{ trans('cruds.user.fields.name') }}" value="{{ old('name', $user->name) }}" name="name">
                </div>
                <div class="form-group">
                    <label for="student_number">{{ trans('cruds.user.fields.student_number') }}</label>
                    <input type="student_number" class="form-control" name="student_number" id="student_number" placeholder="{{ trans('cruds.user.fields.student_number') }}" value="{{ old('student_number', $user->student_number) }}" disabled>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required caps">{{ trans('cruds.user.fields.email') }}</label>
                            <input id="email" name="email" type="email" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" required placeholder="{{ trans('cruds.user.fields.email') }}" value="{{ old('email', $user->email)}}">
                            @if($errors->has('email'))
                                <div class="invalid-feedback">
                                    {{ $errors->first('email') }}
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required" for="phone_number">{{ trans('cruds.user.fields.phone_number') }}</label>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-white">
                                        +62
                                    </span>
                                </div>
                                <input class="form-control {{ $errors->has('phone_number') ? 'is-invalid' : '' }}" type="number" name="phone_number" id="phone_number" value="{{ old('phone_number', $user->phone_number) }}" required>
                                @if($errors->has('phone_number'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('phone_number') }}
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="city_of_birth">{{ trans('cruds.user.fields.city_of_birth') }}</label>
                    <input type="text" class="form-control" name="city_of_birth" id="city_of_birth" placeholder="{{ trans('cruds.user.fields.city_of_birth') }}" value="{{ old('city_of_birth', $user->city_of_birth) }}">
                </div>
                <div class="form-group">
                    <label for="date_of_birth">{{ trans('cruds.user.fields.date_of_birth') }}</label>
                    <input type="text" class="form-control date" name="date_of_birth" id="date_of_birth" placeholder="{{ trans('cruds.user.fields.date_of_birth') }}" value="{{ old('date_of_birth', $user->date_of_birth) }}">
                </div>
                <div class="form-group">
                    <label for="graduated_date">{{ trans('cruds.user.fields.graduated_date') }}</label>
                    <input type="text" class="form-control date" name="graduated_date" id="graduated_date" placeholder="{{ trans('cruds.user.fields.graduated_date') }}" value="{{ old('graduated_date', $user->graduated_date) }}">
                </div>
                <button type="submit" class="btn btn-orange">
                    {{ trans('global.save') }}
                </button>
            </form>
        </div>
    </div>
    <!-- /.box-body -->
</div>