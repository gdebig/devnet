@if($status === \App\User::VERIFIED_ID) 
    <div class="card card-borderless card-top-orange">
        <div class="card-body">
            <div class="col">
                <h6 class="caps bold">Status Verifikasi</h6>
                <div class="row">
                    <div class="col-1">
                        <img src="{{asset('images/ic-verification-success.svg')}}">
                    </div>
                    <div class="col">
                        <h6 class="flex bold">Terverifikasi</h6>
                        <p>Selamat profile anda sudah terverifikasi</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
@elseif($status === \App\User::UNVERIFIED_ID)
    <div class="card card-borderless card-top-blue">
        <div class="card-body">
            <div class="col">
                <h6 class="caps bold">Status Verifikasi</h6>
                <div class="row">
                    <div class="col-1">
                        <img src="{{asset('images/ic-verification-progress.svg')}}">
                    </div>
                    <div class="col">
                        <h6 class="flex bold">Sedang Proses Verifikasi</h6>
                        <p>Proses verifikasi membutuhkan waktu 1-2 hari</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
@else
    <div class="card card-borderless card-top-red">
        <div class="card-body">
            <div class="col">
                <h6 class="caps bold">Status Verifikasi</h6>
                <div class="row">
                    <div class="col-1">
                        <img src="{{asset('images/ic-verification-failed.svg')}}">
                    </div>
                    <div class="col">
                        <h6 class="flex bold">Verifikasi Gagal</h6>
                        <p>{!! nl2br(e(Auth::user()->userStatusHistories()->orderBy('created_at', 'desc')->first()->reason)) ?? '' !!}</p>
                        <a href="{{route('user.verification.form')}}" class="btn btn-lg btn-block btn-orange">
                            Verifikasi Ulang
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endif
