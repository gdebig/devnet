<div class="card card-borderless">
    <div class="card-body">
        <div class="col">
            <h6 class="bold caps">Alamat</h6>
            <form action="{{ route('user.profile.update') }}" method="POST">
                @csrf
                <input type="hidden" class="form-control" value="{{ $user->id }}" name="id">
                <div class="form-group">
                    <label for="address">{{ trans('cruds.user.fields.address') }}</label>
                    <textarea class="form-control" id="address" name="address" placeholder="{{ trans('cruds.user.fields.address') }}" required>{{ $user->address }}</textarea>
                </div>
                {{-- <div class="form-group">
                    <label for="address">{{ trans('cruds.user.fields.address') }}</label>
                    <textarea class="form-control" id="address" name="address" placeholder="{{ trans('cruds.user.fields.address') }}" disabled>{{ $user->address }}</textarea>
                </div> --}}
                <button type="submit" class="btn btn-orange">
                    {{ trans('global.save') }}
                </button>
            </form>
        </div>
    </div>
    <!-- /.box-body -->
</div>