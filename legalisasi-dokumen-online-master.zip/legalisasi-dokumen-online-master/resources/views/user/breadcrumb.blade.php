<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        @foreach($items as $item)
            <li class="breadcrumb-item {{ $item['url'] === '#' ? 'active' : ''}}"><a href="{{ $item['url'] ?? '' }}">{{ $item['url_name'] ?? ''}}</a></li>
        @endforeach
    </ol>
</nav>