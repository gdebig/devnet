@extends('layouts.userApp')
@section('content')
    @include('user.dashboard.top-banner')
    @include('user.dashboard.flow-banner')
    @include('user.dashboard.contact-banner')
    {{-- 628998731849 --}}
    {{-- 6281288167422 --}}
    @include('user.dashboard.btn-wa', ['number' => '6281117071964', 'message' => 'Halo'])
    @include('user.dashboard.modals.additional-info', ['modalTitle' => 'Syarat & Ketentuan', 'modalId' => 'termModal', 'modalView' => 'user.dashboard.modals.content-term-condition'])
    @include('user.dashboard.modals.additional-info', ['modalTitle' => 'Petunjuk Pembayaran', 'modalId' => 'paymentGuideModal', 'modalView' => 'user.dashboard.modals.content-payment-guide'])
@endsection

@section('scripts')
    <script>
        $('#loginModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var action = button.data('action') // Extract info from data-* attributes
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var modal = $(this)
            // modal.find('.modal-title').text('New message to ' + action)
            // modal.find('.modal-body input').val(action)
        })
    </script>
@endsection