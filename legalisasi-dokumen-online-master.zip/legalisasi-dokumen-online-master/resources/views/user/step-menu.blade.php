<div class="row justify-content-center" style="padding-bottom: 1rem">
    <nav style="display: flex; width: 90%;">
        <ol class="cd-breadcrumb triangle">
            @foreach($steps as $step)
                <li class="{{ \Request::route()->getName() === $step['route'] ? 'current' : ''}}">
                    {{-- <a href="{{ route($step['route']) }}">{{ $step['name'] }}</a> --}}
                    {{-- <a href="#">{{ $step['name'] }}</a> --}}
                    <span>{{ $step['name'] }}</span>
                </li>
            @endforeach
        </ol>
    </nav>
</div>