<div class="card card-borderless">
    <div class="card-body">
        <div class="row">
            <div class="col text-center">
                <a href="{{route('user.profile')}}" class="btn btn-user-menu btn-block {{ \Request::route()->getName() === 'user.profile' ? 'active' : ''}}">
                    <i class="fas fa-user fa-2x"></i>
                    <br>
                    Profile
                </a>
            </div>
            <div class="col text-center">
                <a href="{{route('user.order')}}" class="btn btn-user-menu btn-block {{ \Request::route()->getName() === 'user.order' ? 'active' : ''}}">
                    <i class="fas fa-file-medical fa-2x"></i>
                    <br>
                    Pemesanan
                </a>
            </div>
        </div>
    </div>
</div>