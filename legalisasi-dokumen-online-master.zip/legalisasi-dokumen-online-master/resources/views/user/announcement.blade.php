@extends('layouts.userApp')
{{-- @section('title', '') --}}
@section('content')
    <div class="c-app flex-row align-items-center">
        <div class="container">
            <div class="row justify-content-center" style="padding-top: 10%; min-height: 93vh">
                <div class="col-md-6" style="padding-bottom: 2rem">
                    @include('user.breadcrumb', [ 'items' => [ ['url_name' => 'Home', 'url' => route('home') ], ['url_name' => 'Pengumuman', 'url' => '#'] ] ])
                    @include('user.dashboard.announcement', ['announcements' => App\Announcement::published()->latest()->get(), 'all' => true])
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
<script>
</script>
@endsection