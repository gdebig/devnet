<div class="row">
    <div class="col-12">
        <h6 class="caps">Metode Pembayaran</h6>
        <h5 class="">{{ \App\Order::PAYMENT_TYPE_SELECT[$order->payment_type] ?? '-'}}</h5>
        @if($order->payment_info)
            @if($order->payment_type === \App\Order::BANK_TRANSFER_ID)
                <div class="col-md-6">
                    <small class="text-muted">{{ 'Nomor Rekening'}}</small>
                    <h6 class="bold">{{ json_decode($order->payment_info)[0]->va_number ?? '' }}</h6>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">{{ 'Bank' }}</small>
                    <h6 class="bold caps">{{ json_decode($order->payment_info)[0]->bank ?? '' }}</h6>
                </div>
            @elseif($order->payment_type === \App\Order::ECHANNEL_ID)
                <div class="col-md-6">
                    <small class="text-muted">{{ 'Nomor Rekening'}}</small>
                    <h6 class="bold">{{ json_decode($order->payment_info)[0]->bill_key ?? '' }}</h6>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">{{ 'Kode Bank' }}</small>
                    <h6 class="bold caps">{{ json_decode($order->payment_info)[0]->biller_code ?? '' }}</h6>
                </div>
            @endif
        @endif
    </div>
</div>
