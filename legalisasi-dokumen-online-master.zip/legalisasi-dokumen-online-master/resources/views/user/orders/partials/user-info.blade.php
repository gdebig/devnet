<div class="row">
    <div class="col-12">
        <h6 class="caps">Data Pemesan</h6>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <small class="text-muted">Nama Pemesan</small>
        <h6 class="bold">{{ $order->user->name }}</h6>
    </div>
    <div class="col-md-6">
        <small class="text-muted">NPM/No Pokok Mahasiswa</small>
        <h6 class="bold">{{ $order->user->student_number }}</h6>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <small class="text-muted">Email</small>
        <h6 class="bold">{{ $order->user->email }}</h6>
    </div>
    <div class="col-md-6">
        <small class="text-muted">No HP</small>
        <h6 class="bold">{{ $order->user->phone_number }}</h6>
    </div>
</div>