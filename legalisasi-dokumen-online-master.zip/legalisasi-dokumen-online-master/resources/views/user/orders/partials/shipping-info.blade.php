<div class="row">
    <div class="col-12">
        <h6 class="caps">Metode Penerimaan & Alamat Pengiriman</h6>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <small class="text-muted">Metode Penerimaan</small>
        <h6 class="bold">{{ \App\Order::SHIPPING_TYPE_SELECT[$order->shipping_type] }}</h6>
    </div>
    <div class="col-md-6">
        <small class="text-muted">Tujuan Pengiriman</small>
        <h6 class="bold">{{ isset($order->destination_type) ? \App\Order::DESTINATION_TYPE_SELECT[$order->destination_type] : '-'}}</h6>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <small class="text-muted">Alamat Detail</small>
        <h6 class="bold">{{ $order->shipping_address ?? '-' }}</h6>
    </div>
</div>
@if($order->shipping_type === \App\Order::DELIVERY_ID)
    <hr>
    <div class="row">
        <div class="col-md-6">
            <small class="text-muted">Negara</small>
            <h6 class="bold">{{ $order->country_name ?? '-' }}</h6>
        </div>
        <div class="col-md-6">
            <small class="text-muted">Provinsi</small>
            <h6 class="bold">{{ $order->province_name ?? '-' }}</h6>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <small class="text-muted">Kota</small>
            <h6 class="bold">{{ $order->city_name ?? '-' }}</h6>
        </div>
        <div class="col-md-6">
            <small class="text-muted">Kecamatan</small>
            <h6 class="bold">{{ $order->district_name ?? '-' }}</h6>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <small class="text-muted">Kelurahan</small>
            <h6 class="bold">{{ $order->subdistrict ?? '-' }}</h6>
        </div>
        <div class="col-md-6">
            <small class="text-muted">Kode Pos</small>
            <h6 class="bold">{{ $order->postal_code ?? '-' }}</h6>
        </div>
    </div>
@endif