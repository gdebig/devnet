<span class="bold">{{ \App\Order::STATUS_SELECT[$order->status] ?? '-' }}</span>
<br>
<small class="text-muted">{!! $order->orderStatusHistories()->orderBy('created_at', 'desc')->first()->reason ?? '-' !!}</small>
<br>
<br>
<div class="pull-right">
    @if($order->status === \App\Order::NOT_YET_PAID_ID)
        <a href="{{route('user.order.payment', ['id' => $order->order_number])}}" class="text-orange">
            Lakukan Pembayaran
        </a>
    @elseif($order->status === \App\Order::ON_DELIVERY_ID)
        <a href="#" class="text-orange" onclick="copyText(event, '{{ $order->receipt_number }}')">
            Salin Resi
        </a>
        <h6 class="bold">{{ $order->receipt_number ?? '-' }}</h6>
    @else
        <a href="#" class="text-orange" onclick="copyText(event, '{{$order->order_number}}')">
            Salin Kode
        </a>
    @endif
</div>
<small class="text-muted">Kode Pemesanan</small>
<h6 class="bold">{{ $order->order_number ?? '-' }}</h6>