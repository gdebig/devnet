@if(isset($pagination))
    <div class="pull-right">
        <div class="btn-group" role="group" aria-label="Basic example">
            @for($page=1;$page<=$pagination['lastPage'];$page++)
                <a href="{{ $pagination['path'].'?page='.$page}}" class="btn btn-light {{ $page === $pagination['page'] ? 'active' : '' }}">{{$page}}</a>
            @endfor
        </div>
    </div>
@endif