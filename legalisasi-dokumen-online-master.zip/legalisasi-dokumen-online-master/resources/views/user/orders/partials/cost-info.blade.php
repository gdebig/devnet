<div class="row" style="padding-bottom:.5rem">
    <div class="col-12">
        <h6 class="caps">Rincian Pembayaran</h6>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <table class="table table-borderless">
            <tr>
                <td>
                    Total Biaya Legalisasi
                </td>
                <td class="text-right">
                    {{ formatRupiah( ($order->total - $order->shipping_cost) )  }}
                </td>
            </tr>
            <tr>
                <td>
                    Biaya Pengiriman
                </td>
                <td class="text-right">
                    {{ formatRupiah($order->shipping_cost) ?? 'Rp. 0' }}
                </td>
            </tr>
            <tr style="border-top: solid 1px #d3d2d4">
                <td class="bold">
                    Total
                </td>
                <td class="bold text-right">
                    {{ formatRupiah($order->total) ?? 'Rp. 0' }}
                </td>
            </tr>
        </table>
    </div>
</div>