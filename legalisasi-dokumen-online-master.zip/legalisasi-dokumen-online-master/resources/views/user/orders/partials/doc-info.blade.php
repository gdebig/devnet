<div class="row" style="padding-bottom:.5rem">
    <div class="col-12">
        <h6 class="caps">Detail Dokumen</h6>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="text-muted bold" style="font-size:12px">Jenis Dokumen & Jumlah Legalisasi</div>
        @foreach ($order->orderItems as $orderItem)
            <h6 class="bold" style="margin-bottom: .2rem; margin-top:.5rem">
                {{ $orderItem->document_type->name }}, {{ $orderItem->amount }} Lembar
            </h6>
            <small>{{ formatRupiah($orderItem->total) }}</small>
            <br>
        @endforeach
    </div>
</div>
<hr>
<div class="row">
    <div class="col-12">
        <h6 class="caps">Catatan Pesanan</h6>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <h6 class="bold" style="margin-bottom: .2rem;">
            {{ $order->notes ?? '-'}}
        </h6>
    </div>
</div>