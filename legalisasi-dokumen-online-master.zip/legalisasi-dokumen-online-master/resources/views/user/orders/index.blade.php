@extends('layouts.userApp')
@section('title', 'Beranda Pemesanan')
@section('content')
    @include('user.menu')
    @if(Auth::user()->status === \App\User::VERIFIED_ID)
        <div class="card card-borderless">
            <div class="card-body">
                <div class="col-md-12">
                <a href="{{ route('user.order.create') }}" class="btn btn-lg btn-block btn-orange">
                        Buat Pesanan
                    </a>
                </div>
            </div>
        </div>
        @include('user.orders.order-summary', ['orders' => Auth::user()->userOrders()->unfinished()->orderBy('created_at', 'desc')->limit(3)->get()])
        {{-- @php( $lastOrderStatus = Auth::user()->userOrders()->where('created_at', 'desc')->first()->status ?? null) --}}
        {{-- @if(!$lastOrderStatus || $lastOrderStatus === \App\Order::FINISH_ID) --}}
        {{-- @endif --}}
        @include('user.orders.order-histories', ['orders' => Auth::user()->userOrders()->finished()->orderBy('created_at', 'desc')->limit(3)->get()])
    @else 
        @include('user.profiles.verification-status', ['status' => Auth::user()->status])
    @endif
@endsection

@section('scripts')
<script>
</script>
@endsection