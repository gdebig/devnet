@if(isset($orders) && count($orders) > 0)
    <div class="card card-borderless">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    @include('user.orders.partials.pagination')
                    <h6 class="caps bold" style="margin: 1rem 0">History Pemesanan</h6>
                    @foreach($orders as $order)
                        <div class="card" style="margin-bottom: 1rem">
                            <div class="card-body">
                                <div class="pull-right">
                                    <small class="text-muted">{{ date('d M Y', strtotime($order->created_at)) }}</small>
                                </div>
                                <small class="text-muted">Jenis Dokumen</small>
                                @foreach($order->orderItems as $orderItem)
                                    <h6 class="bold">{{ $orderItem->document_type->name ?? '-' }}</h6>
                                @endforeach
                                <br>
                                <div class="pull-right text-right">
                                    <small class="text-muted">Kode Pemesanan</small>
                                    <h6 class="bold">{{ $order->order_number }}</h6>
                                </div>
                                <small class="text-muted">Status Pemesanan</small>
                                <h6 class="bold">{{ \App\Order::STATUS_SELECT[$order->status] ?? '-' }}</h6>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
        @if(!isset($all) || $all !== true)
            <div class="card-footer card-borderless bg-white">
                <div class="pull-right">
                    <a href="{{ route('user.order.history') }}" class="text-orange">
                        Lihat semua history
                    </a>
                </div>
            </div>
        @endif
    </div>
@endif