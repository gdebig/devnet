@extends('layouts.userApp')
{{-- @section('title', '') --}}
@section('content')
    @include('user.breadcrumb', [ 'items' => [ ['url_name' => 'Pemesanan', 'url' => route('user.order') ], ['url_name' => 'Status Pemesanan', 'url' => '#'] ] ])
    @if(Auth::user()->status === \App\User::VERIFIED_ID)
        @php($pagination = ['page' => $orders->currentPage(), 'lastPage' => $orders->lastPage(), 'path' => $orders->path()])
        @include('user.orders.order-summary', ['orders' => $orders->items(), 'all' => true, 'pagination' => $pagination])
    @else 
        @include('user.profiles.verification-status', ['status' => Auth::user()->status])
    @endif
@endsection

@section('scripts')
<script>
</script>
@endsection