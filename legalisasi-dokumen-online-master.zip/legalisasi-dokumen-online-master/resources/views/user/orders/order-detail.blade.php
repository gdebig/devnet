@extends('layouts.userApp')
@section('content')
    @include('user.breadcrumb', [ 'items' => [ ['url_name' => 'Pemesanan', 'url' => route('user.order') ], ['url_name' => 'Detail Pemesanan', 'url' => '#'] ] ])
    <div class="card card-borderless card-top-blue">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <h6 class="caps bold">Detail Pemesanan</h6>
                    <div class="row">
                        @foreach($order->status_progress as $key => $progress)
                            @php ( $is_active = $key <= $order->status ? 'active' : 'inactive' )
                            <div class="col-4 text-center" style="padding: .5rem 0">
                                @if($key != 1 && $key != 4 && $key != 5)
                                    <div class="progress-divider left-divide">
                                    </div>
                                @endif
                                @if($key !== 3 && $key  !== 6 && $key !== 7)
                                    <div class="progress-divider right-divide">
                                    </div>
                                @endif
                                <img src="{{ asset('images/ic-order-status-'.$key.'-'.$is_active.'.svg') }}" style="padding: .5rem 0">
                                <p class="text-muted text-small">{{ $progress }}</p>
                            </div>
                        @endforeach
                    </div>
                    <hr>
                    @include('user.orders.partials.order-info')
                </div>
            </div>
        </div>
    </div>
    <div class="card card-borderless">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    @include('user.orders.partials.user-info')
                    <hr>
                    @include('user.orders.partials.doc-info')
                    <hr>
                    @include('user.orders.partials.payment-info')
                    <hr>
                    @include('user.orders.partials.shipping-info')
                </div>
            </div>
        </div>
    </div>
    <div class="card card-borderless">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    @include('user.orders.partials.cost-info')
                </div>
            </div>
        </div>
    </div>
@endsection