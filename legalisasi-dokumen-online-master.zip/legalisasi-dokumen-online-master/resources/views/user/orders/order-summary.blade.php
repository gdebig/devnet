@if(isset($orders) && count($orders) > 0)
    <div class="card card-borderless card-top-blue">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    @include('user.orders.partials.pagination')
                    <h6 class="caps bold">Status Pemesanan</h6>
                    <hr>
                    @foreach($orders as $order)
                        <div class="pull-right">
                            <a href="{{ route('user.order.detail', ['id' => $order->order_number]) }}" class="text-blue">
                                Detail Order
                            </a>
                        </div>
                        @include('user.orders.partials.order-info')
                        <hr>
                    @endforeach
                </div>
            </div>
        </div>
        @if(!isset($all) || $all !== true)
            <div class="card-footer card-borderless bg-white">
                <div class="pull-right">
                    <a href="{{ route('user.order.status') }}" class="text-orange">
                        Lihat semua pesanan
                    </a>
                </div>
            </div>
        @endif
    </div>
@endif