@extends('layouts.userApp')
@section('content')
    {{-- form --}}
    <div class="col-md-12">
        <div class="row justify-content-center" style="padding-top: 100px; min-height: 93vh">
            <div class="col-lg-4">
                <h1 class="text-center bold" style="padding-bottom: 2rem;">Register Alumni</h1>
                <div class="card card-borderless">
                    <div class="card-body">
                        <p class="bold text-center">Sudah memiliki akun? <a href="{{route('login')}}" class="text-orange">Klik di sini</a></p>
        
                        @if(session('message'))
                            <div class="alert alert-info" role="alert">
                                {{ session('message') }}
                            </div>
                        @endif
        
                        <form method="POST" action="{{ route('register.alumni.create') }}">
                            @csrf
                            <div class="form-group">
                                <label class="required" for="name">{{ trans('cruds.user.fields.name') }}</label>
                                <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" value="{{ old('name', '') }}" required>
                                @if($errors->has('name'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('name') }}
                                    </div>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="required" for="student_number">{{ trans('cruds.user.fields.student_number') }}</label>
                                <input class="form-control {{ $errors->has('student_number') ? 'is-invalid' : '' }}" type="text" name="student_number" id="student_number" value="{{ old('student_number', '') }}" required>
                                @if($errors->has('student_number'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('student_number') }}
                                    </div>
                                @endif
                            </div>
        
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required caps">{{ trans('cruds.user.fields.email') }}</label>
                                        <input id="email" name="email" type="email" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" required placeholder="{{ trans('cruds.user.fields.email') }}" value="{{ old('email')}}">
                                        @if($errors->has('email'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('email') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required" for="phone_number">{{ trans('cruds.user.fields.phone_number') }}</label>
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text bg-white">
                                                    +62
                                                </span>
                                            </div>
                                            <input class="form-control {{ $errors->has('phone_number') ? 'is-invalid' : '' }}" type="number" name="phone_number" id="phone_number" value="{{ old('phone_number', '') }}" required>
                                            @if($errors->has('phone_number'))
                                                <div class="invalid-feedback">
                                                    {{ $errors->first('phone_number') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="required caps">{{ trans('cruds.user.fields.password') }}</label>
                                <div class="input-group mb-3">
                                    <input id="password" name="password" type="password" class="form-control append-right-borderless {{ $errors->has('password') ? ' is-invalid' : '' }}" required placeholder="{{ trans('cruds.user.fields.password') }}">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-right visible-password" type="button"  data-target="password">
                                            <i class="fas fa-eye-slash"></i>
                                        </button>
                                    </div>
                                    @if($errors->has('password'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('password') }}
                                        </div>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="required caps">{{ trans('global.login_password_confirmation') }}</label>
                                <div class="input-group mb-3">
                                    <input id="password_confirmation" name="password_confirmation" type="password" class="form-control append-right-borderless {{ $errors->has('password_confirmation') ? ' is-invalid' : '' }}" required placeholder="{{ trans('global.login_password_confirmation') }}">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-right visible-password" type="button" data-target="password_confirmation">
                                            <i class="fas fa-eye-slash"></i>
                                        </button>
                                    </div>
                                    @if($errors->has('password_confirmation'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('password_confirmation') }}
                                        </div>
                                    @endif
                                </div>
                            </div>

                            {{-- <div class="form-group">
                                <label class="required caps" for="address">{{ trans('cruds.user.fields.address') }}</label>
                                <textarea class="form-control {{ $errors->has('address') ? 'is-invalid' : '' }}" name="address" id="address" required>{{ old('address') }}</textarea>
                                @if($errors->has('address'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('address') }}
                                    </div>
                                @endif
                            </div> --}}
        
                            <div class="row">
                                <div class="col-12" style="padding-top: 1rem;">
                                    <button type="submit" class="btn btn-orange px-4 btn-block btn-lg caps bold">
                                        {{ trans('global.register') }}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        
    </script>
@endsection