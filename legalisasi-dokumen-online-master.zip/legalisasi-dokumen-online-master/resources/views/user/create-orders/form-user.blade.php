@extends('user.create-orders.layout')
@section('title', 'Data Pemesanan')
@section('form')
    <form method="POST" action="{{ route('user.order.user.save') }}">
        @csrf
        <input type="hidden" value="{{ $user->id }}" name="user_id">
        <div class="pull-right">
            <a href="{{route('user.profile')}}" class="text-orange">
                Edit 
            </a>
        </div>
        <div class="form-group">
            <label for="name">{{ trans('cruds.user.fields.name') }}</label>
            <input type="text" class="form-control" id="name" placeholder="{{ trans('cruds.user.fields.name') }}" value="{{ old('name', $user->name ?? '') }}" name="name" disabled>
            @if($errors->has('name'))
                <div class="invalid-feedback">
                    {{ $errors->first('name') }}
                </div>
            @endif
        </div>
        <div class="form-group">
            <label for="student_number">{{ trans('cruds.user.fields.student_number') }}</label>
            <input type="student_number" class="form-control" name="student_number" id="student_number" placeholder="{{ trans('cruds.user.fields.student_number') }}" value="{{ old('student_number', $user->student_number ?? '') }}" disabled>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps">{{ trans('cruds.user.fields.email') }}</label>
                    <input id="email" name="email" type="email" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" required placeholder="{{ trans('cruds.user.fields.email') }}" value="{{ old('email', $user->email ?? '')}}" disabled>
                    @if($errors->has('email'))
                        <div class="invalid-feedback">
                            {{ $errors->first('email') }}
                        </div>
                    @endif
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required caps" for="phone_number">{{ trans('cruds.user.fields.phone_number') }}</label>
                    <div class="input-group mb-3 disabled">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                +62
                            </span>
                        </div>
                        <input class="form-control {{ $errors->has('phone_number') ? 'is-invalid' : '' }}" type="number" name="phone_number" id="phone_number" value="{{ old('phone_number', $user->phone_number ?? '') }}" disabled>
                        @if($errors->has('phone_number'))
                            <div class="invalid-feedback">
                                {{ $errors->first('phone_number') }}
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="city_of_birth">{{ trans('cruds.user.fields.city_of_birth') }}</label>
                    <input type="city_of_birth" class="form-control" name="city_of_birth" id="city_of_birth" placeholder="{{ trans('cruds.user.fields.city_of_birth') }}" value="{{ old('city_of_birth', $user->city_of_birth ?? '') }}" disabled>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="date_of_birth">{{ trans('cruds.user.fields.date_of_birth') }}</label>
                    <input type="date_of_birth" class="form-control date" name="date_of_birth" id="date_of_birth" placeholder="{{ trans('cruds.user.fields.date_of_birth') }}" value="{{ old('date_of_birth', $user->date_of_birth ?? '') }}" disabled>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="address">{{ trans('cruds.user.fields.address') }}</label>
            <textarea class="form-control {{ $errors->has('address') ? 'is-invalid' : '' }}" id="address" name="address" placeholder="{{ trans('cruds.user.fields.address') }}" disabled>{{ $user->address ?? '' }}</textarea>
            @if($errors->has('address'))
                <div class="invalid-feedback">
                    {{ $errors->first('address') }}
                </div>
            @endif
        </div>

        <div class="row">
            <div class="col-12" style="padding-top: 1rem;">
                <button type="submit" class="btn btn-orange px-4 btn-block caps bold">
                    {{ trans('user.next') }}
                </button>
            </div>
        </div>
    </form>
@endsection