@extends('user.create-orders.layout')
@section('title', 'Review')
@section('content')
{{-- Data Pemesan --}}
<div class="card card-borderless">
    <div class="card-body">
        <div class="row">
            <div class="col-12">
                <h6 class="caps">DATA PEMESAN</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <small class="text-muted">Nama Pemesan</small>
                <h6 class="bold">{{ $user->name }}</h6>
            </div>
            <div class="col-md-6">
                <small class="text-muted">NPM/No Pokok Mahasiswa</small>
                <h6 class="bold">{{ $user->student_number }}</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <small class="text-muted">Email</small>
                <h6 class="bold">{{ $user->email }}</h6>
            </div>
            <div class="col-md-6">
                <small class="text-muted">No HP</small>
                <h6 class="bold">{{ $user->phone_number }}</h6>
            </div>
        </div>
    </div>
</div>
{{-- Detail Dokumen --}}
<div class="card card-borderless">
    <div class="card-body">
        <div class="row" style="padding-bottom:.5rem">
            <div class="col-12">
                <h6 class="caps">Detail Dokumen</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="text-muted bold" style="font-size:12px">Jenis Dokumen & Jumlah Legalisasi</div>
                @foreach (\App\DocumentType::whereIn('id', $order->order_item_doc_type)->get() as $key => $docType)
                    <h6 class="bold" style="margin-bottom: .2rem; margin-top:.5rem">
                        {{ $docType->name }}, {{ $order->order_item_amount[$key] ?? '1' }} Lembar
                    </h6>
                    <small>1 lembar {{ formatRupiah($docType->price) ?? 'Rp. 0' }}</small>
                    <br>
                @endforeach
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-12">
                <h6 class="caps">Catatan Pesanan</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <h6 class="bold" style="margin-bottom: .2rem;">
                    {{ $order->notes ?? '-' }}
                </h6>
            </div>
        </div>
    </div>
</div>
{{-- Metode Penerimaan & Alamat --}}
<div class="card card-borderless">
    <div class="card-body">
        <div class="row">
            <div class="col-12">
                <h6 class="caps">Metode Penerimaan & Alamat Pengiriman</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <small class="text-muted">Metode Penerimaan</small>
                <h6 class="bold">{{ \App\Order::SHIPPING_TYPE_SELECT[$order->shipping_type] }}</h6>
            </div>
            <div class="col-md-6">
                <small class="text-muted">Tujuan Pengiriman</small>
                <h6 class="bold">{{ isset($order->destination_type) ? \App\Order::DESTINATION_TYPE_SELECT[$order->destination_type] : '-'}}</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <small class="text-muted">Alamat Detail</small>
                <h6 class="bold">{{ $order->shipping_address ?? '' }}</h6>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <small class="text-muted">Negara</small>
                <h6 class="bold">{{ $order->country_name ?? '-' }}</h6>
            </div>
            <div class="col-md-6">
                <small class="text-muted">Provinsi</small>
                <h6 class="bold">{{ $order->province_name ?? '-' }}</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <small class="text-muted">Kota</small>
                <h6 class="bold">{{ $order->city_name ?? '-' }}</h6>
            </div>
            <div class="col-md-6">
                <small class="text-muted">Kecamatan</small>
                <h6 class="bold">{{ $order->district_name ?? '-' }}</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <small class="text-muted">Kelurahan</small>
                <h6 class="bold">{{ $order->subdistrict ?? '-' }}</h6>
            </div>
            <div class="col-md-6">
                <small class="text-muted">Kode Pos</small>
                <h6 class="bold">{{ $order->postal_code ?? '-' }}</h6>
            </div>
        </div>
    </div>
</div>
{{-- Pengiriman --}}
<div class="card card-borderless">
    <div class="card-body">
        <div class="row" style="padding-bottom:.5rem">
            <div class="col-12">
                <h6 class="caps">Pengiriman</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <h6 class="bold">{{ $order->courier_name }}</h6>
                <small class="text-blue">{{ isset($order->shipping_cost) ? formatRupiah($order->shipping_cost) : '-' }}</small>
            </div>
        </div>
    </div>
</div>
{{-- Metode --}}
{{-- <div class="card card-borderless">
    <div class="card-body">
        <div class="row" style="padding-bottom:.5rem">
            <div class="col-12">
                <h6 class="caps">Metode Pembayaran</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <h6 class="bold">{{ \App\Order::PAYMENT_TYPE_SELECT[$order->payment_type] }}</h6>
            </div>
        </div>
    </div>
</div> --}}
{{-- Rincian Pembayaran --}}
<div class="card card-borderless">
    <div class="card-body">
        <div class="row" style="padding-bottom:.5rem">
            <div class="col-12">
                <h6 class="caps">Rincian Pembayaran</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <table class="table table-borderless">
                    <tr>
                        <td>
                            Total Biaya Legalisasi
                        </td>
                        <td class="text-right">
                            {{ formatRupiah($order->doc_cost) }}
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Biaya Pengiriman
                        </td>
                        <td class="text-right">
                            {{ formatRupiah($order->shipping_cost) ?? 'Rp. 0' }}
                        </td>
                    </tr>
                    <tr style="border-top: solid 1px #d3d2d4">
                        <td class="bold">
                            Total
                        </td>
                        <td class="bold text-right">
                            {{ formatRupiah($order->total) ?? 'Rp. 0' }}
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="card card-borderless">
    <div class="card-body">
        <div class="row">
            <div class="col-6">
                <a href="{{ route('user.order.docs')}}" class="btn btn-outline-secondary btn-block">Kembali</a>
            </div>
            <div class="col-6">
                <form method="POST" action="{{ route('user.order.review.save')}}">
                    @csrf
                    <button type="submit" class="btn btn-orange btn-block">Buat Pesanan</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection