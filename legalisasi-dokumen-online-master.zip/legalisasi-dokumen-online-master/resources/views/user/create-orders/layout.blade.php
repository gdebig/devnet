@extends('layouts.userApp')
@section('header')
    @php(
        $steps = [
            ['name' => '1. Data Pemesan', 'route' => 'user.order.user'],
            ['name' => '2. Data Dokumen', 'route' => 'user.order.docs'],
            ['name' => '3. Review', 'route' => 'user.order.review']
        ]
    )
    @include('user.step-menu')
@endsection
@section('content')
    <div class="card card-borderless">
        <div class="card-body">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            @if(session('message'))
                <div class="alert alert-info" role="alert">
                    {{ session('message') }}
                </div>
            @endif
            
            @yield('form')
        </div>
    </div>
@endsection