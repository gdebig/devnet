<script>
    $(document).ready(function () {
        checkShipType()
        updateTotal()
    
        $('input[name=destination_type]').on('change', function() {
            // wait this to final
            getCountry()
            getProvince()
            getCity()
            getDistrict()
            getCourier()
            updateTotal()
        })

        $('input[name=shipping_type]').on('change', function() {
            checkShipType()
        })
    
        $('#country').on('change', function() {
            getCourier()
            updateTotal()
        })
    
        $('#province').on('change', function() {
            getCity()
            updateTotal()
        })
    
        $('#city').on('change', function() {
            getDistrict()
            updateTotal()
        })
    
        $('#district').on('change', function() {
            getCourier()
            updateTotal()
        })
    
        $('.documentTypeInput').on('change', function() {
            // check active
            var val = $(this).val()
            var perprice = $(this).data('perprice')
            if($(this).is(":checked")) {
                $('#amount_'+val).attr('disabled', false)
            } else {
                $('#amount_'+val).val(0)
                $('#amount_'+val).attr('disabled', true)
            }
            updateTotal()
        })
    
        $('.amountInput').on('change', function() {
            getCourier()
            updateTotal()
        })
    
        $('#courier').on('change', function() {
            updateTotal()
        })
    });
    
    var $loading = $('#loadingBtn').hide();
    
    $(document)
    .ajaxStart(function () {
        $('#btnFormDoc').attr('disabled', true);
        $loading.show();
      })
    .ajaxStop(function () {
        $('#btnFormDoc').attr('disabled', false);
        $loading.hide();
    });
    
    function getNameFromOption(selectID) {
        var textOpt = $('#' + selectID+" option:selected" ).text();
        // add input in form
        $('<input>').attr({
            type: 'hidden',
            id: selectID + '_name',
            name: selectID + '_name',
            value: textOpt
        }).appendTo('form');
    }

    $("form").submit( function(eventObj) {
        getNameFromOption('country')
        getNameFromOption('province')
        getNameFromOption('city')
        getNameFromOption('district')
        getNameFromOption('courier')
        var shipCost = $("#courier option:selected" ).data('price')
        $('<input>').attr({
            type: 'hidden',
            id: 'shipping_cost',
            name: 'shipping_cost',
            value: shipCost
        }).appendTo('form')
        var shipService = $("#courier option:selected" ).data('service')
        $('<input>').attr({
            type: 'hidden',
            id: 'courier_service',
            name: 'courier_service',
            value: shipService
        }).appendTo('form')

        var total = countTotal()
        $('<input>').attr({
            type: 'hidden',
            id: 'total',
            name: 'total',
            value: total
        }).appendTo('form')

        return true;
    });

    function countTotal() {
        var total = 0;
        $('.amountInput').each(
            function(index){  
                var price = parseInt( $(this).data('price') ) * parseInt( $(this).val() );
                // console.log(price)
                if(price) {
                    // console.log('price ' + price)
                    total += price
                }
            }
        )
        $('#totalDocCost').val(total)

        $('#courier option').each(
            function(index){
                var price = parseInt( $(this).data('price') )
                // console.log(price)
                if($(this).is(":selected")) {
                    total += price
                }
            }
        )
        return total
    }
    function updateTotal() {
        total = countTotal()
        total = numberWithCommas(total)
        $('#totalInput').val(total)
    }

    var destTypeLocal = function() { return $('#destination_type_{{\App\Order::LOCAL_ID}}').is(":checked") }; 
    var destTypeIntl = function() { return $('#destination_type_{{\App\Order::INTERNATIONAL_ID}}').is(":checked") };
    function getCountry() {
        var selectID = "#country";
        // 
        var selectedData = '{{$order->country_id ?? ""}}'
        $(selectID).empty(); // clear the container
        if (destTypeIntl()) { // in case they select "Please select"
            $(selectID+'_load').show();
            $.ajax({
                url: "{{ route('user.order.country') }}", 
                type: 'GET', 
                data: {  },
                dataType: 'json',
                // async: false,
                success: function(data){
                    if(destTypeIntl()) {
                    data.data.forEach(function (country) {
                        $(selectID).append('<option value=' + country.country_id + '>' + country.country_name + '</option>');
                    })
                    }
                    $(selectID).val(selectedData).trigger('change');
                    $(selectID+'_load').hide();
                    updateTotal()
                }
            });
            $(selectID).attr('disabled', false)
            $('#province').attr('disabled', true)
            $('#city').attr('disabled', true)
            $('#district').attr('disabled', true)
            $('#subdistrict').attr('disabled', true)
            $('#postal_code').attr('disabled', true)
            $('#province').val('')
            $('#city').val('')
            $('#district').val('')
            $('#subdistrict').val('')
            $('#postal_code').val('')
        }
    }

    function getProvince() {
        var selectID = "#province";
        var selectedData = '{{$order->province_id ?? ""}}'
        // 
        $(selectID).empty(); // clear the container
        if (destTypeLocal()) { // in case they select "Please select"
            $(selectID+'_load').show();
            $.ajax({
                url: "{{ route('user.order.province') }}", 
                type: 'GET', 
                data: {  },
                dataType: 'json',
                // async: false,
                success: function(data){
                    if(destTypeLocal()) {
                    data.data.forEach(function (province) {
                        $(selectID).append('<option value=' + province.province_id + '>' + province.province + '</option>');
                    })
                    }
                    $(selectID).val(selectedData).trigger('change')
                    $(selectID+'_load').hide();
                    updateTotal()
                }
            });
            $(selectID).attr('disabled', false)
            $('#country').attr('disabled', true)
            $('#city').attr('disabled', false)
            $('#district').attr('disabled', false)
            $('#subdistrict').attr('disabled', false)
            $('#postal_code').attr('disabled', false)
        }
    }
    
    function getCity() {
        var provinceID = $('#province').val();
        var selectID = "#city";
        var selectedData = '{{$order->city_id ?? ""}}'
        // 
        $(selectID).empty(); // clear the container
        if (provinceID) { // in case they select "Please select"
            $(selectID+'_load').show();
          $.ajax({
                url: "{{ route('user.order.city') }}", 
                type: 'GET', 
                data: { province_id : provinceID },
                dataType: 'json',
                // async: false,
                success: function(data){
                    if(destTypeLocal()) {
                    data.data.forEach(function (city) {
                        $(selectID).append('<option value=' + city.city_id + '>' + city.type + " " + city.city_name + '</option>');
                    })
                    }
                    $(selectID).val(selectedData).trigger('change')
                    $(selectID+'_load').hide();
                    updateTotal()
                }
            });
        }
    }
    
    function getDistrict() {
        var cityID = $('#city').val();
        var selectID = "#district";
        var selectedData = '{{$order->district_id ?? ""}}'
        // 
        $(selectID).empty(); // clear the container
        if (cityID) { // in case they select "Please select"
            $(selectID+'_load').show();
          $.ajax({
                url: "{{ route('user.order.district') }}", 
                type: 'GET', 
                data: { city_id : cityID },
                dataType: 'json',
                // async: false,
                success: function(data){
                    if(destTypeLocal()) {
                    data.data.forEach(function (district) {
                        $(selectID).append('<option value=' + district.subdistrict_id + '>' + district.subdistrict_name + '</option>');
                    })
                    }
                    $(selectID).val(selectedData).trigger('change')
                    $(selectID+'_load').hide();
                    updateTotal()
                }
            });
        }
    }
    
    function getCourier() {
        var countryID = $('#country').val();
        var provinceID = $('#province').val();
        var cityID = $('#city').val();
        var districtID = $('#district').val();
        var selectID = "#courier";
        var courierURL = "{{ route('user.order.courier-local') }}";
        if(countryID) {
            courierURL = "{{ route('user.order.courier-intl') }}";
        }
        var selectedData = '{{$order->courier ?? ""}}'
        var totalWeight = getTotalWeight();
        $(selectID).empty(); // clear the container
        if (districtID || countryID) { // in case they select "Please select"
            if(totalWeight < 1) {
                alert('Kurir tidak bisa ditemukan, jumlah berat barang kurang dari 1 gram')
            } else {
                $(selectID+'_load').show();
                $('input[name=destination_type]').attr('disabled', true)
                $.ajax({
                        url: courierURL, 
                        type: 'GET', 
                        data: { province_id: provinceID , city_id: cityID , district_id: districtID, country_id: countryID, weight: totalWeight},
                        dataType: 'json',
                        // async: false,
                        success: function(data){
                            data.data.forEach(function (courier) {
                                $(selectID).append('<option value=' + courier.id + ' data-price=' + courier.price +' data-service='+ courier.service +'>' + courier.text + '</option>');
                            })
                            $('input[name=destination_type]').attr('disabled', false)
                            $(selectID).val(selectedData).trigger('change');
                            $(selectID+'_load').hide();
                            updateTotal()
                        }
                    });
                }
            }
    }

    function getTotalWeight() {
        var total = 0;
        $('.amountInput').each(
            function(index){  
                var weight = parseInt( $(this).data('weight') ) * parseInt( $(this).val() );
                if(weight) {
                    total += weight
                }
            }
        )
        return total
    }

    function checkShipType() {
        var val = $('#shipping_type_{{App\Order::DELIVERY_ID}}').prop('checked')
        if(val) {
            $('input[name=destination_type]').attr('disabled', false);
            // enabled
            $('#country').attr('disabled', false);
            $('#province').attr('disabled', false);
            $('#city').attr('disabled', false);
            $('#district').attr('disabled', false);
            $('#shipping_address').attr('disabled', false);
            $('#courier').attr('disabled', false);
            $('#subdistrict').attr('disabled', false);
            $('#postal_code').attr('disabled', false);
        } else {
            // disabled all
            $('input[name=destination_type]').attr('disabled', true);
            $('#destination_type_1').prop('checked', false);
            $('#destination_type_2').prop('checked', false);
            $('#country').attr('disabled', true);
            $('#province').attr('disabled', true);
            $('#city').attr('disabled', true);
            $('#district').attr('disabled', true);
            $('#shipping_address').attr('disabled', true);
            $('#shipping_address').val('');
            $('#courier').attr('disabled', true);
            $('#subdistrict').attr('disabled', true);
            $('#subdistrict').val('');
            $('#postal_code').attr('disabled', true);
            $('#postal_code').val('');
        }
        getCountry()
        getProvince()
        getCity()
        getDistrict()
        getCourier()
    }
</script>