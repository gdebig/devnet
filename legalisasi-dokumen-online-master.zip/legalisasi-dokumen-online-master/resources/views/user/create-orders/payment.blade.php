@extends('layouts.userApp')
@section('title', 'Pembayaran')
@section('content')
    @include('user.breadcrumb', [ 'items' => [ ['url_name' => 'Pemesanan', 'url' => route('user.order') ], ['url_name' => 'Pembayaran', 'url' => '#'] ] ])
    <div class="card card-borderless">
        <div class="card-body">
            <div class="row">
                <div class="col-10">
                    <h6 class="caps">Kode Pemesanan: {{ $order->order_number }}</h6>
                </div>
                <div class="col-2">

                </div>
            </div>
            <hr>
            @include('user.orders.partials.user-info')
            <hr>
            @include('user.orders.partials.doc-info')
        </div>
    </div>
    <div class="card card-borderless">
        <div class="card-body">
            @include('user.orders.partials.payment-info')
            <hr>
            <div class="row">
                <div class="col-12">
                    <h6 class="bold">Transfer sejumlah</h6>
                </div>
                <div class="col-10">
                    <h5 class="bold"> {{ formatRupiah($order->total) }} </h5>
                </div>
            </div>
            <hr>  
            <div class="">
                <button class="btn btn-block btn-orange" data-token="{{$midtransToken}}" id="pay-button" {{$midtransToken ? '' : 'disabled'}}>Lakukan Pembayaran</button>
                @if(!$midtransToken)
                    <span class="help-block">
                        <i class="fas fa-exclamation-circle text-orange px-1"></i>
                        Pembayaran sedang diproses
                    </span>
                @endif
            </div>
        </div>
    </div>
@endsection
@section('scripts')
<script 
    type="text/javascript"
    src="https://app.sandbox.midtrans.com/snap/snap.js"
    data-client-key="{{env('MIDTRANS_KEY')}}"
>
</script>
<script type="text/javascript">
    var payButton = document.getElementById('pay-button');
    var token = $('#pay-button').data('token');
    // For example trigger on button clicked, or any time you need
    payButton.addEventListener('click', function () {
        snap.pay(token); // Replace it with your transaction token
    });
</script>
@endsection