@extends('user.create-orders.layout')
@section('title', 'Data Dokumen')
@section('form')
    <form method="POST" action="{{ route('user.order.docs.save') }}">
        @csrf
        <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
        <div class="row">
            <div class="col-md-6 col-8">
                <label for="name" class="caps">{{ trans('cruds.orderItem.fields.document_type') }}</label>
            </div>
            <div class="col-md-6 col-4">
                <label for="student_number" class="caps">{{ trans('cruds.orderItem.fields.amount') }}</label>
            </div>
            @foreach(\App\DocumentType::filterUser()->get() as $index => $doc)
                <div class="col-md-6 col-8">
                    <div class="form-group">
                        <div class="form-check form-check-inline">
                            @php($docCheck = isset($order->order_item_doc_type) ? in_array($doc->id, $order->order_item_doc_type) : 0)
                            @php($docAmount = isset($order->order_item_doc_type) ? (array_keys($order->order_item_doc_type, $doc->id)[0] ?? -1) : -1)
                            <input class="form-check-input documentTypeInput" type="checkbox" name="order_item_doc_type[]" id="doc_type_{{$doc->id}}" value="{{$doc->id}}" {{ isset($order->order_item_doc_type) && $docCheck ? "checked" : ''}}>
                            <label class="form-check-label" for="doc_type_{{$doc->id}}">
                                {{ $doc->name }}
                            </label>
                        </div>
                        <br>
                        <small class="text-blue" style="padding-left: 1rem;">
                            {{ '1 LEMBAR Rp '.$doc->price }}
                        </small>
                    </div>
                </div>
                <div class="col-md-6 col-4">
                    <div class="form-group">
                        <input type="number" class="form-control amountInput" name="order_item_amount[]" id="amount_{{$doc->id}}" {{ isset($order->order_item_doc_type) && in_array($doc->id, $order->order_item_doc_type) ? '' : 'disabled'}} min="1" data-price="{{$doc->price}}" data-weight="{{$doc->weight}}" placeholder="Jumlah legalisasi per lembar" value="{{ $order->order_item_amount[$docAmount] ?? ''}}" required>
                    </div>
                </div>
            @endforeach
        </div>
        <div class="form-group">
            <label for="notes" class="caps">{{ 'Catatan Pesanan' }}</label>
            <textarea class="form-control  {{ $errors->has('notes') ? 'is-invalid' : '' }}" id="notes" name="notes" placeholder="{{ 'Catatan Pesanan' }}">{{ $order->notes ?? '' }}</textarea>
            @if($errors->has('notes'))
                <div class="invalid-feedback">
                    {{ $errors->first('notes') }}
                </div>
            @endif
        </div>
        <hr>
        <div class="form-group">
            <label for="shipping_type" class="caps">{{ trans('cruds.order.fields.shipping_type') }}</label>
            <br>
            @php($oldShipType = isset($order->shipping_type) ? (int) $order->shipping_type : old('shipping_type'))
            @foreach(\App\Order::SHIPPING_TYPE_SELECT as $key => $shippingType)
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="shipping_type" id="shipping_type_{{$key}}" value="{{$key}}" {{ $oldShipType === $key ? 'checked' : 'false' }} required>
                    <label class="form-check-label" for="shipping_type_{{$key}}">
                        {{ $shippingType }}
                    </label>
                </div>
            @endforeach
            @if($errors->has('shipping_type'))
                <div class="invalid-feedback">
                    {{ $errors->first('shipping_type') }}
                </div>
            @endif
        </div>
        <div class="form-group">
            <label for="destination_type" class="caps">{{ trans('cruds.order.fields.destination_type') }}</label>
            <br>
            @php($oldDestType = isset($order->destination_type) ? (int) $order->destination_type : old('destination_type'))
            @foreach(\App\Order::DESTINATION_TYPE_SELECT as $key => $destinationType)
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="destination_type" id="destination_type_{{$key}}" value="{{$key}}" {{ $oldDestType === $key ? 'checked' : 'false' }} required>
                    <label class="form-check-label" for="destination_type_{{$key}}">
                        {{ $destinationType }}
                    </label>
                </div>
            @endforeach
            @if($errors->has('destination_type'))
                <div class="invalid-feedback">
                    {{ $errors->first('destination_type') }}
                </div>
            @endif
        </div>
        <hr>
        <div class="form-group">
            <label for="shipping_address" class="caps">{{ trans('cruds.order.fields.shipping_address') }}</label>
            <textarea class="form-control" id="shipping_address" name="shipping_address" placeholder="{{ trans('cruds.order.fields.shipping_address') }}" required>{{ $order->shipping_address ?? $user->address }}</textarea>
            <span class="help-block">Mohon isikan alamat sedetail mungkin</span>
        </div>
        <div class="row">
            <div class="col-6">
                <label for="country" class="caps">{{ trans('cruds.order.fields.country') }}</label>
                <select class="form-control select2" name="country_id" id="country" disabled required>
                </select>
                <span class="help-block" id="country_load" style="display: none;"><i class="fas fa-spinner fa-spin text-orange"></i>Data negara sedang diambil</span>
            </div>
            <div class="col-6">
                <label for="province" class="caps">{{ trans('cruds.order.fields.province') }}</label>
                <select class="form-control select2" name="province_id" id="province" disabled required>
                </select>
                <span class="help-block" id="province_load" style="display: none;"><i class="fas fa-spinner fa-spin text-orange"></i>Data provinsi sedang diambil</span>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-6">
                <label for="city" class="caps">{{ trans('cruds.order.fields.city') }}</label>
                <select class="form-control select2" name="city_id" id="city" required>
                </select>
                <span class="help-block" id="city_load" style="display: none;"><i class="fas fa-spinner fa-spin text-orange"></i>Data kota sedang diambil</span>
            </div>
            <div class="col-6">
                <label for="district" class="caps">{{ trans('cruds.order.fields.district') }}</label>
                <select class="form-control select2" name="district_id" id="district" required>
                </select>
                <span class="help-block" id="district_load" style="display: none;"><i class="fas fa-spinner fa-spin text-orange"></i>Data kecamatan sedang diambil</span>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-6">
                <label for="subdistrict" class="caps">{{ trans('cruds.order.fields.subdistrict') }}</label>
                <input class="form-control" type="text" name="subdistrict" id="subdistrict" required value="{{ $order->subdistrict ?? ''}}">
            </div>
            <div class="col-6">
                <label for="postal_code" class="caps">{{ trans('cruds.order.fields.postal_code') }}</label>
                <input class="form-control" type="text" name="postal_code" id="postal_code" required value="{{ $order->postal_code ?? ''}}">
            </div>
        </div>
        <hr>
        <div class="form-group">
            <label for="courier" class="caps">{{ trans('cruds.order.fields.courier') }}</label>
            <select class="form-control select2" name="courier" id="courier" required>
            </select>
            <span class="help-block" id="courier_load" style="display: none;"><i class="fas fa-spinner fa-spin text-orange"></i>Data kurir sedang diambil</span>
        </div>
        {{-- <div class="form-group">
            <label for="payment_type" class="caps">{{ trans('cruds.order.fields.payment_type') }}</label>
            <select class="form-control select2" name="payment_type" id="payment_type" required>
                @foreach(\App\Order::PAYMENT_TYPE_SELECT as $key => $paymentType)
                    <option value="{{$key}}">{{$paymentType}}</option>
                @endforeach
            </select>
        </div>  --}}
        <div class="form-group">
            <label for="total" class="caps">{{ trans('cruds.order.fields.total') }}</label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        Rp
                    </span>
                </div>
                <input class="form-control" name="total" id="totalInput" disabled value="{{ $order->total ?? '0' }}">
            </div>
        </div>
        <input type="hidden" value="0" id="totalDocCost" name="doc_cost">
        <div class="row">
            <div class="col-12" style="padding-top: 1rem;">
                <button type="submit" class="btn btn-orange px-4 btn-block caps bold" id="btnFormDoc">
                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true" id="loadingBtn"></span>
                    {{ trans('user.next') }}
                </button>
            </div>
        </div>
    </form>
@endsection

@section('scripts')
    @include('user.create-orders.order-script')
@endsection