@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.create') }} {{ trans('cruds.documentType.title_singular') }}
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route("admin.document-types.store") }}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label class="required" for="name">{{ trans('cruds.documentType.fields.name') }}</label>
                <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" value="{{ old('name', '') }}" required>
                @if($errors->has('name'))
                    <div class="invalid-feedback">
                        {{ $errors->first('name') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.documentType.fields.name_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="price">{{ trans('cruds.documentType.fields.price') }}</label>
                <input class="form-control {{ $errors->has('price') ? 'is-invalid' : '' }}" type="hidden" name="price" id="price" value="{{ old('price', '') }}" required>
                <input class="form-control {{ $errors->has('price') ? 'is-invalid' : '' }}" type="text" name="price_str" id="price_str" value="{{ old('price', '') }}" required>
                @if($errors->has('price'))
                    <div class="invalid-feedback">
                        {{ $errors->first('price') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.documentType.fields.price_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="weight">{{ trans('cruds.documentType.fields.weight') }}</label>
                <input class="form-control {{ $errors->has('weight') ? 'is-invalid' : '' }}" type="hidden" name="weight" id="weight" value="{{ old('weight', '') }}" required>
                <input class="form-control {{ $errors->has('weight') ? 'is-invalid' : '' }}" type="text" name="weight_str" id="weight_str" value="{{ old('weight', '') }}" required>
                @if($errors->has('weight'))
                    <div class="invalid-feedback">
                        {{ $errors->first('weight') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.documentType.fields.weight_helper') }}</span>
            </div>
            <div class="form-group">
                <label>
                    {{ trans('cruds.documentType.fields.is_for_student') }}&nbsp;&nbsp;
                    <input type="checkbox" id="is_for_student" name="is_for_student" data-toggle="toggle" data-on="Ya" data-off="Tidak">
                </label>
            </div>
            <div class="form-group">
                <label>
                    {{ trans('cruds.documentType.fields.is_for_alumni') }}&nbsp;&nbsp;
                    <input type="checkbox" id="is_for_alumni" name="is_for_alumni" data-toggle="toggle" data-on="Ya" data-off="Tidak">
                </label>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

@section('scripts')
@parent
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<script>
$(function () {
    numberFormat('price')
    numberFormat('weight')

    $('#price_str').keyup(function () {
        numberFormat('price')
    })

    $('#weight_str').keyup(function () {
        numberFormat('weight')
    })
})

function numberFormat(inputId) {
    let num = $('#' + inputId + '_str').val()
    num = num.toString().replace(/\D+/g, '')
    $('#' + inputId).val(num)
    $('#' + inputId + '_str').val(num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
}
</script>
@endsection