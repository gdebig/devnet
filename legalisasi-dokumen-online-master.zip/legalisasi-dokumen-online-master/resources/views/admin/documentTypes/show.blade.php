@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.show') }} {{ trans('cruds.documentType.title') }}
    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.document-types.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.documentType.fields.name') }}
                        </th>
                        <td>
                            {{ $documentType->name }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.documentType.fields.price') }}
                        </th>
                        <td>
                            {{ $documentType->price ? preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', (int) $documentType->price . "") : '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.documentType.fields.weight') }}
                        </th>
                        <td>
                            {{ $documentType->weight ? preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', $documentType->weight . "") : '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.documentType.fields.is_for_student') }}
                        </th>
                        <td>
                            {{ $documentType->is_for_student ? 'Ya' : 'Tidak' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.documentType.fields.is_for_alumni') }}
                        </th>
                        <td>
                            {{ $documentType->is_for_alumni ? 'Ya' : 'Tidak' }}
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.document-types.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
        </div>
    </div>
</div>



@endsection