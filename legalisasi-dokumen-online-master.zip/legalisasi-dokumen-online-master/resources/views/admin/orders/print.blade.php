<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Cetak Alamat Pengiriman</title>

    <style>
    @media print {
        @page { margin: 0; }
        body { margin: 1.6cm; }
    }
    </style>
</head>

<body>
    <div style="width: 50%; border-style: solid; border-width: 1px; padding: 12px;">
        <u>Tujuan:</u><br/><br/>
        <strong>{{ $order->user->name }} </strong><br/>
        <p>{{ $address }}</p>
        <p>Nomor Handphone: {{ $order->user->phone_number }}</p>
        <hr/>
        <u>Pengirim:</u><br/><br/>
        <strong>Pusat Administrasi Fakultas Teknik Universitas Indonesia</strong>
        <p>Gedung GK Lantai 1 Fakultas Teknik UI</p>
        <p>Telepon: 6221-78887861</p>
        <hr/>
        <u>Pesanan:</u>
        <ul>
            @foreach($order->orderItems as $item)
            <li>{{ $item->amount }} {{ $item->document_type->name }}</li>
            @endforeach
        </ul>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
    $(function () {
        window.print()
    })
    </script>
</body>

</html>