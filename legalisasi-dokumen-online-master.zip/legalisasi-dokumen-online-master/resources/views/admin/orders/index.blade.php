@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.list') }} {{ trans('cruds.order.title_singular') }}
        @if($alreadyPaidOrder > 0)
        <div class="float-right">
            <button id="btn-already-paid" class="btn btn-danger"><span class="badge badge-light">{{ $alreadyPaidOrder }}</span>&nbsp;{{ trans('cruds.order.paid_alert') }}</button>
        </div>
        @endif
    </div>

    <div class="card-body">
        <div class="row">
            <div class="col-md-2">
                <div class="form-group">
                    <div class="input-group">
                        <input type="text" class="form-control" id="start-date" placeholder="Tanggal Awal">
                        <div class="input-group-append">
                            <span class="input-group-text">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <div class="input-group">
                        <input type="text" class="form-control" id="end-date" placeholder="Tanggal Akhir">
                        <div class="input-group-append">
                            <span class="input-group-text">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <select name="status" id="status" class="form-control">
                        <option value selected>{{ trans('cruds.order.fields.status') }}</option>
                        @foreach(App\Order::STATUS_SELECT as $key => $label)
                        <option value="{{ $key }}">{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <select name="payment-type" id="payment-type" class="form-control">
                        <option value selected>{{ trans('cruds.order.fields.payment_type') }}</option>
                        @foreach(App\Order::PAYMENT_TYPE_SELECT as $key => $label)
                        <option value="{{ $key }}">{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <select name="courier" id="courier" class="form-control">
                        <option value selected>{{ trans('cruds.order.fields.courier') }}</option>
                        @foreach(App\Order::COURIER_SELECT as $key => $label)
                        <option value="{{ $key }}">{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <button class="btn btn-info btn-block" id="filter">{{ trans('global.filter') }}</button>
            </div>
        </div>
        <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-Order">
            <thead>
                <tr>
                    <th width="10">

                    </th>
                    <th>
                        {{ trans('cruds.order.fields.order_number') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.document_type') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.amount') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.user') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.student_number') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.study_program') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.shipping_type') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.destination_type') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.courier') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.payment_type') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.total') }}
                    </th>
                    <th>
                        {{ trans('cruds.order.fields.status') }}
                    </th>
                    <th>
                        &nbsp;
                    </th>
                    <th></th>
                </tr>
            </thead>
        </table>
    </div>
</div>



@endsection
@section('scripts')
@parent
<script>
let orderTable

$(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

  let dtOverrideGlobals = {
    buttons: dtButtons,
    processing: true,
    serverSide: true,
    retrieve: true,
    aaSorting: [],
    ajax: "{{ route('admin.orders.index') }}",
    columns: [
        { data: 'placeholder', name: 'placeholder' },
        { data: 'order_number', name: 'order_number', searchable: true },
        { data: 'document_types', name: 'document_types', sortable: false },
        { data: 'amount', name: 'amount', sortable: false },
        { data: 'user.name', name: 'user.name', sortable: false },
        { data: 'user.student_number', name: 'user.student_number', sortable: false },
        { data: 'user.study_program', name: 'user.study_program', sortable: false },
        { data: 'shipping_type', name: 'shipping_type', searchable: false },
        { data: 'destination_type', name: 'destination_type', searchable: false },
        { data: 'courier', name: 'courier', searchable: false },
        { data: 'payment_type', name: 'payment_type', searchable: false },
        { data: 'total', name: 'total', searchable: false, sortable: false },
        { data: 'status', name: 'status', searchable: false },
        { data: 'actions', name: '{{ trans('global.actions') }}', sortable: false, searchable: false },
        { data: 'updated_at', name: 'updated_at', sortable: true, visible: false, searchable: false },
    ],
    orderCellsTop: true,
    order: [[ 14, 'desc' ]],
    pageLength: 10,
  };
  orderTable = $('.datatable-Order').DataTable(dtOverrideGlobals);
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });

  $('#start-date').datetimepicker({
      format: 'YYYY-MM-DD'
  })

  $('#end-date').datetimepicker({
      format: 'YYYY-MM-DD'
  })

  $("#start-date").on("dp.change", function (e) {
    $('#end-date').data("DateTimePicker").minDate(e.date);
  });

  $("#end-date").on("dp.change", function (e) {
    $('#start-date').data("DateTimePicker").maxDate(e.date);
  });

  $('#filter').click(function() {
    let startDate = $('#start-date').val()
    let endDate = $('#end-date').val()
    let status = $('#status').val()
    let paymentType = $('#payment-type').val()
    let courier = $('#courier').val()

    filter(startDate, endDate, status, paymentType, courier)
  })

  $('#btn-already-paid').click(function () {
    $('#start-date').val('')
    $('#end-date').val('')
    $('#status option[value={{ \App\Order::PAID_ID  }}]').prop('selected', true)
    $('#payment-type option[value=""').prop('selected', true)
    $('#courier option[value=""').prop('selected', true)
    $('#filter').click()
  })

  if (getUrlParam('paid') == true) {
    $('#btn-already-paid').click()
  }
  
});

function filter(startDate, endDate, status, paymentType, courier) {
    orderTable.ajax.url('{{ route('admin.orders.index') }}?startDate=' + startDate 
        + '&endDate=' + endDate + '&status=' + status + '&paymentType=' + paymentType + '&courier=' + courier).load()
}

</script>
@endsection