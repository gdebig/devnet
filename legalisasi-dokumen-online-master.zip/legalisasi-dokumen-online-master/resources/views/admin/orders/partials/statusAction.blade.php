@can('order_edit')
    @if($row->status != \App\Order::FINISH_ID && $row->status != \App\Order::NOT_YET_PAID_ID)
    <button type="button" class="btn btn-xs btn-success" data-toggle="modal" data-target="#statusModal{{ $row->id }}">{{ trans('cruds.order.update_status') }}</button>
    <div class="modal fade" id="statusModal{{ $row->id }}" tabindex="-1" role="dialog" aria-labelledby="statusModal{{ $row->id }}Label" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="statusModal{{ $row->id }}Label">{{ $row->order_number }}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('admin.orders.status', $row->id) }}" method="POST" style="display: inline-block;">
                    @method('PUT')
                    @csrf
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="required">{{ trans('cruds.order.fields.status') }}</label>
                            <select class="form-control" name="status" id="status{{ $row->order_number }}" required>
                                <option value disabled {{ old('type', null) === null ? 'selected' : '' }}>{{ trans('global.pleaseSelect') }}</option>
                                @foreach($selectableStatus as $key => $label)
                                <option value="{{ $key }}" {{ old('type', '1') === (string) $key ? 'selected' : '' }}>{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" id="receipt-group{{ $row->order_number }}">
                            <label class="required" id="receipt-label{{ $row->order_number }}" for="receipt">{{ trans('cruds.order.fields.receipt_number') }}</label>
                            <input name="receipt_number" id="receipt{{ $row->order_number }}" class="form-control" required>
                        </div>
                        <div class="form-group" id="reason-group{{ $row->order_number }}">
                            <label class="required" id="reason-label{{ $row->order_number }}" for="reason">{{ trans('cruds.order.fields.reason') }}</label>
                            <textarea name="reason" id="reason{{ $row->order_number }}" class="form-control" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-danger">{{ trans('global.edit') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endif
    @if($row->status != \App\Order::PAID_ID && $row->status != \App\Order::NOT_YET_PAID_ID)
    <form action="{{ route('admin.orders.status.undo', $row->id) }}" method="POST" style="display: inline-block;">
        @method('PUT')
        @csrf
        <input type="submit" class="btn btn-xs btn-warning" value="{{ trans('global.undo') }}">
    </form>
    @endif
@endcan

<script>
$(function() {
    $('#reason{{ $row->order_number }}').removeAttr('required')
    $('#reason-label{{ $row->order_number }}').removeClass('required')
    $('#reason-group{{ $row->order_number }}').hide()

    $('#receipt{{ $row->order_number }}').removeAttr('required')
    $('#receipt-label{{ $row->order_number }}').removeClass('required')
    $('#receipt-group{{ $row->order_number }}').hide()

    $('#status{{ $row->order_number }}').change(function () {
        if ($(this).val() == {{ \App\Order::ORDER_PROBLEM_ID }}) {
            $('#reason{{ $row->order_number }}').attr('required', '')
            $('#reason-label{{ $row->order_number }}').addClass('required')
            $('#reason-group{{ $row->order_number }}').show()
        } else if ($(this).val() == {{ \App\Order::ON_DELIVERY_ID }}) {
            $('#receipt{{ $row->order_number }}').attr('required', '')
            $('#receipt-label{{ $row->order_number }}').addClass('required')
            $('#receipt-group{{ $row->order_number }}').show()
        } else {
            $('#reason{{ $row->order_number }}').html('')
            $('#reason{{ $row->order_number }}').removeAttr('required')
            $('#reason-label{{ $row->order_number }}').removeClass('required')
            $('#reason-group{{ $row->order_number }}').hide()

            $('#receipt{{ $row->order_number }}').val('')
            $('#receipt{{ $row->order_number }}').removeAttr('required')
            $('#receipt-label{{ $row->order_number }}').removeClass('required')
            $('#receipt-group{{ $row->order_number }}').hide()
        }
    })
})
</script>