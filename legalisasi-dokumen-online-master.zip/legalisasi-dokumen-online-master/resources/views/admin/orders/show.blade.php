@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.show') }} {{ trans('cruds.order.title') }}
    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.orders.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.order_number') }}
                        </th>
                        <td>
                            {{ $order->order_number }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.shipping_type') }}
                        </th>
                        <td>
                            {{ $order->shipping_type ? \App\Order::SHIPPING_TYPE_SELECT[$order->shipping_type] : '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.destination_type') }}
                        </th>
                        <td>
                            {{ $order->destination_type ? \App\Order::DESTINATION_TYPE_SELECT[$order->destination_type] : '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.courier') }}
                        </th>
                        <td>
                            {{ \App\Order::COURIER_SELECT[$order->courier] ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.receipt_number') }}
                        </th>
                        <td>
                            {{ $order->receipt_number }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.payment_type') }}
                        </th>
                        <td>
                            {{ \App\Order::PAYMENT_TYPE_SELECT[$order->payment_type] ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.shipping_address') }}
                        </th>
                        <td>
                            {{ $order->shipping_address }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.shipping_cost') }}
                        </th>
                        <td>
                            {{ preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', (int) $order->shipping_cost . "") }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.total') }}
                        </th>
                        <td>
                            {{ preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', (int) $order->total . "") }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.status') }}
                        </th>
                        <td>
                            {{ $order->status ? \App\Order::STATUS_SELECT[$order->status] : '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.user') }}
                        </th>
                        <td>
                            {{ $order->user->name ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.student_number') }}
                        </th>
                        <td>
                            {{ $order->user->student_number ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.study_program') }}
                        </th>
                        <td>
                            {{ $order->user->study_program ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.notes') }}
                        </th>
                        <td>
                            {{ $order->notes }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.created_at') }}
                        </th>
                        <td>
                            {{ $order->created_at ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.paid_at') }}
                        </th>
                        <td>
                            {{ $order->paid_at ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.processed_at') }}
                        </th>
                        <td>
                            {{ $order->processed_at ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.delivered_at') }}
                        </th>
                        <td>
                            {{ $order->delivered_at ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.finished_at') }}
                        </th>
                        <td>
                            {{ $order->finished_at ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.review') }}
                        </th>
                        <td>
                            {{ $order->review }}
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.orders.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
                @can('order_edit')
                @if($order->status != \App\Order::FINISH_ID && $order->status != \App\Order::NOT_YET_PAID_ID)
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#statusModal{{ $order->id }}">{{ trans('cruds.order.update_status') }}</button>
                <div class="modal fade" id="statusModal{{ $order->id }}" tabindex="-1" role="dialog" aria-labelledby="statusModal{{ $order->id }}Label" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="statusModal{{ $order->id }}Label">{{ $order->order_number }}</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="{{ route('admin.orders.status', $order->id) }}" method="POST" style="display: inline-block;">
                                @method('PUT')
                                @csrf
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="required">{{ trans('cruds.order.fields.status') }}</label>
                                        <select class="form-control" name="status" id="status{{ $order->order_number }}" required>
                                            <option value disabled {{ old('type', null) === null ? 'selected' : '' }}>{{ trans('global.pleaseSelect') }}</option>
                                            @foreach($selectableStatus as $key => $label)
                                            <option value="{{ $key }}" {{ old('type', '1') === (string) $key ? 'selected' : '' }}>{{ $label }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="form-group" id="receipt-group{{ $order->order_number }}">
                                        <label class="required" id="receipt-label{{ $order->order_number }}" for="receipt">{{ trans('cruds.order.fields.receipt_number') }}</label>
                                        <input name="receipt_number" id="receipt{{ $order->order_number }}" class="form-control" required>
                                    </div>
                                    <div class="form-group" id="reason-group{{ $order->order_number }}">
                                        <label class="required" id="reason-label{{ $order->order_number }}" for="reason">{{ trans('cruds.order.fields.reason') }}</label>
                                        <textarea name="reason" id="reason{{ $order->order_number }}" class="form-control" required></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-danger">{{ trans('global.edit') }}</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @endif
                @if($order->status != \App\Order::PAID_ID && $order->status != \App\Order::NOT_YET_PAID_ID)
                <form action="{{ route('admin.orders.status.undo', $order->id) }}" method="POST" style="display: inline-block;">
                    @method('PUT')
                    @csrf
                    <input type="submit" class="btn btn-warning" value="{{ trans('global.undo') }}">
                </form>
                @endif
                @endcan
                <div class="float-right">
                    <a class="btn btn-danger" id="btn-print" href="{{ route('admin.orders.print', ['order' => $order->id]) }}" target="_blank">
                        <i class="fa fa-print" aria-hidden="true"></i>
                        {{ trans('global.print') }}
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

@section('scripts')
<script>
$(function() {
    $('#reason{{ $order->order_number }}').removeAttr('required')
    $('#reason-label{{ $order->order_number }}').removeClass('required')
    $('#reason-group{{ $order->order_number }}').hide()

    $('#receipt{{ $order->order_number }}').removeAttr('required')
    $('#receipt-label{{ $order->order_number }}').removeClass('required')
    $('#receipt-group{{ $order->order_number }}').hide()

    $('#status{{ $order->order_number }}').change(function () {
        if ($(this).val() == {{ \App\Order::ORDER_PROBLEM_ID }}) {
            $('#reason{{ $order->order_number }}').attr('required', '')
            $('#reason-label{{ $order->order_number }}').addClass('required')
            $('#reason-group{{ $order->order_number }}').show()
        } else if ($(this).val() == {{ \App\Order::ON_DELIVERY_ID }}) {
            $('#receipt{{ $order->order_number }}').attr('required', '')
            $('#receipt-label{{ $order->order_number }}').addClass('required')
            $('#receipt-group{{ $order->order_number }}').show()
        } else {
            $('#reason{{ $order->order_number }}').html('')
            $('#reason{{ $order->order_number }}').removeAttr('required')
            $('#reason-label{{ $order->order_number }}').removeClass('required')
            $('#reason-group{{ $order->order_number }}').hide()

            $('#receipt{{ $order->order_number }}').val('')
            $('#receipt{{ $order->order_number }}').removeAttr('required')
            $('#receipt-label{{ $order->order_number }}').removeClass('required')
            $('#receipt-group{{ $order->order_number }}').hide()
        }
    })
})
</script>
@endsection

<div class="card">
    <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
        <li class="nav-item">
            <a class="nav-link active" href="#order_order_items" role="tab" data-toggle="tab">
                {{ trans('cruds.orderItem.title') }}
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#order_status_histories" role="tab" data-toggle="tab">
                {{ trans('cruds.orderStatusHistory.title') }}
            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane active" role="tabpanel" id="order_order_items">
            @includeIf('admin.orders.relationships.orderOrderItems', ['orderItems' => $order->orderItems])
        </div>
        <div class="tab-pane" role="tabpanel" id="order_status_histories">
            @includeIf('admin.orders.relationships.orderStatusHistories', ['orderStatusHistories' => $order->orderStatusHistories])
        </div>
    </div>
</div>

@endsection