<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-orderOrderItems">
                <thead>
                    <tr>
                        <th>
                            {{ trans('cruds.orderItem.fields.document_type') }}
                        </th>
                        <th>
                            {{ trans('cruds.orderItem.fields.amount') }}
                        </th>
                        <th>
                            {{ trans('cruds.orderItem.fields.total') }}
                        </th>
                        <th>
                            {{ trans('cruds.orderItem.fields.order') }}
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($orderItems as $key => $orderItem)
                        <tr data-entry-id="{{ $orderItem->id }}">
                            <td>
                                {{ $orderItem->document_type->name ?? '' }}
                            </td>
                            <td>
                                {{ $orderItem->amount ?? '' }}
                            </td>
                            <td>
                                {{ $orderItem->total ?? '' }}
                            </td>
                            <td>
                                {{ $orderItem->order->order_number ?? '' }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@section('scripts')
@parent
<script>
$(function () {

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 4, 'desc' ]],
    pageLength: 10,
  });
  let table = $('.datatable-orderOrderItems:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
@endsection