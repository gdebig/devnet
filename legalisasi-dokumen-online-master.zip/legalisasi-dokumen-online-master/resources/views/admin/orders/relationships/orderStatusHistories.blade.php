<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-orderStatusHistories">
                <thead>
                    <tr>
                        <th>
                            {{ trans('cruds.orderStatusHistory.fields.status') }}
                        </th>
                        <th>
                            {{ trans('cruds.orderStatusHistory.fields.reason') }}
                        </th>
                        <th>
                            {{ trans('cruds.orderStatusHistory.fields.created_at') }}
                        </th>
                        <th>
                            {{ trans('cruds.orderStatusHistory.fields.updated_by') }}
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($orderStatusHistories as $key => $orderStatusHistory)
                        <tr>
                            <td>
                                {{ $orderStatusHistory->status ? \App\Order::STATUS_SELECT[$orderStatusHistory->status] : '' }}
                            </td>
                            <td>
                                {{ $orderStatusHistory->reason ?? '' }}
                            </td>
                            <td>
                                {{ $orderStatusHistory->created_at }}
                            </td>
                            <td>
                                {{ $orderStatusHistory->user ? $orderStatusHistory->user->name : 'System' }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@section('scripts')
@parent
<script>
$(function () {

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 0, 'desc' ]],
    pageLength: 10,
  });
  let table = $('.datatable-orderStatusHistories:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
@endsection