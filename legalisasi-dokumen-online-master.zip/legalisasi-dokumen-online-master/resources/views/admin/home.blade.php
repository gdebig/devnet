@extends('layouts.admin')
@section('content')
<div class="content">
    @can('dashboard_access')
    
    @if($alreadyPaidOrder > 0)
    <div class="alert alert-info">
        <div class="row">
            <div class="col">
                <h5><span class="badge badge-danger">{{ $alreadyPaidOrder }}</span>&nbsp;{{ trans('cruds.order.paid_alert') }}</h5>
            </div>
            <div class="col">
                <div class="float-right"><a href="{{ route('admin.orders.index', ['paid' => true]) }}" class="btn btn-danger">{{ trans('cruds.order.go_to_order') }}</a></div>
            </div>
        </div>
    </div>
    @endif

    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    {{ trans('cruds.dashboard.trend_chart') }}
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="input-group">
                                <select class="form-control" id="tren-filter-type">
                                    <option value="all" selected>{{ trans('cruds.dashboard.all') }}</option>
                                    <option value="this-week">{{ trans('cruds.dashboard.this_week') }}</option>
                                    <option value="this-month">{{ trans('cruds.dashboard.this_month') }}</option>
                                    <option value="this-year">{{ trans('cruds.dashboard.this_year') }}</option>
                                    <option value="custom">{{ trans('cruds.dashboard.custom') }}</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="input-group">
                                <input type="text" class="form-control" id="tren-filter-start" placeholder="{{ trans('cruds.dashboard.start_date') }}" disabled>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="fa-fw fas fa-calendar"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="input-group">
                                <input type="text" class="form-control" id="tren-filter-end" placeholder="{{ trans('cruds.dashboard.end_date') }}" disabled>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="fa-fw fas fa-calendar"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                    <canvas id="tren-chart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    {{ trans('cruds.dashboard.trend_chart_pie') }}
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="input-group">
                                <select class="form-control" id="pie-filter-type">
                                    <option value="all" selected>{{ trans('cruds.dashboard.all') }}</option>
                                    <option value="this-week">{{ trans('cruds.dashboard.this_week') }}</option>
                                    <option value="this-month">{{ trans('cruds.dashboard.this_month') }}</option>
                                    <option value="this-year">{{ trans('cruds.dashboard.this_year') }}</option>
                                    <option value="custom">{{ trans('cruds.dashboard.custom') }}</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="input-group">
                                <input type="text" class="form-control" id="pie-filter-start" placeholder="{{ trans('cruds.dashboard.start_date') }}" disabled>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="fa-fw fas fa-calendar"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="input-group">
                                <input type="text" class="form-control" id="pie-filter-end" placeholder="{{ trans('cruds.dashboard.end_date') }}" disabled>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="fa-fw fas fa-calendar"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                    <canvas id="pie-tren-chart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    {{ trans('cruds.dashboard.sla_report') }}
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="input-group">
                                <select class="form-control" id="sla-filter-type">
                                    <option value="all" selected>{{ trans('cruds.dashboard.all') }}</option>
                                    <option value="this-week">{{ trans('cruds.dashboard.this_week') }}</option>
                                    <option value="this-month">{{ trans('cruds.dashboard.this_month') }}</option>
                                    <option value="this-year">{{ trans('cruds.dashboard.this_year') }}</option>
                                    <option value="custom">{{ trans('cruds.dashboard.custom') }}</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="input-group">
                                <input type="text" class="form-control" id="sla-filter-start" placeholder="{{ trans('cruds.dashboard.start_date') }}" disabled>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="fa-fw fas fa-calendar"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="input-group">
                                <input type="text" class="form-control" id="sla-filter-end" placeholder="{{ trans('cruds.dashboard.end_date') }}" disabled>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="fa-fw fas fa-calendar"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    {{ trans('cruds.dashboard.grand_order') }}
                                </div>
                                <div class="card-body">
                                    <h1 id="grand-order">0</h1>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    {{ trans('cruds.dashboard.grand_exemplar') }}
                                </div>
                                <div class="card-body">
                                    <h1 id="grand-exemplar">0</h1>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    {{ trans('cruds.dashboard.grand_rev') }}
                                </div>
                                <div class="card-body">
                                    <h1 id="grand-rev">0</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <table class="table table-bordered table-striped table-hover" id="sla-table">
                        <thead>
                            <tr>
                                <th>{{ trans('cruds.dashboard.document_type') }}</th>
                                <th>{{ trans('cruds.dashboard.total_order') }}</th>
                                <th>{{ trans('cruds.dashboard.total_exemplar') }}</th>
                                <th>{{ trans('cruds.dashboard.total_rev') }}</th>
                                <th>{{ trans('cruds.dashboard.fastest_service') }}</th>
                                <th>{{ trans('cruds.dashboard.slowest_service') }}</th>
                                <th>{{ trans('cruds.dashboard.avg_service') }}</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    @endcan
</div>
@endsection

@section('scripts')
@parent
@can('order_access')
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
<script>

let trenChart = null
let pieTrenChart = null

$(function () {
    initTrenFilter()
    initTrenChart()

    initPieFilter()
    initPieChart()

    initSLAFilter()
    initSLAReport()
})

function initTrenFilter() {
    $('#tren-filter-start').datetimepicker({
        format: 'YYYY-MM-DD',
        useCurrent: false
    });

    $('#tren-filter-end').datetimepicker({
        format: 'YYYY-MM-DD',
        useCurrent: false
    });

    $('#tren-filter-start').on('dp.change', function (e) {
        $('#tren-filter-end').data('DateTimePicker').minDate(e.date);
        getTrenChartData($('#tren-filter-start').val(), $('#tren-filter-end').val())
    });

    $('#tren-filter-end').on("dp.change", function (e) {
        $('#tren-filter-start').data('DateTimePicker').maxDate(e.date);
        getTrenChartData($('#tren-filter-start').val(), $('#tren-filter-end').val())
    });

    $('#tren-filter-type').change(function () {
        if ($(this).val() == 'all') {
            $('#tren-filter-start').val('')
            $('#tren-filter-end').val('')

            $('#tren-filter-start').prop('disabled', true)
            $('#tren-filter-end').prop('disabled', true)

            getTrenChartData($('#tren-filter-start').val(), $('#tren-filter-end').val())
        } else if ($(this).val() == 'custom') {
            $('#tren-filter-start').prop('disabled', false)
            $('#tren-filter-end').prop('disabled', false)
        } else {
            setFilterDateByFilterType($(this).val(), 'tren-filter-start', 'tren-filter-end')

            $('#tren-filter-start').prop('disabled', true)
            $('#tren-filter-end').prop('disabled', true)

            getTrenChartData($('#tren-filter-start').val(), $('#tren-filter-end').val())
        }
    })
}

function initPieFilter() {
    $('#pie-filter-start').datetimepicker({
        format: 'YYYY-MM-DD',
        useCurrent: false
    });

    $('#pie-filter-end').datetimepicker({
        format: 'YYYY-MM-DD',
        useCurrent: false
    });

    $('#pie-filter-start').on('dp.change', function (e) {
        $('#pie-filter-end').data('DateTimePicker').minDate(e.date);
        getPieChartData($('#pie-filter-start').val(), $('#pie-filter-end').val())
    });

    $('#pie-filter-end').on("dp.change", function (e) {
        $('#pie-filter-start').data('DateTimePicker').maxDate(e.date);
        getPieChartData($('#pie-filter-start').val(), $('#pie-filter-end').val())
    });

    $('#pie-filter-type').change(function () {
        if ($(this).val() == 'all') {
            $('#pie-filter-start').val('')
            $('#pie-filter-end').val('')

            $('#pie-filter-start').prop('disabled', true)
            $('#pie-filter-end').prop('disabled', true)

            getPieChartData($('#pie-filter-start').val(), $('#pie-filter-end').val())
        } else if ($(this).val() == 'custom') {
            $('#pie-filter-start').prop('disabled', false)
            $('#pie-filter-end').prop('disabled', false)
        } else {
            setFilterDateByFilterType($(this).val(), 'pie-filter-start', 'pie-filter-end')

            $('#pie-filter-start').prop('disabled', true)
            $('#pie-filter-end').prop('disabled', true)

            getPieChartData($('#pie-filter-start').val(), $('#pie-filter-end').val())
        }
    })
}

function initSLAFilter() {
    $('#sla-filter-start').datetimepicker({
        format: 'YYYY-MM-DD',
        useCurrent: false
    });

    $('#sla-filter-end').datetimepicker({
        format: 'YYYY-MM-DD',
        useCurrent: false
    });

    $('#sla-filter-start').on('dp.change', function (e) {
        $('#sla-filter-end').data('DateTimePicker').minDate(e.date);
        generateSLAReport($('#sla-filter-start').val(), $('#sla-filter-end').val())
    });

    $('#sla-filter-end').on("dp.change", function (e) {
        $('#sla-filter-start').data('DateTimePicker').maxDate(e.date);
        generateSLAReport($('#sla-filter-start').val(), $('#sla-filter-end').val())
    });

    $('#sla-filter-type').change(function () {
        if ($(this).val() == 'all') {
            $('#sla-filter-start').val('')
            $('#sla-filter-end').val('')

            $('#sla-filter-start').prop('disabled', true)
            $('#sla-filter-end').prop('disabled', true)

            generateSLAReport($('#sla-filter-start').val(), $('#sla-filter-end').val())
        } else if ($(this).val() == 'custom') {
            $('#sla-filter-start').prop('disabled', false)
            $('#sla-filter-end').prop('disabled', false)
        } else {
            setFilterDateByFilterType($(this).val(), 'sla-filter-start', 'sla-filter-end')

            $('#sla-filter-start').prop('disabled', true)
            $('#sla-filter-end').prop('disabled', true)

            generateSLAReport($('#sla-filter-start').val(), $('#sla-filter-end').val())
        }
    })
}

function initTrenChart() {
    const ctxTren = document.getElementById('tren-chart').getContext('2d')
    trenChart = new Chart(ctxTren, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                data: [],
                borderColor: ['rgba(255, 159, 64, 0.2)'],
                backgroundColor: ['rgba(0, 0, 0, 0.0)'],
                borderWidth: 3
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            },
            legend: {
                display: false
            }
        }
    });

    $('#tren-filter-type').val('this-month')
    $('#tren-filter-type').trigger('change')
    getTrenChartData($('#tren-filter-start').val(), $('#tren-filter-end').val())
}

function initPieChart() {
    const ctxPieTren = document.getElementById('pie-tren-chart').getContext('2d')
    pieTrenChart = new Chart(ctxPieTren, {
        type: 'pie',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [],
                borderColor: [],
                borderWidth: 1
            }]
        },
        options: {
            legend: {
                display: false
            }
        }
    });

    $('#pie-filter-type').val('this-month')
    $('#pie-filter-type').trigger('change')
    getPieChartData($('#pie-filter-start').val(), $('#pie-filter-end').val())
}

function initSLAReport() {
    $('#sla-filter-type').val('this-month')
    $('#sla-filter-type').trigger('change')
    generateSLAReport($('#sla-filter-start').val(), $('#sla-filter-end').val())
}

function getTrenChartData(start, end) {
    $.ajax({
        method: 'GET',
        url: '{{ route('admin.trenChart') }}?startDate=' + start + '&endDate=' + end,
    })
    .done(function (datas) {
        generateTrenChart(datas.totals, datas.labels)
    })
}

function getPieChartData(start, end) {
    $.ajax({
        method: 'GET',
        url: '{{ route('admin.orderByType') }}?startDate=' + start + '&endDate=' + end,
    })
    .done(function (datas) {
        generatePieTrenChart(datas.totals, datas.labels, datas.colors, datas.borders)
    })
}

function generateSLAReport(start, end) {
    $.ajax({
        method: 'GET',
        url: '{{ route('admin.slaReport') }}?startDate=' + start + '&endDate=' + end,
    })
    .done(function (datas) {
        generateGrandTotal(datas.grand_total_order, datas.grand_total_exemplar, datas.grand_total_rev)
        generateSLATable(datas.data)
    })
}

function generateSLATable(data) {
    let tbodyData = ''
    $('#sla-table>tbody').html(tbodyData)
    
    for (i = 0; i < data.length; ++i) {
        tbodyData += '<tr><td>' + data[i].document_type + '</td>'
            + '<td>' + data[i].total + '</td>'
            + '<td>' + data[i].total_amount + '</td>'
            + '<td>' + data[i].total_rev + '</td>'
            + '<td>' + data[i].min + '</td>'
            + '<td>' + data[i].max + '</td>'
            + '<td>' + data[i].avg + '</td></tr>'
    }

    $('#sla-table>tbody').html(tbodyData)
}

function generateGrandTotal(grandOrder, grandExemplar, grandRev) {
    $('#grand-order').html(grandOrder)
    $('#grand-exemplar').html(grandExemplar)
    $('#grand-rev').html(grandRev)
}

function generateTrenChart(datas, labels) {
    trenChart.data.labels = labels;
    trenChart.data.datasets.forEach((dataset) => {
        dataset.data = datas
    })
    trenChart.update()
}

function generatePieTrenChart(datas, labels, colors, borders) {
    pieTrenChart.data.labels = labels;
    pieTrenChart.data.datasets.forEach((dataset) => {
        dataset.data = datas
        dataset.backgroundColor = colors
        dataset.borderColor = borders
    })
    pieTrenChart.update()
}

function setFilterDateByFilterType(type, startId, endId) {
    if (type == 'this-week') {
        let date = new Date // get current date
        let first = date.getDate() - date.getDay();
        let last = first + 6;

        let firstDate = new Date(date.getFullYear(), date.getMonth(), first)
        first = firstDate.getDate()
        let startMonth = new Intl.DateTimeFormat('en', { month: '2-digit' }).format(firstDate)
        let startYear = firstDate.getFullYear()

        let lastDate = new Date(date.getFullYear(), date.getMonth(), last)
        last = lastDate.getDate()
        let endMonth = new Intl.DateTimeFormat('en', { month: '2-digit' }).format(lastDate)
        let endYear = lastDate.getFullYear()

        $('#' + startId).val(startYear + '-' + startMonth + '-' + (first < 10 ? '0' + first : first))
        $('#' + endId).val(endYear + '-' + endMonth + '-' + (last < 10 ? '0' + last : last))
    } else if (type == 'this-month') {
        let date = new Date
        let firstDay = new Date(date.getFullYear(), date.getMonth(), 1)
        let lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0)

        let first = firstDay.getDate()
        let last = lastDay.getDate()

        let year = new Intl.DateTimeFormat('en', { year: 'numeric' }).format(date)
        let month = new Intl.DateTimeFormat('en', { month: '2-digit' }).format(date)

        $('#' + startId).val(year + '-' + month + '-' + (first < 10 ? '0' + first : first))
        $('#' + endId).val(year + '-' + month + '-' + (last < 10 ? '0' + last : last))
    } else if (type == 'this-year') {
        let date = new Date
        let year = date.getFullYear()

        $('#' + startId).val(year + '-01-01')
        $('#' + endId).val(year + '-12-31')
    }
}

</script>
@endcan
@endsection