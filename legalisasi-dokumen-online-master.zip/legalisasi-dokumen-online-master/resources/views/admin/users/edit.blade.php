@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.user.title_singular') }}
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route("admin.users.update", [$user->id]) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-group">
                <label class="required" for="name">{{ trans('cruds.user.fields.name') }}</label>
                <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" value="{{ old('name', $user->name) }}" required>
                @if($errors->has('name'))
                    <div class="invalid-feedback">
                        {{ $errors->first('name') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.name_helper') }}</span>
            </div>
            <div class="form-group">
                <label>{{ trans('cruds.user.fields.type') }}</label>
                <select class="form-control {{ $errors->has('type') ? 'is-invalid' : '' }}" name="type" id="type">
                    <option value disabled {{ old('type', null) === null ? 'selected' : '' }}>{{ trans('global.pleaseSelect') }}</option>
                    @foreach(App\User::TYPE_SELECT as $key => $label)
                        <option value="{{ $key }}" {{ old('type', $user->type) === $key ? 'selected' : '' }}>{{ $label }}</option>
                    @endforeach
                </select>
                @if($errors->has('type'))
                    <div class="invalid-feedback">
                        {{ $errors->first('type') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.type_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="student_number">{{ trans('cruds.user.fields.student_number') }}</label>
                <input class="form-control {{ $errors->has('student_number') ? 'is-invalid' : '' }}" type="text" name="student_number" id="student_number" value="{{ old('student_number', $user->student_number) }}">
                @if($errors->has('student_number'))
                    <div class="invalid-feedback">
                        {{ $errors->first('student_number') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.student_number_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="study_program">{{ trans('cruds.user.fields.study_program') }}</label>
                <select class="form-control {{ $errors->has('type') ? 'is-invalid' : '' }}" name="study_program" id="study_program">
                    <option value disabled {{ old('study_program', null) === null ? 'selected' : '' }}>{{ trans('global.pleaseSelect') }}</option>
                    @foreach($studyPrograms as $studyProgram)
                        <option value="{{ $studyProgram }}" {{ old('study_program', $user->study_program) === $studyProgram ? 'selected' : '' }}>{{ $studyProgram }}</option>
                    @endforeach
                </select>
                @if($errors->has('study_program'))
                    <div class="invalid-feedback">
                        {{ $errors->first('study_program') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.study_program_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="phone_number">{{ trans('cruds.user.fields.phone_number') }}</label>
                <input class="form-control {{ $errors->has('phone_number') ? 'is-invalid' : '' }}" type="text" name="phone_number" id="phone_number" value="{{ old('phone_number', $user->phone_number) }}">
                @if($errors->has('phone_number'))
                    <div class="invalid-feedback">
                        {{ $errors->first('phone_number') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.phone_number_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="address">{{ trans('cruds.user.fields.address') }}</label>
                <textarea class="form-control {{ $errors->has('address') ? 'is-invalid' : '' }}" name="address" id="address">{{ old('address', $user->address) }}</textarea>
                @if($errors->has('address'))
                    <div class="invalid-feedback">
                        {{ $errors->first('address') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.address_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="city_of_birth">{{ trans('cruds.user.fields.city_of_birth') }}</label>
                <input class="form-control {{ $errors->has('city_of_birth') ? 'is-invalid' : '' }}" type="text" name="city_of_birth" id="city_of_birth" value="{{ old('city_of_birth', $user->city_of_birth) }}">
                @if($errors->has('city_of_birth'))
                    <div class="invalid-feedback">
                        {{ $errors->first('city_of_birth') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.city_of_birth_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="date_of_birth">{{ trans('cruds.user.fields.date_of_birth') }}</label>
                <input class="form-control date {{ $errors->has('date_of_birth') ? 'is-invalid' : '' }}" type="text" name="date_of_birth" id="date_of_birth" value="{{ old('date_of_birth', $user->date_of_birth) }}">
                @if($errors->has('date_of_birth'))
                    <div class="invalid-feedback">
                        {{ $errors->first('date_of_birth') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.date_of_birth_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="graduated_date">{{ trans('cruds.user.fields.graduated_date') }}</label>
                <input class="form-control date {{ $errors->has('graduated_date') ? 'is-invalid' : '' }}" type="text" name="graduated_date" id="graduated_date" value="{{ old('graduated_date', $user->graduated_date) }}">
                @if($errors->has('graduated_date'))
                    <div class="invalid-feedback">
                        {{ $errors->first('graduated_date') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.graduated_date_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="certificate_number">{{ trans('cruds.user.fields.certificate_number') }}</label>
                <input class="form-control {{ $errors->has('certificate_number') ? 'is-invalid' : '' }}" type="text" name="certificate_number" id="certificate_number" value="{{ old('certificate_number', $user->certificate_number) }}">
                @if($errors->has('certificate_number'))
                    <div class="invalid-feedback">
                        {{ $errors->first('certificate_number') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.certificate_number_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="certificate_file">{{ trans('cruds.user.fields.certificate_file') }}</label>
                <div class="needsclick dropzone {{ $errors->has('certificate_file') ? 'is-invalid' : '' }}" id="certificate_file-dropzone">
                </div>
                @if($errors->has('certificate_file'))
                    <div class="invalid-feedback">
                        {{ $errors->first('certificate_file') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.certificate_file_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="transcript_number">{{ trans('cruds.user.fields.transcript_number') }}</label>
                <input class="form-control {{ $errors->has('transcript_number') ? 'is-invalid' : '' }}" type="text" name="transcript_number" id="transcript_number" value="{{ old('transcript_number', $user->transcript_number) }}">
                @if($errors->has('transcript_number'))
                    <div class="invalid-feedback">
                        {{ $errors->first('transcript_number') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.transcript_number_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="transcript_file">{{ trans('cruds.user.fields.transcript_file') }}</label>
                <div class="needsclick dropzone {{ $errors->has('transcript_file') ? 'is-invalid' : '' }}" id="transcript_file-dropzone">
                </div>
                @if($errors->has('transcript_file'))
                    <div class="invalid-feedback">
                        {{ $errors->first('transcript_file') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.transcript_file_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="signature_image">{{ trans('cruds.user.fields.signature_image') }}</label>
                <div class="needsclick dropzone {{ $errors->has('signature_image') ? 'is-invalid' : '' }}" id="signature_image-dropzone">
                </div>
                @if($errors->has('signature_image'))
                    <div class="invalid-feedback">
                        {{ $errors->first('signature_image') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.signature_image_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="certificate_degree">{{ trans('cruds.user.fields.certificate_degree') }}</label>
                <input class="form-control {{ $errors->has('certificate_degree') ? 'is-invalid' : '' }}" type="text" name="certificate_degree" id="certificate_degree" value="{{ old('certificate_degree', $user->certificate_degree) }}">
                @if($errors->has('certificate_degree'))
                    <div class="invalid-feedback">
                        {{ $errors->first('certificate_degree') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.certificate_degree_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="certificate_printed_number">{{ trans('cruds.user.fields.certificate_printed_number') }}</label>
                <input class="form-control {{ $errors->has('certificate_printed_number') ? 'is-invalid' : '' }}" type="text" name="certificate_printed_number" id="certificate_printed_number" value="{{ old('certificate_printed_number', $user->certificate_printed_number) }}">
                @if($errors->has('certificate_printed_number'))
                    <div class="invalid-feedback">
                        {{ $errors->first('certificate_printed_number') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.certificate_printed_number_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="gpa">{{ trans('cruds.user.fields.gpa') }}</label>
                <input class="form-control {{ $errors->has('gpa') ? 'is-invalid' : '' }}" type="number" name="gpa" id="gpa" value="{{ old('gpa', $user->gpa) }}" step="0.01">
                @if($errors->has('gpa'))
                    <div class="invalid-feedback">
                        {{ $errors->first('gpa') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.gpa_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="thesis_title">{{ trans('cruds.user.fields.thesis_title') }}</label>
                <input class="form-control {{ $errors->has('thesis_title') ? 'is-invalid' : '' }}" type="text" name="thesis_title" id="thesis_title" value="{{ old('thesis_title', $user->thesis_title) }}">
                @if($errors->has('thesis_title'))
                    <div class="invalid-feedback">
                        {{ $errors->first('thesis_title') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.thesis_title_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="thesis_title_en">{{ trans('cruds.user.fields.thesis_title_en') }}</label>
                <input class="form-control {{ $errors->has('thesis_title_en') ? 'is-invalid' : '' }}" type="text" name="thesis_title_en" id="thesis_title_en" value="{{ old('thesis_title_en', $user->thesis_title_en) }}">
                @if($errors->has('thesis_title_en'))
                    <div class="invalid-feedback">
                        {{ $errors->first('thesis_title_en') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.thesis_title_en_helper') }}</span>
            </div>
            <div class="form-group">
                <label>
                    {{ trans('cruds.user.fields.is_graduated') }}&nbsp;&nbsp;
                    <input type="checkbox" id="is_graduated" name="is_graduated" {{ $user->is_graduated ? 'checked' : '' }} data-toggle="toggle" data-on="Ya" data-off="Tidak">
                </label>
            </div>
            <div class="form-group">
                <label class="required" for="email">{{ trans('cruds.user.fields.email') }}</label>
                <input class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}" type="email" name="email" id="email" value="{{ old('email', $user->email) }}" required>
                @if($errors->has('email'))
                    <div class="invalid-feedback">
                        {{ $errors->first('email') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.email_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="password">{{ trans('cruds.user.fields.password') }}</label>
                <input class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}" type="password" name="password" id="password">
                @if($errors->has('password'))
                    <div class="invalid-feedback">
                        {{ $errors->first('password') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.password_helper') }}</span>
            </div>
            <div class="form-group">
                <label>
                    {{ trans('cruds.user.fields.is_admin') }}&nbsp;&nbsp;
                    <input type="checkbox" id="is_admin" name="is_admin" {{ $user->is_admin ? 'checked' : '' }} data-toggle="toggle" data-on="Ya" data-off="Bukan">
                </label>
            </div>
            <div class="form-group" id="roles_group">
                <label for="roles">{{ trans('cruds.user.fields.roles') }}</label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0">{{ trans('global.deselect_all') }}</span>
                </div>
                <select class="form-control select2 {{ $errors->has('roles') ? 'is-invalid' : '' }}" name="roles[]" id="roles" multiple>
                    @foreach($roles as $id => $roles)
                        <option value="{{ $id }}" {{ (in_array($id, old('roles', [])) || $user->roles->contains($id)) ? 'selected' : '' }}>{{ $roles }}</option>
                    @endforeach
                </select>
                @if($errors->has('roles'))
                    <div class="invalid-feedback">
                        {{ $errors->first('roles') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.roles_helper') }}</span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>



@endsection

@section('scripts')
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<script>
    $(function() {
        @if(!$user->is_admin)
        $('#roles_group').hide()
        @endif
        
        $('#is_admin').change(function() {
            if ($(this).prop('checked')) {
                $('#roles_group').show()
            } else {
                $('#roles_group').hide()
            }
        })
    })
</script>
<script>
    Dropzone.options.certificateFileDropzone = {
    url: '{{ route('admin.users.storeMedia') }}',
    maxFilesize: 5, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "{{ csrf_token() }}"
    },
    params: {
      size: 5
    },
    success: function (file, response) {
      $('form').find('input[name="certificate_file"]').remove()
      $('form').append('<input type="hidden" name="certificate_file" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="certificate_file"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
@if(isset($user) && $user->certificate_file)
      var file = {!! json_encode($user->certificate_file) !!}
          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="certificate_file" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
@endif
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<script>
    Dropzone.options.transcriptFileDropzone = {
    url: '{{ route('admin.users.storeMedia') }}',
    maxFilesize: 5, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "{{ csrf_token() }}"
    },
    params: {
      size: 5
    },
    success: function (file, response) {
      $('form').find('input[name="transcript_file"]').remove()
      $('form').append('<input type="hidden" name="transcript_file" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="transcript_file"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
@if(isset($user) && $user->transcript_file)
      var file = {!! json_encode($user->transcript_file) !!}
          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="transcript_file" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
@endif
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<script>
    Dropzone.options.signatureImageDropzone = {
    url: '{{ route('admin.users.storeMedia') }}',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "{{ csrf_token() }}"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="signature_image"]').remove()
      $('form').append('<input type="hidden" name="signature_image" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="signature_image"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
@if(isset($user) && $user->signature_image)
      var file = {!! json_encode($user->signature_image) !!}
          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="signature_image" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
@endif
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
@endsection