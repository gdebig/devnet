@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.show') }} {{ trans('cruds.user.title') }}
    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.users.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.name') }}
                        </th>
                        <td>
                            {{ $user->name }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.type') }}
                        </th>
                        <td>
                            {{ App\User::TYPE_SELECT[$user->type] ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.student_number') }}
                        </th>
                        <td>
                            {{ $user->student_number }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.phone_number') }}
                        </th>
                        <td>
                            {{ $user->phone_number }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.address') }}
                        </th>
                        <td>
                            {{ $user->address }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.city_of_birth') }}
                        </th>
                        <td>
                            {{ $user->city_of_birth }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.date_of_birth') }}
                        </th>
                        <td>
                            {{ $user->date_of_birth }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.study_program') }}
                        </th>
                        <td>
                            {{ $user->study_program }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.status') }}
                        </th>
                        <td>
                            {{ App\User::STATUS_SELECT[$user->status] ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.graduated_date') }}
                        </th>
                        <td>
                            {{ $user->graduated_date }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.certificate_number') }}
                        </th>
                        <td>
                            {{ $user->certificate_number }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.certificate_file') }}
                        </th>
                        <td>
                            @if($user->certificate_file)
                                <a href="{{ $user->certificate_file->url }}" target="_blank">
                                    {{ trans('global.view_file') }}
                                </a>
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.transcript_number') }}
                        </th>
                        <td>
                            {{ $user->transcript_number }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.transcript_file') }}
                        </th>
                        <td>
                            @if($user->transcript_file)
                                <a href="{{ $user->transcript_file->url }}" target="_blank">
                                    {{ trans('global.view_file') }}
                                </a>
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.signature_image') }}
                        </th>
                        <td>
                            @if($user->signature_image)
                                <a href="{{ $user->signature_image->url }}" target="_blank" style="display: inline-block">
                                    <img src="{{ $user->signature_image->preview }}">
                                </a>
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.certificate_degree') }}
                        </th>
                        <td>
                            {{ $user->certificate_degree }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.certificate_printed_number') }}
                        </th>
                        <td>
                            {{ $user->certificate_printed_number }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.gpa') }}
                        </th>
                        <td>
                            {{ $user->gpa }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.thesis_title') }}
                        </th>
                        <td>
                            {{ $user->thesis_title }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.thesis_title_en') }}
                        </th>
                        <td>
                            {{ $user->thesis_title_en }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.is_graduated') }}
                        </th>
                        <td>
                            {{ $user->is_graduated == 1 ? 'Ya' : 'Tidak' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.email') }}
                        </th>
                        <td>
                            {{ $user->email }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.is_admin') }}
                        </th>
                        <td>
                            {{ $user->is_admin == 1 ? 'Ya' : 'Bukan' }}
                        </td>
                    </tr>
                    @if($user->is_admin)
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.roles') }}
                        </th>
                        <td>
                            @foreach($user->roles as $key => $roles)
                                <span class="badge badge-info">{{ $roles->title }}</span>
                            @endforeach
                        </td>
                    </tr>
                    @endif
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.users.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
                @can('user_edit')
                    @if($user->status == \App\User::UNVERIFIED_ID || $user->status == \App\User::REJECTED_ID)
                    <form action="{{ route('admin.users.verified', $user->id) }}" method="POST" style="display: inline-block;">
                        @method('PUT')
                        @csrf
                        <input type="submit" class="btn btn-success" value="{{ trans('global.verified') }}">
                    </form>
                    @endif
                    @if($user->status == \App\User::UNVERIFIED_ID)
                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#blockModal">{{ trans('global.reject') }}</button>
                    <form action="{{ route('admin.users.reject', $user->id) }}" method="POST" style="display: inline-block;">
                        @method('PUT')
                        @csrf
                        <div class="modal fade" id="blockModal" tabindex="-1" role="dialog" aria-labelledby="blockModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="blockModalLabel">{{ trans('global.reject') }} {{ $user->name }} - {{ $user->student_number }}</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label class="required" for="reason">{{ trans('cruds.user.fields.reason') }}</label>
                                            <textarea name="reason" id="reason" class="form-control" required></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-warning">{{ trans('global.reject') }}</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    @endif
                    @if($user->status == \App\User::VERIFIED_ID)
                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#blockModal">{{ trans('global.block') }}</button>
                    <form action="{{ route('admin.users.block', $user->id) }}" method="POST" style="display: inline-block;">
                        @method('PUT')
                        @csrf
                        <div class="modal fade" id="blockModal" tabindex="-1" role="dialog" aria-labelledby="blockModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="blockModalLabel">{{ trans('global.block') }} {{ $user->name }} - {{ $user->student_number }}</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label class="required" for="reason">{{ trans('cruds.user.fields.reason') }}</label>
                                            <textarea name="reason" id="reason" class="form-control" required></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-warning">{{ trans('global.block') }}</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    @endif
                    @if($user->status == \App\User::BLOCK_ID)
                    <form action="{{ route('admin.users.activated', $user->id) }}" method="POST" style="display: inline-block;">
                        @method('PUT')
                        @csrf
                        <input type="submit" class="btn btn-warning" value="{{ trans('global.activated') }}">
                    </form>
                    @endif
                @endcan
            </div>
        </div>
    </div>
</div>

<div class="card">
    <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
        <li class="nav-item">
            <a class="nav-link active" href="#user_orders" role="tab" data-toggle="tab">
                {{ trans('cruds.order.title') }}
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#user_status_histories" role="tab" data-toggle="tab">
                {{ trans('cruds.userStatusHistory.title') }}
            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane active" role="tabpanel" id="user_orders">
            @includeIf('admin.users.relationships.userOrders', ['orders' => $user->userOrders])
        </div>
        <div class="tab-pane" role="tabpanel" id="user_status_histories">
            @includeIf('admin.users.relationships.userStatusHistories', ['userStatusHistories' => $user->userStatusHistories])
        </div>
    </div>
</div>

@endsection