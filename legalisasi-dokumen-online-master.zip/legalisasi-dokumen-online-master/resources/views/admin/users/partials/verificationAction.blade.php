@can('user_edit')
    @if($row->status == \App\User::UNVERIFIED_ID || $row->status == \App\User::REJECTED_ID)
    <form action="{{ route('admin.users.verified', $row->id) }}" method="POST" style="display: inline-block;">
        @method('PUT')
        @csrf
        <input type="submit" class="btn btn-xs btn-success" value="{{ trans('global.verified') }}">
    </form>
    @endif
    @if($row->status == \App\User::UNVERIFIED_ID)
    <button type="button" class="btn btn-xs btn-warning" data-toggle="modal" data-target="#blockModal{{ $row->id }}">{{ trans('global.reject') }}</button>
    <form action="{{ route('admin.users.reject', $row->id) }}" method="POST" style="display: inline-block;">
        @method('PUT')
        @csrf
        <div class="modal fade" id="blockModal{{ $row->id }}" tabindex="-1" role="dialog" aria-labelledby="blockModal{{ $row->id }}Label" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="blockModal{{ $row->id }}Label">{{ trans('global.reject') }} {{ $row->name }} - {{ $row->student_number }}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="required" for="reason">{{ trans('cruds.user.fields.reason') }}</label>
                            <textarea name="reason" id="reason{{ $row->id }}" class="form-control" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-warning">{{ trans('global.reject') }}</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    @endif
    @if($row->status == \App\User::VERIFIED_ID)
    <button type="button" class="btn btn-xs btn-warning" data-toggle="modal" data-target="#blockModal{{ $row->id }}">{{ trans('global.block') }}</button>
    <form action="{{ route('admin.users.block', $row->id) }}" method="POST" style="display: inline-block;">
        @method('PUT')
        @csrf
        <div class="modal fade" id="blockModal{{ $row->id }}" tabindex="-1" role="dialog" aria-labelledby="blockModal{{ $row->id }}Label" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="blockModal{{ $row->id }}Label">{{ trans('global.block') }} {{ $row->name }} - {{ $row->student_number }}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="required" for="reason">{{ trans('cruds.user.fields.reason') }}</label>
                            <textarea name="reason" id="reason{{ $row->id }}" class="form-control" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-warning">{{ trans('global.block') }}</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    @endif
    @if($row->status == \App\User::BLOCK_ID)
    <form action="{{ route('admin.users.activated', $row->id) }}" method="POST" style="display: inline-block;">
        @method('PUT')
        @csrf
        <input type="submit" class="btn btn-xs btn-warning" value="{{ trans('global.activated') }}">
    </form>
    @endif
@endcan