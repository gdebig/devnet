<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-userOrders">
                <thead>
                    <tr>
                        <th>
                            {{ trans('cruds.order.fields.order_number') }}
                        </th>
                        <th>
                            {{ trans('cruds.order.fields.shipping_type') }}
                        </th>
                        <th>
                            {{ trans('cruds.order.fields.destination_type') }}
                        </th>
                        <th>
                            {{ trans('cruds.order.fields.courier') }}
                        </th>
                        <th>
                            {{ trans('cruds.order.fields.payment_type') }}
                        </th>
                        <th>
                            {{ trans('cruds.order.fields.status') }}
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($orders as $key => $order)
                        <tr data-entry-id="{{ $order->id }}">
                            <td>
                                {{ $order->order_number ?? '' }}
                            </td>
                            <td>
                                {{ $order->shipping_type ? \App\Order::SHIPPING_TYPE_SELECT[$order->shipping_type] : '' }}
                            </td>
                            <td>
                                {{ $order->destination_type ? \App\Order::DESTINATION_TYPE_SELECT[$order->destination_type] : '' }}
                            </td>
                            <td>
                                {{ $order->courier ? \App\Order::COURIER_SELECT[$order->courier] : '' }}
                            </td>
                            <td>
                                {{ $order->payment_type ? \App\Order::PAYMENT_TYPE_SELECT[$order->payment_type] : '' }}
                            </td>
                            <td>
                                {{ $order->status ? \App\Order::STATUS_SELECT[$order->status] : '' }}
                            </td>
                            <td>
                                @can('order_show')
                                    <a class="btn btn-xs btn-primary" href="{{ route('admin.orders.show', $order->id) }}">
                                        {{ trans('global.view') }}
                                    </a>
                                @endcan
                            </td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@section('scripts')
@parent
<script>
$(function () {
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
@endsection