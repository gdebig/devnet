<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-userStatusHistories">
                <thead>
                    <tr>
                        <th>
                            {{ trans('cruds.userStatusHistory.fields.status') }}
                        </th>
                        <th>
                            {{ trans('cruds.userStatusHistory.fields.reason') }}
                        </th>
                        <th>
                            {{ trans('cruds.userStatusHistory.fields.created_at') }}
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($userStatusHistories as $key => $userStatusHistory)
                        <tr>
                            <td>
                                {{ $userStatusHistory->status ? \App\User::STATUS_SELECT[$userStatusHistory->status] : '' }}
                            </td>
                            <td>
                                {!! str_replace("\n", '<br/>', ($userStatusHistory->reason ?? '')) !!}
                            </td>
                            <td>
                                {{ $userStatusHistory->created_at }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@section('scripts')
@parent
<script>
$(function () {

  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
@endsection