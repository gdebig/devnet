<?php

Route::get('/home', 'HomeController@index')->middleware('user')->name('home');

Route::get('/announcement', 'HomeController@announcement')->name('announcement');

Route::get('/sso-login', 'Auth\LoginController@ssoLogin')->name('ssoLogin');
// Route::get('/', 'User\HomeController@index')->name('home');
Route::get('/email_verified/{id}', 'HomeController@emailVerified')->middleware('guest')->name('email_verified');

Route::get('ldo-admin/login', 'Auth\AdminLoginController@showLoginForm')->name('admin.login');
Route::post('ldo-admin/login', 'Auth\AdminLoginController@login')->name('admin.loginPost');
Route::post('ldo-admin/logout', 'Auth\AdminLoginController@logout')->name('admin.logout');

Route::get('/ldo-admin', function () {
    if (session('status')) {
        return redirect()->route('admin.home')->with('status', session('status'));
    }

    return redirect()->route('admin.home');
});

Route::group(['middleware' => ['user.not_auth']], function() {
    Route::get('/register-alumni/form', 'User\RegisterController@indexAlumni')->name('register.alumni');
    Route::post('/register-alumni/create', 'User\RegisterController@createUserAlumni')->name('register.alumni.create');

    Route::get('/register-new-alumni', 'User\RegisterNewAlumniController@index')->name('register-new-alumni');
    Route::get('/register-new-alumni/form-account', 'User\RegisterNewAlumniController@formAccount')->name('register-new-alumni.account');
    Route::post('/register-new-alumni/create-account', 'User\RegisterNewAlumniController@createAccount')->name('register-new-alumni.account.create');
    Route::get('/register-new-alumni/form-certificate', 'User\RegisterNewAlumniController@formCertificate')->name('register-new-alumni.certificate');
    Route::post('/register-new-alumni/create-certificate', 'User\RegisterNewAlumniController@createCertificate')->name('register-new-alumni.certificate.create');
    Route::get('/register-new-alumni/form-transcript', 'User\RegisterNewAlumniController@formTranscript')->name('register-new-alumni.transcript');
    Route::post('/register-new-alumni/create-transcript', 'User\RegisterNewAlumniController@createTranscript')->name('register-new-alumni.transcript.create');
});

Route::post('/user/media', 'User\HomeController@storeMedia')->name('user.storeMedia');
Auth::routes(['register' => false]);

// User
Route::group(['namespace' => 'User', 'middleware' => ['user.auth', 'user'], 'as' => 'user.'], function () {
    Route::group(['middleware' => ['user.not_verified']], function () {
        Route::get('/verification/form', 'VerificationController@form')->name('verification.form');
        Route::post('/verification/create', 'VerificationController@store')->name('verification.store');
    });

    Route::group(['middleware' => ['user.verified']], function () {
        Route::get('/', 'HomeController@index')->name('home');

        Route::get('/profile', 'ProfileController@index')->name('profile');
        Route::post('/profile', 'ProfileController@update')->name('profile.update');
        Route::get('/order', 'OrderController@index')->name('order');
        Route::get('/order-history', 'OrderController@history')->name('order.history');
        Route::get('/order-status', 'OrderController@status')->name('order.status');
        Route::get('/order-detail/{id}', 'OrderController@detail')->name('order.detail');

        Route::get('/create-order', 'OrderController@createOrder')->name('order.create');
        Route::get('/create-order/form-user', 'OrderController@formUser')->name('order.user');
        Route::post('/create-order/save-user', 'OrderController@saveUser')->name('order.user.save');
        Route::get('/create-order/form-docs', 'OrderController@formDocs')->name('order.docs');
        Route::post('/create-order/save-docs', 'OrderController@saveDocs')->name('order.docs.save');
        Route::get('/create-order/review', 'OrderController@review')->name('order.review');
        Route::post('/create-order/save-review', 'OrderController@saveReview')->name('order.review.save');
        Route::get('/create-order/form-payment/{id}', 'OrderController@formPayment')->name('order.payment');
        // Route::post('/create-order/confirm-payment', 'OrderController@confirmPayment')->name('order.payment.confirm');
        Route::get('/order/finish', 'OrderController@finish')->name('order.finish');

        Route::get('/country', 'OrderController@getCountry')->name('order.country');
        Route::get('/province', 'OrderController@getProvince')->name('order.province');
        Route::get('/city', 'OrderController@getCity')->name('order.city');
        Route::get('/district', 'OrderController@getDistrict')->name('order.district');
        Route::get('/courier', 'OrderController@getLocalCourier')->name('order.courier-local');
        Route::get('/courier-intl', 'OrderController@getIntlCourier')->name('order.courier-intl');
        Route::get('/cost', 'OrderController@getCost')->name('order.cost');
    });
});


// Admin
Route::group(['prefix' => 'ldo-admin', 'as' => 'admin.', 'namespace' => 'Admin', 'middleware' => ['admin.auth', 'admin']], function () {
    Route::get('/', 'HomeController@index')->name('home');
    Route::get('order-by-type', 'HomeController@getOrderByTypeData')->name('orderByType');
    Route::get('tren-chart', 'HomeController@getTrenChartData')->name('trenChart');
    Route::get('sla-report', 'HomeController@getSLAData')->name('slaReport');

    // Permissions
    Route::resource('permissions', 'PermissionsController', ['except' => ['create', 'store', 'edit', 'update', 'show', 'destroy']]);

    // Roles
    Route::delete('roles/destroy', 'RolesController@massDestroy')->name('roles.massDestroy');
    Route::resource('roles', 'RolesController');

    // Users
    Route::delete('users/destroy', 'UsersController@massDestroy')->name('users.massDestroy');
    Route::put('users/{user}/verified', 'UsersController@verified')->name('users.verified');
    Route::put('users/{user}/block', 'UsersController@block')->name('users.block');
    Route::put('users/{user}/reject', 'UsersController@reject')->name('users.reject');
    Route::put('users/{user}/activated', 'UsersController@activated')->name('users.activated');
    Route::get('users/media/{mediaId}/conversions/{fileName}', 'UsersController@retrieveMediaConversion')->name('users.retrieveMediaConversion');
    Route::get('users/media/{mediaId}/{fileName}', 'UsersController@retrieveMedia')->name('users.retrieveMedia');
    Route::post('users/media', 'UsersController@storeMedia')->name('users.storeMedia');
    Route::post('users/ckmedia', 'UsersController@storeCKEditorImages')->name('users.storeCKEditorImages');
    Route::resource('users', 'UsersController');

    // Document Types
    Route::delete('document-types/destroy', 'DocumentTypesController@massDestroy')->name('document-types.massDestroy');
    Route::resource('document-types', 'DocumentTypesController');

    // Orders
    Route::put('orders/{order}/status', 'OrdersController@updateStatus')->name('orders.status');
    Route::put('orders/{order}/status/undo', 'OrdersController@undoStatus')->name('orders.status.undo');
    Route::get('orders/status/paid', 'OrdersController@getAlreadyPaidCount')->name('orders.status.paid');
    Route::get('orders/{order}/print', 'OrdersController@print')->name('orders.print');
    Route::resource('orders', 'OrdersController', ['except' => ['create', 'store', 'edit', 'update']]);

    // Announcements
    Route::delete('announcements/destroy', 'AnnouncementsController@massDestroy')->name('announcements.massDestroy');
    Route::post('announcements/media', 'AnnouncementsController@storeMedia')->name('announcements.storeMedia');
    Route::post('announcements/ckmedia', 'AnnouncementsController@storeCKEditorImages')->name('announcements.storeCKEditorImages');
    Route::resource('announcements', 'AnnouncementsController');
});
Route::group(['prefix' => 'profile', 'as' => 'profile.', 'namespace' => 'Auth', 'middleware' => ['admin.auth']], function () {
// Change password
    if (file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))) {
        Route::get('password', 'ChangePasswordController@edit')->name('password.edit');
        Route::post('password', 'ChangePasswordController@update')->name('password.update');
    }
});
