<?php

Route::group(['prefix' => 'v1', 'as' => 'api.', 'namespace' => 'Api\V1\Admin', 'middleware' => ['auth:api']], function () {
    // Permissions
    Route::apiResource('permissions', 'PermissionsApiController', ['except' => ['store', 'show', 'update', 'destroy']]);

    // Roles
    Route::apiResource('roles', 'RolesApiController');

    // Users
    Route::post('users/media', 'UsersApiController@storeMedia')->name('users.storeMedia');
    Route::apiResource('users', 'UsersApiController');

    // Document Types
    Route::apiResource('document-types', 'DocumentTypesApiController');

    // Order Items
    Route::apiResource('order-items', 'OrderItemsApiController', ['except' => ['store', 'show', 'update', 'destroy']]);

    // Orders
    Route::apiResource('orders', 'OrdersApiController', ['except' => ['store', 'update']]);

    // Announcements
    Route::post('announcements/media', 'AnnouncementsApiController@storeMedia')->name('announcements.storeMedia');
    Route::apiResource('announcements', 'AnnouncementsApiController');
});

// Notifications
Route::post('/midtrans-notification', 'User\OrderController@midtransNotification')->name('midtrans.notif');
