<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToOrderItemsTable extends Migration
{
    public function up()
    {
        Schema::table('order_items', function (Blueprint $table) {
            $table->unsignedInteger('document_type_id');
            $table->foreign('document_type_id', 'document_type_fk_1889905')->references('id')->on('document_types');
            $table->unsignedInteger('order_id');
            $table->foreign('order_id', 'order_fk_1890038')->references('id')->on('orders');
        });
    }
}
