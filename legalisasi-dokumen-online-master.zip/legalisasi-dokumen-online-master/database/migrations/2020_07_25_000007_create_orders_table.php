<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->increments('id');
            $table->string('order_number')->unique();
            $table->integer('shipping_type');
            $table->integer('destination_type')->nullable();
            $table->longText('shipping_address')->nullable();
            $table->integer('status');
            $table->decimal('shipping_cost', 15, 2)->nullable();
            $table->integer('courier')->nullable();
            $table->integer('payment_type')->nullable();
            $table->longText('review')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
}
