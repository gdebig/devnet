<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRegisterFieldInUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            //
            $table->string('city_of_birth')->nullable();
            $table->date('date_of_birth')->nullable();
            $table->string('certificate_degree')->nullable();
            $table->string('certificate_printed_number')->nullable();
            $table->decimal('gpa')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            //
            $table->dropColumn('city_of_birth');
            $table->dropColumn('date_of_birth');
            $table->dropColumn('certificate_degree');
            $table->dropColumn('certificate_printed_number');
            $table->dropColumn('gpa');
        });
    }
}
