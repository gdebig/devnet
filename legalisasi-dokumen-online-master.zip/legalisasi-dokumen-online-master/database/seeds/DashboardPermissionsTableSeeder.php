<?php

use App\Permission;
use App\Role;
use Illuminate\Database\Seeder;

class DashboardPermissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $permissions = [
            [
                'title' => 'dashboard_access',
                'name'  => 'Melihat Dashboard'
            ],
        ];

        Permission::insert($permissions);

        $admin_permissions = Permission::all();
        Role::findOrFail(1)->permissions()->sync($admin_permissions->pluck('id'));
    }
}
