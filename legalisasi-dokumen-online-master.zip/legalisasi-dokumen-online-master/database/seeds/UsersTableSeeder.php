<?php

use App\User;
use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    public function run()
    {
        $users = [
            [
                'id'                 => 1,
                'name'               => 'Admin',
                'email'              => 'ldo.admin@ui.ac.id',
                'password'           => '$2y$10$4gbTOMwSW0nXcdeUFBMI/uLrtcT9/xwJV6zv8KL2Nu4PxGKfzx/pS',
                'remember_token'     => null,
                'student_number'     => '',
                'phone_number'       => '',
                'certificate_number' => '',
                'transcript_number'  => '',
                'is_admin'           => true,
                'status'             => User::VERIFIED_ID
            ],
        ];

        User::insert($users);
    }
}
