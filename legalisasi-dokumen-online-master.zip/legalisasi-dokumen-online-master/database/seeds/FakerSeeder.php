<?php

use App\User;
use App\DocumentType;
use App\OrderItem;
use App\Order;
use App\Announcement;
use Faker\Factory as Faker;
use Illuminate\Database\Seeder;

class FakerSeeder extends Seeder
{
    public function run()
    {
        $faker = Faker::create('id_ID');

        $documentTypes = [];
        $names = array('Ijazah Bahasa Indonesia', 'Ijazah Bahasa Inggris', 'Transkrip Bahasa Indonesia', 'Transkrip Bahasa Inggris', 'DNM Bahasa Indonesia', 'DNM Bahasa Inggris');
        $isForStudent = array(false, false, false, false, true, true);
        for ($i = 0; $i < 6; ++$i) {
            $documentTypes[$i] = [
                'name' => $names[$i],
                'price' => $faker->randomElement(array(2000, 3000)),
                'is_for_alumni' => true,
                'is_for_student' => $isForStudent[$i],
                'created_at' => '2019-01-01 05:00:00',
                'updated_at' => '2019-01-01 05:00:00'
            ];
        }
        DocumentType::insert($documentTypes);

        $randomUserTypeIdx = [];
        $i = 0;
        foreach (User::TYPE_SELECT as $id => $item) {
            $randomUserTypeIdx[$i] = $id;
            ++$i;
        }

        $randomUserStatusIdx = [];
        $i = 0;
        foreach (User::STATUS_SELECT as $id => $item) {
            $randomUserStatusIdx[$i] = $id;
            ++$i;
        }
        
        $users = [];
        for ($i = 0; $i < env('SIZEOFUSER', 100); ++$i) {
            $type = $faker->randomElement($randomUserTypeIdx);

            $users[$i] = [
                'name' => $faker->name,
                'email' => $faker->unique()->safeEmail,
                'email_verified_at' => now(),
                'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
                'remember_token' => Str::random(10),
                'student_number' => $faker->shuffleString('0123456789'),
                'type' => $type,
                'phone_number' => $faker->shuffleString('0123456789'),
                'address' => $faker->address,
                'graduated_date' => $type == User::ALUMNI_ID ? $faker->randomElement(array('2019-08-17', '2018-08-17', '2017-08-17', '2016-08-17', '2015-08-17')) : null,
                'status' => $faker->randomElement($randomUserStatusIdx),
                'certificate_number' => $faker->shuffleString('0123456789'),
                'transcript_number' => $faker->shuffleString('0123456789'),
                'created_at' => '2020-01-01 05:00:00',
                'updated_at' => '2020-01-01 05:00:00'
            ];
        }
        User::insert($users);

        $documentTypes = DocumentType::get();
        $randomDocTypeIdx = [];
        for ($i = 0; $i < sizeof($documentTypes); ++$i) {
            $randomDocTypeIdx[$i] = $i;   
        }

        $users = User::where('status', User::VERIFIED_ID)->get();
        $randomUserIdx = [];
        for ($i = 0; $i < sizeof($users); ++$i) {
            $randomUserIdx[$i] = $i;   
        }

        $randomStatusIdx = [];
        $i = 0;
        foreach (Order::STATUS_SELECT as $id => $item) {
            $randomStatusIdx[$i] = $id;
            ++$i;
        }

        $randomDestIdx = [];
        $i = 0;
        foreach (Order::DESTINATION_TYPE_SELECT as $id => $item) {
            $randomDestIdx[$i] = $id;
            ++$i;
        }

        $randomShippingTypeIdx = [];
        $i = 0;
        foreach (Order::SHIPPING_TYPE_SELECT as $id => $item) {
            $randomShippingTypeIdx[$i] = $id;
            ++$i;
        }

        $randomPaymentTypeIdx = [];
        $i = 0;
        foreach (Order::PAYMENT_TYPE_SELECT as $id => $item) {
            $randomPaymentTypeIdx[$i] = $id;
            ++$i;
        }

        $randomCourierIdx = [];
        $i = 0;
        foreach (Order::COURIER_SELECT as $id => $item) {
            $randomCourierIdx[$i] = $id;
            ++$i;
        }

        for ($i = 0; $i < env('SIZEOFORDER', 100); ++$i) {
            $user = $users[$faker->randomElement($randomUserIdx)];
            $shippingType = $faker->randomElement($randomShippingTypeIdx);
            $status = $faker->randomElement($randomStatusIdx);

            $createdAt = $faker->dateTimeBetween('-3 months', '-9 days');
            $updatedAt = clone $createdAt;
            $paidAt = null;
            $completedAt = null;
            $deliveredAt = null;
            $finishedAt = null;
            if ($status == Order::PAID_ID) {
                $hourAdd = $faker->randomElement(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
                $paidAt = clone $createdAt;
                $paidAt->add(new DateInterval('PT' . $hourAdd .  'H'));
                $updatedAt = $paidAt;
            }
            if ($status == Order::PROCESSED_ID) {
                $hourAdd = $faker->randomElement(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
                $paidAt = clone $createdAt;
                $paidAt->add(new DateInterval('PT' . $hourAdd .  'H'));
                $dayAdd = $faker->randomElement(array(1, 2));
                $hourAdd = $faker->randomElement(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
                $completedAt = clone $paidAt;
                $completedAt->add(new DateInterval('P' . $dayAdd . 'DT' . $hourAdd .  'H'));
                $updatedAt = $completedAt;
            }

            if ($status == Order::READY_TO_PICKUP_ID || $status == Order::ON_DELIVERY_ID) {
                $hourAdd = $faker->randomElement(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
                $paidAt = clone $createdAt;
                $paidAt->add(new DateInterval('PT' . $hourAdd .  'H'));
                $dayAdd = $faker->randomElement(array(1, 2));
                $hourAdd = $faker->randomElement(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
                $completedAt = clone $paidAt;
                $completedAt->add(new DateInterval('P' . $dayAdd . 'DT' . $hourAdd .  'H'));
                $dayAdd = $faker->randomElement(array(1, 2));
                $hourAdd = $faker->randomElement(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
                $deliveredAt = clone $completedAt;
                $deliveredAt->add(new DateInterval('P' . $dayAdd . 'DT' . $hourAdd .  'H'));
                $updatedAt = $deliveredAt;
            }

            if ($status == Order::FINISH_ID || $status == Order::ORDER_PROBLEM_ID) {
                $hourAdd = $faker->randomElement(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
                $paidAt = clone $createdAt;
                $paidAt->add(new DateInterval('PT' . $hourAdd .  'H'));
                $dayAdd = $faker->randomElement(array(1, 2));
                $hourAdd = $faker->randomElement(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
                $completedAt = clone $paidAt;
                $completedAt->add(new DateInterval('P' . $dayAdd . 'DT' . $hourAdd .  'H'));
                $dayAdd = $faker->randomElement(array(1, 2));
                $hourAdd = $faker->randomElement(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
                $deliveredAt = clone $completedAt;
                $deliveredAt->add(new DateInterval('P' . $dayAdd . 'DT' . $hourAdd .  'H'));
                $dayAdd = $faker->randomElement(array(1, 2));
                $hourAdd = $faker->randomElement(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
                $finishedAt = clone $deliveredAt;
                $finishedAt->add(new DateInterval('P' . $dayAdd . 'DT' . $hourAdd .  'H'));
                $updatedAt = $finishedAt;
            }

            $order = [
                'order_number' => 'ORD-' . ($i + 1),
                'shipping_type' => $shippingType,
                'destination_type' => $faker->randomElement($randomDestIdx),
                'shipping_address' => $faker->address,
                'status' => $status,
                'shipping_cost' => 9000,
                'courier' => $shippingType == Order::PICKUP_ID ? null : $faker->randomElement($randomCourierIdx),
                'payment_type' => $faker->randomElement($randomPaymentTypeIdx),
                'user_id' => $user->id,
                'paid_at' => $paidAt ? $paidAt->format('Y-m-d H:i:s') : null,
                'processed_at' => $completedAt ? $completedAt->format('Y-m-d H:i:s') : null,
                'delivered_at' => $deliveredAt ? $deliveredAt->format('Y-m-d H:i:s') : null,
                'finished_at' => $finishedAt ? $finishedAt->format('Y-m-d H:i:s') : null,
                'created_at' => $createdAt->format('Y-m-d H:i:s'),
                'updated_at' => $updatedAt->format('Y-m-d H:i:s')
            ];
            $orderId = Order::insertGetId($order);

            $orderItemsSize = $faker->randomElement(array(1, 2, 3));
            $orderItems = [];
            $total = 0;
            for ($j = 0; $j < $orderItemsSize; ++$j) {
                $amount = $faker->randomElement(array(1, 2, 3, 4, 5));
                $documentType = $documentTypes[$faker->randomElement($randomDocTypeIdx)];
                $orderItems[$j] = [
                    'amount' => $amount,
                    'total' => $amount * $documentType->price,
                    'document_type_id' => $documentType->id,
                    'order_id' => $orderId,
                    'created_at' => $createdAt->format('Y-m-d H:i:s'),
                    'updated_at' => $createdAt->format('Y-m-d H:i:s')
                ];
                $total += ($amount * $documentType->price);
            }
            OrderItem::insert($orderItems);
            $order = Order::find($orderId);
            $order->total = $total + $order->shipping_cost;
            $order->save();
        }

        $randomAnncStatusIdx = [];
        $i = 0;
        foreach (Announcement::STATUS_SELECT as $id => $item) {
            $randomAnncStatusIdx[$i] = $id;
            ++$i;
        }

        for ($i = 0; $i < env('SIZEOFANNOUNCEMENT', 25); ++$i) {
            $createdAt = $faker->dateTimeBetween('-3 months');
            $status = $faker->randomElement($randomAnncStatusIdx);
            $contents = $faker->paragraphs();
            $strContent = '';
            foreach ($contents as $content) {
                $strContent = '<p>' . $strContent . $content . '</p>';
            }
            $announcement = [
                'title' => $faker->sentence,
                'content' => $strContent,
                'publish_date' => $status == Announcement::DRAFT_ID ? null : $createdAt->format('Y-m-d H:i:s'),
                'status' => $status,
                'created_at' => $createdAt->format('Y-m-d H:i:s'),
                'updated_at' => $createdAt->format('Y-m-d H:i:s')
            ];
            Announcement::insert($announcement);
        }
    }
}
