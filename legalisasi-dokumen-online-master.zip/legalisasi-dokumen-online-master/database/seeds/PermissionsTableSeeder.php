<?php

use App\Permission;
use Illuminate\Database\Seeder;

class PermissionsTableSeeder extends Seeder
{
    public function run()
    {
        $permissions = [
            [
                'title' => 'permission_access',
                'name'  => 'Mengakses Hak Akses'
            ],
            [
                'title' => 'role_create',
                'name'  => 'Membuat Peranan'
            ],
            [
                'title' => 'role_edit',
                'name'  => 'Mengubah Peranan'
            ],
            [
                'title' => 'role_show',
                'name'  => 'Menampilkan Peranan'
            ],
            [
                'title' => 'role_delete',
                'name'  => 'Menghapus Peranan'
            ],
            [
                'title' => 'role_access',
                'name'  => 'Mengakses Peranan'
            ],
            [
                'title' => 'user_create',
                'name'  => 'Membuat Pengguna'
            ],
            [
                'title' => 'user_edit',
                'name'  => 'Mengubah Pengguna'
            ],
            [
                'title' => 'user_show',
                'name'  => 'Menampilkan Pengguna'
            ],
            [
                'title' => 'user_delete',
                'name'  => 'Menghapus Pengguna'
            ],
            [
                'title' => 'user_access',
                'name'  => 'Mengakses Pengguna'
            ],
            [
                'title' => 'document_type_create',
                'name'  => 'Membuat Jenis Layanan Dokumen'
            ],
            [
                'title' => 'document_type_edit',
                'name'  => 'Mengubah Jenis Layanan Dokumen'
            ],
            [
                'title' => 'document_type_show',
                'name'  => 'Menampilkan Jenis Layanan Dokumen'
            ],
            [
                'title' => 'document_type_delete',
                'name'  => 'Menghapus Jenis Layanan Dokumen'
            ],
            [
                'title' => 'document_type_access',
                'name'  => 'Mengakses Jenis Layanan Dokumen'
            ],
            [
                'title' => 'master_data_access',
                'name'  => 'Mengakses Data Master'
            ],
            [
                'title' => 'order_show',
                'name'  => 'Menampilkan Pesanan'
            ],
            [
                'title' => 'order_edit',
                'name'  => 'Mengubah Status Pesanan'
            ],
            [
                'title' => 'order_access',
                'name'  => 'Mengakses Pesanan'
            ],
            [
                'title' => 'announcement_create',
                'name'  => 'Membuat Pengumuman'
            ],
            [
                'title' => 'announcement_edit',
                'name'  => 'Mengubah Pengumuman'
            ],
            [
                'title' => 'announcement_show',
                'name'  => 'Menampilkan Pengumuman'
            ],
            [
                'title' => 'announcement_delete',
                'name'  => 'Menghapus Pengumuman'
            ],
            [
                'title' => 'announcement_access',
                'name'  => 'Mengakses Pengumuman'
            ],
            [
                'title' => 'profile_password_edit',
                'name'  => 'Mengubah Password Pribadi'
            ],
        ];

        Permission::insert($permissions);
    }
}
