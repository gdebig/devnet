<?php

function getStudyProgramList()
{
    $path = 'additional-info.json';
    $orgData = json_decode(Illuminate\Support\Facades\Storage::disk('sso')->get($path), true);
    $studyPrograms = [];
    $index = 0;
    foreach ($orgData as $data) {
        if ($data['fullname'] == '') {
            continue;
        }
        $studyPrograms[$index] = $data['fullname'];
        ++$index;
    }

    return $studyPrograms;
}

function formatRupiah($number)
{
    $format = "Rp " . number_format($number,0,',','.');
    return $format;
}