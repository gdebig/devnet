<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use \DateTimeInterface;

class UserStatusHistory extends Model
{
    public $table = 'user_status_histories';

    protected $dates = [
        'created_at',
        'updated_at',

    ];

    protected $fillable = [
        'user_id',
        'status',
        'reason',
        'created_at',
        'updated_at',
    ];
}