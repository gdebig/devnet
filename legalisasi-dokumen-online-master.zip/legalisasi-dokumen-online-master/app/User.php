<?php

namespace App;

use Carbon\Carbon;
use Hash;
use Illuminate\Auth\Notifications\ResetPassword;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;
use Spatie\MediaLibrary\Models\Media;
use \DateTimeInterface;

class User extends Authenticatable implements HasMedia
{
    use SoftDeletes, Notifiable, HasApiTokens, HasMediaTrait;

    public $table = 'users';

    protected $hidden = [
        'remember_token',
        'password',
    ];

    protected $appends = [
        'certificate_file',
        'transcript_file',
        'signature_image',
    ];

    protected $dates = [
        'graduated_date',
        'email_verified_at',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'name',
        'type',
        'student_number',
        'phone_number',
        'address',
        'status',
        'graduated_date',
        'certificate_number',
        'transcript_number',
        'email',
        'email_verified_at',
        'is_admin',
        'password',
        'remember_token',
        'created_at',
        'updated_at',
        'deleted_at',
        'city_of_birth',
        'date_of_birth',
        'certificate_degree',
        'certificate_printed_number',
        'gpa',
        'thesis_title',
        'thesis_title_en',
        'is_graduated',
        'study_program',
    ];

    const UNVERIFIED_ID = 1;
    const VERIFIED_ID = 2;
    const REJECTED_ID = 3;
    const BLOCK_ID = 4;
    const NEED_FILL_FORM_ID = 5;

    const STATUS_SELECT = [
        User::UNVERIFIED_ID => 'Belum Terverifikasi',
        User::VERIFIED_ID => 'Terverifikasi',
        User::REJECTED_ID => 'Verifikasi Ditolak',
        User::BLOCK_ID => 'Pengguna Di-Block',
        User::NEED_FILL_FORM_ID => 'Belum isi form verifikasi'
    ];

    const STUDENT_ID = 1;
    const ALUMNI_ID = 2;

    const TYPE_SELECT = [
        User::STUDENT_ID => 'Mahasiswa',
        User::ALUMNI_ID => 'Alumni',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function getHasAdminRoleAttribute()
    {
        return $this->roles()->where('id', 1)->exists();
    }

    public function registerMediaConversions(Media $media = null)
    {
        $this->addMediaConversion('thumb')->fit('crop', 50, 50);
        $this->addMediaConversion('preview')->fit('crop', 120, 120);
    }

    public function userOrders()
    {
        return $this->hasMany(Order::class, 'user_id', 'id');
    }

    public function getGraduatedDateAttribute($value)
    {
        return $value ? Carbon::parse($value)->format(config('panel.date_format')) : null;
    }

    public function setGraduatedDateAttribute($value)
    {
        $this->attributes['graduated_date'] = $value ? Carbon::createFromFormat(config('panel.date_format'), $value)->format('Y-m-d') : null;
    }

    public function getCertificateFileAttribute()
    {
        $file = $this->getMedia('certificate_file')->last(); 

        if ($file) {
            $file->url = $file->getUrl();
        }

        return $file;
    }

    public function getTranscriptFileAttribute()
    {
        $file = $this->getMedia('transcript_file')->last();

        if ($file) {
            $file->url = $file->getUrl();
        }

        return $file;
    }

    public function getSignatureImageAttribute()
    {
        $file = $this->getMedia('signature_image')->last();

        if ($file) {
            $file->url       = $file->getUrl();
            $file->thumbnail = $file->getUrl('thumb');
            $file->preview   = $file->getUrl('preview');
        }

        return $file;
    }

    public function getEmailVerifiedAtAttribute($value)
    {
        return $value ? Carbon::createFromFormat('Y-m-d H:i:s', $value)->format(config('panel.date_format') . ' ' . config('panel.time_format')) : null;
    }

    public function setEmailVerifiedAtAttribute($value)
    {
        $this->attributes['email_verified_at'] = $value ? Carbon::createFromFormat(config('panel.date_format') . ' ' . config('panel.time_format'), $value)->format('Y-m-d H:i:s') : null;
    }

    public function setPasswordAttribute($input)
    {
        if ($input) {
            $this->attributes['password'] = app('hash')->needsRehash($input) ? Hash::make($input) : $input;
        }
    }

    public function sendPasswordResetNotification($token)
    {
        $this->notify(new ResetPassword($token));
    }

    public function roles()
    {
        return $this->belongsToMany(Role::class);
    }

    public function userStatusHistories()
    {
        return $this->hasMany(UserStatusHistory::class, 'user_id');
    }

    public function getIsStudentAttribute()
    {
        return $this->type === self::STUDENT_ID;
    }

    public function getIsAlumniAttribute()
    {
        return $this->type === self::ALUMNI_ID;
    }
}
