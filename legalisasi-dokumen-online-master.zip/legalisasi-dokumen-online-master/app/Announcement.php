<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;
use Spatie\MediaLibrary\Models\Media;
use \DateTimeInterface;

class Announcement extends Model implements HasMedia
{
    use SoftDeletes, HasMediaTrait;

    public $table = 'announcements';

    protected $dates = [
        'publish_date',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'title',
        'content',
        'publish_date',
        'status',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    const DRAFT_ID = 1;
    const PUBLISH_ID = 2;
    const STATUS_SELECT = [
        Announcement::DRAFT_ID => 'Draft',
        Announcement::PUBLISH_ID => 'Terpublikasikan'
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function registerMediaConversions(Media $media = null)
    {
        $this->addMediaConversion('thumb')->fit('crop', 50, 50);
        $this->addMediaConversion('preview')->fit('crop', 120, 120);
    }

    public function getPublishDateAttribute($value)
    {
        return $value ? Carbon::createFromFormat('Y-m-d H:i:s', $value)->format(config('panel.date_format') . ' ' . config('panel.time_format')) : null;
    }

    public function setPublishDateAttribute($value)
    {
        $this->attributes['publish_date'] = $value ? Carbon::createFromFormat(config('panel.date_format') . ' ' . config('panel.time_format'), $value)->format('Y-m-d H:i:s') : null;
    }

    public function scopePublished($query)
    {
        $query->where('status', self::PUBLISH_ID)->whereNotNull('publish_date');
    }

    public function scopeLatest($query)
    {
        $query->orderBy('publish_date', 'desc');
    }
}
