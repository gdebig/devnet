<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

use App\Order;
use App\OrderStatusHistory;

class OrdersAutoFinish extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'order:autofinish';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Auto finish order yang sudah dalam waktu tertentu';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $now = date('Y-m-d H:i:s');
        $minutesToAutoFinish = env('ORDER_AUTO_FINISH', 10080);
        
        DB::beginTransaction();

        try {
            $orders = Order::whereRaw('date_add(updated_at, interval ? minute) <= ?', [$minutesToAutoFinish, $now])
                    ->where(function ($query) {
                        $query->where('status', Order::READY_TO_PICKUP_ID)
                            ->orWhere('status', Order::ON_DELIVERY_ID);
                    })->get();
            foreach ($orders as $order) {
                $order->is_auto_finish = true;
                $order->finished_at = $now;
                $order->status = Order::FINISH_ID;
                $order->save();

                $orderStatusHistory = new OrderStatusHistory;
                $orderStatusHistory->order_id = $order->id;
                $orderStatusHistory->reason = 'Auto Finish';
                $orderStatusHistory->status = Order::FINISH_ID;
                $orderStatusHistory->save();
            }
            echo count($orders);
            DB::commit();
        } catch (\Exception $e) {
            echo $e;
            DB::rollback();
        }
    }
}
