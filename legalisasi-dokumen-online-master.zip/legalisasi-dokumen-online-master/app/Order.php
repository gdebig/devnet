<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use \DateTimeInterface;

use DB;

class Order extends Model
{
    use SoftDeletes;

    public $table = 'orders';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
        'paid_at',
        'processed_at',
        'delivered_at',
        'finished_at'

    ];

    protected $fillable = [
        'order_number',
        'shipping_type',
        'destination_type',
        'courier',
        'payment_type',
        'shipping_address',
        'shipping_cost',
        'status',
        'is_auto_finish',
        'user_id',
        'review',
        'paid_at',
        'processed_at',
        'delivered_at',
        'finished_at',
        'created_at',
        'updated_at',
        'deleted_at',
        'country_id',
        'province_id',
        'city_id',
        'district_id',
        'subdistrict',
        'postal_code',
        'total',
        'address_info',
        'courier_service',
        'receipt_number',
        'notes'
    ];

    const LOCAL_ID = 1;
    const INTERNATIONAL_ID = 2;
    const DESTINATION_TYPE_SELECT = [
        Order::LOCAL_ID => 'Domestik',
        Order::INTERNATIONAL_ID => 'Luar Negeri'
    ];

    const DELIVERY_ID = 1;
    const PICKUP_ID = 2;
    const SHIPPING_TYPE_SELECT = [
        Order::DELIVERY_ID => 'Dikirim ke alamat tertentu',
        Order::PICKUP_ID => 'Diambil di FTUI'
    ];

    const CC_ID = 'credit_card';
    const BANK_TRANSFER_ID = 'bank_transfer';
    const GOPAY_ID = 'gopay';
    const BCA_ID = 'bca_klikpay';
    const CIMB_ID = 'cimb_clicks';
    const DANAMON_ID = 'danamon_online';
    const AKULAKU_ID = 'akulaku';
    const CSTORE_ID = 'cstore';
    const ECHANNEL_ID = 'echannel';
    
    const PAYMENT_TYPE_SELECT = [
        Order::CC_ID => 'Credit Card',
        Order::BANK_TRANSFER_ID => 'Bank Transfer',
        Order::GOPAY_ID => 'Gopay',
        Order::BCA_ID => 'BCA Klikpay',
        Order::CIMB_ID => 'CIMB Clicks',
        Order::DANAMON_ID => 'Danamon Online',
        Order::AKULAKU_ID => 'Akulaku',
        Order::CSTORE_ID => 'Alfamart/Indomaret',
        Order::ECHANNEL_ID => 'Bank Transfer',
    ];

    const JNE_ID = 1;
    const JNT_ID = 2;
    const TIKI_ID = 3;
    const POS_ID = 4;
    const COURIER_SELECT = [
        Order::JNE_ID => 'JNE',
        Order::JNT_ID => 'JNT',
        Order::TIKI_ID => 'Tiki',
        Order::POS_ID => 'Pos'
    ];

    const NOT_YET_PAID_ID = 1;
    const PAID_ID = 2;
    const PROCESSED_ID = 3;
    const READY_TO_PICKUP_ID = 4;
    const ON_DELIVERY_ID = 5;
    const FINISH_ID = 6;
    const ORDER_PROBLEM_ID = 7;
    const STATUS_SELECT = [
        Order::NOT_YET_PAID_ID => 'Menunggu Pembayaran',
        Order::PAID_ID => 'Sudah Dibayar',
        Order::PROCESSED_ID => 'Dokumen Sedang Diproses',
        Order::READY_TO_PICKUP_ID => 'Siap Diambil',
        Order::ON_DELIVERY_ID => 'Sedang Dikirim',
        Order::FINISH_ID => 'Pemesanan Selesai',
        Order::ORDER_PROBLEM_ID => 'Pemesanan Bermasalah'
    ];

    public static function boot()
    {
        parent::boot();

        self::creating(function($model){
            // ... code here
            // latest ID 
            $statement = DB::select("SHOW TABLE STATUS LIKE 'orders'");
            $nextId = $statement[0]->Auto_increment;
            $model->order_number = 'ORD-'.$nextId;
            $model->status = Order::NOT_YET_PAID_ID;
        });
    }

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function orderItems()
    {
        return $this->hasMany(OrderItem::class, 'order_id', 'id');
    }

    public function orderStatusHistories()
    {
        return $this->hasMany(OrderStatusHistory::class, 'order_id', 'id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function scopeUnfinished($query)
    {
        $query->whereNotIn('status', [self::FINISH_ID]);
    }

    public function scopeFinished($query)
    {
        $query->whereIn('status', [self::FINISH_ID]);
    }

    public function getStatusProgressAttribute()
    {
        $progress = self::STATUS_SELECT;
        switch($this->status)
        {
            case self::ON_DELIVERY_ID :
                unset($progress[self::READY_TO_PICKUP_ID]);
                unset($progress[self::ORDER_PROBLEM_ID]);
                $progress[self::ON_DELIVERY_ID] = self::STATUS_SELECT[self::ON_DELIVERY_ID];
                break;
            case self::ORDER_PROBLEM_ID :
                unset($progress[self::FINISH_ID]);
                unset($progress[self::ON_DELIVERY_ID]);
                $progress[self::ORDER_PROBLEM_ID] = self::STATUS_SELECT[self::ORDER_PROBLEM_ID];
                break;
            default:
                unset($progress[self::ORDER_PROBLEM_ID]);
                unset($progress[self::ON_DELIVERY_ID]);
                break;
        }
        return $progress;
    }
}
