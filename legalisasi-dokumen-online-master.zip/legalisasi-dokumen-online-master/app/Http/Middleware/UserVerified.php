<?php

namespace App\Http\Middleware;

use Closure;

use Auth;
use App\User;

class UserVerified
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = Auth::user();
        if(!$user) {
            return route('home');
        } elseif($user->status === User::NEED_FILL_FORM_ID) {
            // not verified;
            return redirect()->route('user.verification.form');
        } elseif($user->status === User::VERIFIED_ID) {
            // verified or else;
            return $next($request);
        }
        return $next($request);
    }
}
