<?php

namespace App\Http\Middleware;

use Closure;

class AdminAuthenticate
{
    public function handle($request, Closure $next)
    {
        $user = \Auth::user();

        if ($user && (!$user->is_admin || $user->status != \App\User::VERIFIED_ID)) {
            return redirect()->intended('/');
        }

        return $next($request);
    }
}
