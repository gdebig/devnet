<?php

namespace App\Http\Middleware;

use App\User;
use App\Http\Helpers\SSO;

use Illuminate\Support\Facades\Session;

use Closure;

class UserAuthenticate
{
    public function handle($request, Closure $next)
    {
        $user = \Auth::user();
        
        if (!$user) {
            $isLogin = SSO::check();
            if($isLogin) {
                $ssoUser = SSO::getUser();
                if ($ssoUser != null && ($ssoUser->role && $ssoUser->role == 'mahasiswa' || $ssoUser->username == 'bigzaman')) {
                    $this->attempLoginSSO($ssoUser);
                } else {
                    $warningMessage = 'Anda melakukan login SSO UI tidak sebagai mahasiswa FT UI, silakan '
                        . '<a href="#" onclick="event.preventDefault();document.getElementById(\'logout-form\').submit();">logout</a>' 
                        . ' dan login kembali menggunakan akun mahasiswa FT UI';
                    Session::flash('warning', $warningMessage);
                }
            }
        }
        return $next($request);
    }

    private function attempLoginSSO($ssoUser)
    {
        $studentNumber = $ssoUser->username != 'bigzaman' ? $ssoUser->npm : $ssoUser->nip;
        $user = User::firstOrNew(
            [
                'student_number' => $studentNumber
            ]
        );
        $user->is_admin = false;
        $user->name = $ssoUser->name;
        $user->study_program = $ssoUser->fullname ?? '';
        $user->type = User::STUDENT_ID;
        $user->status = User::VERIFIED_ID;
        $user->password = $studentNumber;
        $user->save();

        return \Auth::guard()->attempt(
            [
                'student_number' => $studentNumber,
                'password' => $studentNumber
            ]
        );
    }
}
