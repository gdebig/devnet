<?php

namespace App\Http\Requests;

use App\User;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class StoreUserRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('user_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return true;
    }

    public function rules()
    {
        return [
            'name'           => [
                'required',
            ],
            // 'type'           => [
            //     'required',
            // ],
            'student_number' => [
                // 'required',
                'exclude_if:student_number,""',
                'unique:users',
            ],
            // 'phone_number'   => [
            //     'required',
            // ],
            // 'address'        => [
            //     'required',
            // ],
            'date_of_birth' => [
                'date_format:' . config('panel.date_format'),
                'nullable',
            ],
            'graduated_date' => [
                'date_format:' . config('panel.date_format'),
                'nullable',
            ],
            'gpa' => [
                'numeric',
                'between:0,4:',
                'nullable'
            ],
            'email'          => [
                'required',
                'unique:users',
            ],
            'password'       => [
                'required',
                'min:6'
            ],
            'roles.*'        => [
                'integer',
            ],
            'roles'          => [
                'array',
            ],
        ];
    }

    public function messages()
    {
        return [
            'student_number.unique' => 'Isian NPM sudah ada sebelumnya',
        ];
    }
}
