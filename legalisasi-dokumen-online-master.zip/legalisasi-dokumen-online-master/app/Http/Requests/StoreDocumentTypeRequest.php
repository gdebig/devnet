<?php

namespace App\Http\Requests;

use App\DocumentType;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class StoreDocumentTypeRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('document_type_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return true;
    }

    public function rules()
    {
        return [
            'name'  => [
                'required',
                'unique:document_types',
            ],
            'price' => [
                'required',
            ],
            'weight' => [
                'integer',
                'required',
            ],
        ];
    }

    public function messages()
    {
        return [
            'name.unique' => 'Isian Nama sudah ada sebelumnya',
        ];
    }
}
