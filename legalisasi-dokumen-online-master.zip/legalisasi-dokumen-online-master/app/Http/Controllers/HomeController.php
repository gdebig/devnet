<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Http\Controllers\Traits\MidtransTrait;
use App\User;

class HomeController extends Controller
{
    use AuthenticatesUsers, MidtransTrait;
    // /**
    //  * Create a new controller instance.
    //  *
    //  * @return void
    //  */
    // public function __construct()
    // {
    //     // $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        // dd('test123123');
        if(\Auth::user()) {
            return redirect()->route('user.home');
        }
        return view('user.home');
    }

    public function announcement()
    {
        return view('user.announcement');
    }

    public function emailVerified($userID)
    {
        $decrypted = decrypt($userID);
        if($decrypted) {
            $user = User::where('id', $decrypted)->first();
            if($user && !$user->email_verified_at) {
                $user->email_verified_at = date('Y-m-d H:i:s');
                $user->save();
                
                return redirect()->route('login')->with(['message' => 'Berhasil melakukan aktivasi']);
            }
        }
        return redirect()->route('login')->with(['message' => 'Gagal melakukan aktivasi']);
    }
}
