<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Http\Resources\Admin\UserResource;
use App\User;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class UsersApiController extends Controller
{
    use MediaUploadingTrait;

    public function index()
    {
        abort_if(Gate::denies('user_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new UserResource(User::with(['roles'])->get());
    }

    public function store(StoreUserRequest $request)
    {
        $user = User::create($request->all());
        $user->roles()->sync($request->input('roles', []));

        if ($request->input('certificate_file', false)) {
            $user->addMedia(storage_path('tmp/uploads/' . $request->input('certificate_file')))->toMediaCollection('certificate_file');
        }

        if ($request->input('transcript_file', false)) {
            $user->addMedia(storage_path('tmp/uploads/' . $request->input('transcript_file')))->toMediaCollection('transcript_file');
        }

        if ($request->input('signature_image', false)) {
            $user->addMedia(storage_path('tmp/uploads/' . $request->input('signature_image')))->toMediaCollection('signature_image');
        }

        return (new UserResource($user))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(User $user)
    {
        abort_if(Gate::denies('user_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new UserResource($user->load(['roles']));
    }

    public function update(UpdateUserRequest $request, User $user)
    {
        $user->update($request->all());
        $user->roles()->sync($request->input('roles', []));

        if ($request->input('certificate_file', false)) {
            if (!$user->certificate_file || $request->input('certificate_file') !== $user->certificate_file->file_name) {
                if ($user->certificate_file) {
                    $user->certificate_file->delete();
                }

                $user->addMedia(storage_path('tmp/uploads/' . $request->input('certificate_file')))->toMediaCollection('certificate_file');
            }
        } elseif ($user->certificate_file) {
            $user->certificate_file->delete();
        }

        if ($request->input('transcript_file', false)) {
            if (!$user->transcript_file || $request->input('transcript_file') !== $user->transcript_file->file_name) {
                if ($user->transcript_file) {
                    $user->transcript_file->delete();
                }

                $user->addMedia(storage_path('tmp/uploads/' . $request->input('transcript_file')))->toMediaCollection('transcript_file');
            }
        } elseif ($user->transcript_file) {
            $user->transcript_file->delete();
        }

        if ($request->input('signature_image', false)) {
            if (!$user->signature_image || $request->input('signature_image') !== $user->signature_image->file_name) {
                if ($user->signature_image) {
                    $user->signature_image->delete();
                }

                $user->addMedia(storage_path('tmp/uploads/' . $request->input('signature_image')))->toMediaCollection('signature_image');
            }
        } elseif ($user->signature_image) {
            $user->signature_image->delete();
        }

        return (new UserResource($user))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(User $user)
    {
        abort_if(Gate::denies('user_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $user->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
