<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\VerificationUserRequest;

use App\User;
use Auth;

class VerificationController extends Controller
{
    public function form(Request $request)
    {
        $user = Auth::user();
        $studyPrograms = getStudyProgramList();
        return view('user.verifications.form-verification-alumni', compact('user', 'studyPrograms'));
    }

    public function store(VerificationUserRequest $request)
    {
        $input = $request->all();
        $user = Auth::user();
        $input = array_merge($input, ['status' => User::UNVERIFIED_ID]);
        $user->update($input);

        if ($request->input('certificate_file', false)) {
            if (!$user->certificate_file || $request->input('certificate_file') !== $user->certificate_file->file_name) {
                if ($user->certificate_file) {
                    $user->certificate_file->delete();
                }

                $user->addMedia(storage_path('tmp/uploads/' . $request->input('certificate_file')))->toMediaCollection('certificate_file', 'private-file');
            }
        } elseif ($user->certificate_file) {
            $user->certificate_file->delete();
        }

        if ($request->input('transcript_file', false)) {
            if (!$user->transcript_file || $request->input('transcript_file') !== $user->transcript_file->file_name) {
                if ($user->transcript_file) {
                    $user->transcript_file->delete();
                }

                $user->addMedia(storage_path('tmp/uploads/' . $request->input('transcript_file')))->toMediaCollection('transcript_file', 'private-file');
            }
        } elseif ($user->transcript_file) {
            $user->transcript_file->delete();
        }

        return redirect()->route('user.profile')->with('message', trans('user.success_verification'));
    }
}