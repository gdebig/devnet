<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Traits\MediaUploadingTrait;

class HomeController extends Controller
{
    use MediaUploadingTrait;

    public function index(Request $request)
    {
        return redirect()->route('user.order');
    }
}