<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\User;

class ProfileController extends Controller
{
    public function index(Request $request)
    {
        return view('user.profiles.index');
    }

    public function update(Request $request)
    {
        $user = User::where('id', $request->id)->first();
        
        $input = $request->all();
        $user->update($input);

        $message = 'Data profile berhasil disimpan';
        return redirect()->back()->with(['message' => $message]);
    }
}