<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\RegisterUserRequest;

use Intervention\Image\ImageManagerStatic as Image;

use App\Notifications\NewUser;

use App\User;
use DB;

class RegisterNewAlumniController extends Controller
{
    public function index(Request $request)
    {
        // clear session
        $request->session()->forget('register');

        return redirect()->route('register-new-alumni.account');
    }

    private function updateRegisterSession($request)
    {
        $input = $request->except('_token');

        $register = $request->session()->get('register') ?? array();
        $register = array_merge($register, $input);
        
        $request->session()->put('register', $register);
    }

    // AccountForm
    public function formAccount(Request $request)
    {
        $register = (object) $request->session()->get('register');

        return view('user.register-new-alumnis.form-account', compact('register'));
    }

    public function createAccount(RegisterUserRequest $request)
    {
        $this->updateRegisterSession($request);

        return redirect()->route('register-new-alumni.certificate');
    }

    // CertificateForm
    public function formCertificate(Request $request)
    {
        $register = (object) $request->session()->get('register');
        if(!isset($register->student_number))
        {
            return redirect()->back()->with(['message' => 'Silahkan lengkapi data terlebih dahulu']);
        }
        $studyPrograms = getStudyProgramList();
        
        return view('user.register-new-alumnis.form-certificate', compact('register', 'studyPrograms'));
    }

    public function createCertificate(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required',
            'city_of_birth' => 'required',
            'date_of_birth' => 'required',
            'graduated_date' => 'required',
            'certificate_printed_number' => 'required',
            // 'certificate_number' => 'required',
            'certificate_degree' => 'required',
            // 'certificate_file' => 'required',
        ]);

        $this->updateRegisterSession($request);

        return redirect()->route('register-new-alumni.transcript');
    }

    // TranscriptForm
    public function formTranscript(Request $request)
    {
        $register = (object) $request->session()->get('register');
        if(!isset($register->name))
        {
            return redirect()->back()->with(['message' => 'Silahkan lengkapi data terlebih dahulu']);
        }
        return view('user.register-new-alumnis.form-transcript', compact('register'));
    }

    public function createTranscript(Request $request)
    {
        $validatedData = $request->validate([
            'gpa' => 'required',
            // 'transcript_number' => 'required',
            // 'transcript_file' => 'required',
            'signature_image' => 'required'
        ]);

        $this->updateRegisterSession($request);

        // insert session into user
        $input = $request->session()->get('register');
        $input = array_merge($input, ['type' => USER::ALUMNI_ID, 'status' => USER::NEED_FILL_FORM_ID]);
        DB::beginTransaction();

        $user = User::create($input);
        
        $input['signature_image'] = $this->storeTempSignatureImage($input['signature_image'], $input['student_number']);
        
        if(isset($input['certificate_file'])) {
            $user->addMedia(storage_path('tmp/uploads/' . $input['certificate_file']))->toMediaCollection('certificate_file', 'private-file');
        }
        if(isset($input['transcript_file'])) {
            $user->addMedia(storage_path('tmp/uploads/' . $input['transcript_file']))->toMediaCollection('transcript_file', 'private-file');
        }
        $user->addMedia(storage_path('tmp/uploads/' . $input['signature_image']))->toMediaCollection('signature_image', 'private-file');
        $user->notify(new NewUser($user));

        DB::commit();
        $request->session()->forget('register');
        
        return redirect()->route('register-new-alumni.account')->with('message', trans('user.success_register'));
    }

    private function storeTempSignatureImage($signatureImage, $studentNumber)
    {
        $path = storage_path('tmp/uploads/');

        try {
            if (!file_exists($path)) {
                mkdir($path, 0755, true);
            }
        } catch (\Exception $e) {
        }

        $name = uniqid() . '_' . trim('s-'.$studentNumber.'.jpg');
        $path = $path.'/'.$name;
        Image::make(file_get_contents($signatureImage))->save($path);
        return $name;
    }
}