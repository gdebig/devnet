<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Traits\ShippingCostTrait;
use App\Http\Controllers\Traits\MidtransTrait;

use Auth;
use DB;
use Log;
use App\Order;
use App\DocumentType;
use Validator;

class OrderController extends Controller
{
    // Order 
    // Created By Uwais Iskandar
    // 
    use ShippingCostTrait, MidtransTrait;

    public function index(Request $request)
    {
        return view('user.orders.index');
    }

    public function history(Request $request)
    {
        $orders = Auth::user()->userOrders()->finished()->orderBy('created_at', 'desc')->paginate(10);
        
        return view('user.orders.order-all-history', compact('orders'));
    }

    public function status(Request $request)
    {
        $orders = Auth::user()->userOrders()->unfinished()->orderBy('created_at', 'desc')->paginate(10);
        
        return view('user.orders.order-all-status', compact('orders'));
    }

    public function createOrder(Request $request)
    {
        $request->session()->forget('order');

        return redirect()->route('user.order.user');
    }

    private function updateOrderSession($request)
    {
        $input = $request->except('_token');

        $order = $request->session()->get('order') ?? array();
        $order = array_merge($order, $input);
        
        $request->session()->put('order', $order);
    }

    public function formUser(Request $request)
    {
        $order = (object) $request->session()->get('order');
        $user = Auth::user();

        return view('user.create-orders.form-user', compact('order', 'user'));
    }

    public function saveUser(Request $request)
    {
        $user = \App\User::where('id', $request->user_id)->first()->toArray();
        $userRules = [
            'name' => 'required',
            'student_number' => 'required',
            'email' => 'required',
            'phone_number' => 'required',
            'address' => 'required'
        ];
        $messages = [
            'student_number.required' => 'NPM diperlukan!',
            'phone_number.required' => 'No HP diperlukan!',
            'address.required' => 'Alamat diperlukan!',
        ];
        $v = Validator::make($user, $userRules, $messages);
    
        if ($v->fails())
        {
            return redirect()->back()->withErrors($v->errors());
        }
        $this->updateOrderSession($request);
        
        return redirect()->route('user.order.docs');
    }

    public function formDocs(Request $request)
    {
        $order = (object) $request->session()->get('order');
        // dd($order);
        $user = Auth::user();

        return view('user.create-orders.form-doc', compact('order', 'user'));
    }

    public function saveDocs(Request $request)
    {
        $docRules = [
            'order_item_doc_type' => 'required',
            'notes' => 'max:255'
        ];
        $messages = [
            'order_item_doc_type.required' => 'Jenis dokumen diperlukan!'
        ];
        $this->validate($request, $docRules, $messages);
        $this->updateOrderSession($request);
        
        return redirect()->route('user.order.review');
    }

    public function review(Request $request)
    {
        $order = (object) $request->session()->get('order');
        $user = Auth::user();

        return view('user.create-orders.review', compact('order', 'user'));
    }

    public function saveReview(Request $request)
    {
        $order = $request->session()->get('order');
        
        DB::beginTransaction();
        $newOrder = Order::create($order);
        // create item
        foreach(DocumentType::whereIn('id', $order['order_item_doc_type'])->get() as $key => $docType) 
        {
            $newOrder->orderItems()->create([
                'document_type_id' => $docType->id,
                'amount' => $order['order_item_amount'][$key],
                'total' => $order['order_item_amount'][$key] * $docType->price
            ]);
        }
        $midtransToken = $this->prepareMidtransPayment($newOrder);
        $newOrder->payment_token = $midtransToken;
        $newOrder->save();
        $this->updateOrderStatusHistories($newOrder, 'Order dibuat', Order::NOT_YET_PAID_ID, $newOrder->user_id);

        DB::commit();
        return redirect()->route('user.order.payment', ['id' => $newOrder->order_number]);
    }

    public function formPayment(Request $request, $orderNumber)
    {
        $order = Order::where('order_number', $orderNumber)->first();
        if($order->status != Order::NOT_YET_PAID_ID) 
        {
            return redirect('/');
        }
        if(!$order->payment_token)
        {
            // generate payment if token is null
            $order->payment_token = $this->prepareMidtransPayment($order);
            $order->save();
        }
        $midtransToken = $order->payment_token;
        return view('user.create-orders.payment', compact('order', 'midtransToken'));
    }

    public function detail(Request $request, $orderNumber)
    {
        $user = Auth::user();
        $order = Order::where('order_number', $orderNumber)->where('user_id', $user->id)->first();
        if(!$order) {
            return redirect()->route('home')->with(['message' => 'Maaf, order tidak ditemukan']);
        }

        // get shipping_names
        $order->country_name = $this->getNameAddress($order->country_id, '/internationalDestination', 'country_name');
        $order->province_name = $this->getNameAddress($order->province_id, '/province', 'province');
        $order->city_name = $this->getNameAddress($order->city_id, '/city', 'city_name');
        $order->district_name = $this->getNameAddress($order->district_id, '/subdistrict', 'subdistrict_name');
        return view('user.orders.order-detail', compact('order'));
    }

    private function getNameAddress($id = null, $path, $key)
    {
        if(!$id) {
            return null;
        }
        $params = ['id' => $id];
        $res = $this->rajaOngkirRequest($path, 'GET', $params);
        if($path === '/city' && $res) {
            return $res->type.' '.$res->city_name;
        }
        return $res->$key ?? null;
    }

    public function midtransNotification(Request $request)
    {
        // logging request
        Log::channel('midtrans')->info('Midtrans Notifications! :'.json_encode($request->all()));
        $signatureArray = [$request->order_id, $request->status_code, $request->gross_amount, env('MIDTRANS_KEY')];
        if($request->signature_key !== $this->checkSignature($signatureArray)) {
            return response()->json(['message' => 'signature failed'], 400);
        }

        $orderID = explode('|', $request->order_id)[1] ?? null;
        $order = Order::where('order_number', $orderID)->where('status', Order::NOT_YET_PAID_ID)->first();
        if(!$order) {
            return 400;
        }
        
        DB::beginTransaction();
        switch($request->transaction_status) {
            case 'capture':
            case 'settlement':
                // success
                $order->status = Order::PAID_ID;
                $order->paid_at = date('Y-m-d H:i:s');
                $this->updateOrderStatusHistories($order, 'Order berhasil dibayar | Midtrans - Payment Gateway', Order::PAID_ID);
                break;
            case 'deny':
            case 'cancel':
            case 'expire' :
                // failed
                $order->status = Order::ORDER_PROBLEM_ID;
                $this->updateOrderStatusHistories($order, 'Order gagal | Midtrans - Payment Gateway', Order::ORDER_PROBLEM_ID);
                break;
            case 'refund':
                // refund
                $order->status = Order::ORDER_PROBLEM_ID;
                $this->updateOrderStatusHistories($order, 'Order gagal | Midtrans - Payment Gateway', Order::ORDER_PROBLEM_ID);
                break;
            default:
                // pending
                if(!$order->payment_type) {
                    $order->payment_type = $request->payment_type;
                    if($request->payment_type === 'bank_transfer') {
                        if($request->permata_va_number) {
                            $order->payment_info = json_encode([['va_number'=> $request->permata_va_number, 'bank'=> 'permata']]);
                        } else {
                            $order->payment_info = $request->va_numbers;
                        }
                    } elseif($request->payment_type === 'echannel') {
                        $order->payment_info = json_encode([['biller_code'=> $request->biller_code, 'bill_key'=> $request->bill_key]]);
                    }
                }
                break;
        }
        $order->save();
        
        DB::commit();

        return 200;
    }
}