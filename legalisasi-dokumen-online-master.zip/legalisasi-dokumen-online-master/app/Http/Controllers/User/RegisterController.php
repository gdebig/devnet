<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\RegisterUserRequest;

use App\User;
use DB;

use App\Notifications\NewUser;

class RegisterController extends Controller
{
    public function indexAlumni(Request $request)
    {
        return view('user.register-alumni');
    }

    public function createUserAlumni(RegisterUserRequest $request)
    {
        $input = $request->all();
        $input = array_merge($input, ['status' => User::NEED_FILL_FORM_ID, 'type' => User::ALUMNI_ID]);

        DB::beginTransaction();
        $user = User::create($input);
        // send Email
        $user->notify(new NewUser($user));
        
        DB::commit();

        return redirect()->route('login')->with('message', trans('user.success_register'));
    }
}