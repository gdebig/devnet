<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\MassDestroyUserRequest;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Role;
use App\User;
use App\UserStatusHistory;
use Gate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Spatie\MediaLibrary\Models\Media;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class UsersController extends Controller
{
    use MediaUploadingTrait;

    public function index(Request $request)
    {
        abort_if(Gate::denies('user_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $user = \Auth::user();
            $type = $request->type;
            $status = $request->status;

            $query = User::with(['roles'])->select(sprintf('%s.*', (new User)->table));

            if ($type) {
                $query = $query->where('type', $type);
            }
            if ($status) {
                $query = $query->where('status', $status);
            }

            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) use ($user) {
                $viewGate      = 'user_show';
                $editGate      = 'user_edit';
                $deleteGate    = $row->id == $user->id ? '' : 'user_delete';
                $crudRoutePart = 'users';

                $statusAction = view('admin.users.partials.verificationAction', compact('row'));

                return view('partials.datatablesActions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                )) . $statusAction;
            });

            $table->editColumn('name', function ($row) {
                return $row->name ? $row->name : "";
            });
            $table->editColumn('type', function ($row) {
                return $row->type ? User::TYPE_SELECT[$row->type] : '';
            });
            $table->editColumn('student_number', function ($row) {
                return $row->student_number ? $row->student_number : '';
            });
            $table->editColumn('phone_number', function ($row) {
                return $row->phone_number ? $row->phone_number : '';
            });
            $table->editColumn('status', function ($row) use ($user) {
                return $row->status ? User::STATUS_SELECT[$row->status] : '';
            });
            $table->editColumn('email', function ($row) {
                return $row->email ? $row->email : '';
            });
            $table->editColumn('roles', function ($row) {
                if (!$row->is_admin) {
                    return '';
                }

                $labels = [];

                foreach ($row->roles as $role) {
                    $labels[] = sprintf('<span class="badge badge-info">%s</span>', $role->title);
                }

                return implode(' ', $labels);
            });

            $table->rawColumns(['actions', 'placeholder', 'roles', 'status']);

            return $table->make(true);
        }

        return view('admin.users.index');
    }

    public function create()
    {
        abort_if(Gate::denies('user_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $roles = Role::all()->pluck('title', 'id');
        $studyPrograms = getStudyProgramList();

        return view('admin.users.create', compact('roles', 'studyPrograms'));
    }

    public function store(StoreUserRequest $request)
    {
        $input = $request->all();
        array_key_exists('is_admin', $input) ? $input['is_admin'] = 1 : $input = array_merge($input, ['is_admin' => 0]);
        array_key_exists('is_graduated', $input) ? $input['is_graduated'] = 1 : $input = array_merge($input, ['is_graduated' => 0]);
        $input = array_merge($input, ['status' => User::UNVERIFIED_ID]);
        $user = User::create($input);
        $user->roles()->sync($request->input('roles', []));

        if ($request->input('certificate_file', false)) {
            $user->addMedia(storage_path('tmp/uploads/' . $request->input('certificate_file')))->toMediaCollection('certificate_file', 'private-file');
        }

        if ($request->input('transcript_file', false)) {
            $user->addMedia(storage_path('tmp/uploads/' . $request->input('transcript_file')))->toMediaCollection('transcript_file', 'private-file');
        }

        if ($request->input('signature_image', false)) {
            $user->addMedia(storage_path('tmp/uploads/' . $request->input('signature_image')))->toMediaCollection('signature_image', 'private-file');
        }

        if ($media = $request->input('ck-media', false)) {
            Media::whereIn('id', $media)->update(['model_id' => $user->id]);
        }

        return redirect()->route('admin.users.index')->with('message', trans('cruds.user.success_create'));
    }

    public function edit(User $user)
    {
        abort_if(Gate::denies('user_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $roles = Role::all()->pluck('title', 'id');
        $studyPrograms = getStudyProgramList();

        $user->load('roles');

        return view('admin.users.edit', compact('roles', 'user', 'studyPrograms'));
    }

    public function update(UpdateUserRequest $request, User $user)
    {
        $input = $request->all();
        array_key_exists('is_admin', $input) ? $input['is_admin'] = 1 : $input = array_merge($input, ['is_admin' => 0]);
        array_key_exists('is_graduated', $input) ? $input['is_graduated'] = 1 : $input = array_merge($input, ['is_graduated' => 0]);
        $user->update($input);
        $user->roles()->sync($request->input('roles', []));

        if ($request->input('certificate_file', false)) {
            if (!$user->certificate_file || $request->input('certificate_file') !== $user->certificate_file->file_name) {
                if ($user->certificate_file) {
                    $user->certificate_file->delete();
                }

                $user->addMedia(storage_path('tmp/uploads/' . $request->input('certificate_file')))->toMediaCollection('certificate_file', 'private-file');
            }
        } elseif ($user->certificate_file) {
            $user->certificate_file->delete();
        }

        if ($request->input('transcript_file', false)) {
            if (!$user->transcript_file || $request->input('transcript_file') !== $user->transcript_file->file_name) {
                if ($user->transcript_file) {
                    $user->transcript_file->delete();
                }

                $user->addMedia(storage_path('tmp/uploads/' . $request->input('transcript_file')))->toMediaCollection('transcript_file', 'private-file');
            }
        } elseif ($user->transcript_file) {
            $user->transcript_file->delete();
        }

        if ($request->input('signature_image', false)) {
            if (!$user->signature_image || $request->input('signature_image') !== $user->signature_image->file_name) {
                if ($user->signature_image) {
                    $user->signature_image->delete();
                }

                $user->addMedia(storage_path('tmp/uploads/' . $request->input('signature_image')))->toMediaCollection('signature_image', 'private-file');
            }
        } elseif ($user->signature_image) {
            $user->signature_image->delete();
        }

        return redirect()->route('admin.users.index')->with('message', trans('cruds.user.success_edit'));
    }

    public function verified(User $user)
    {
        abort_if(Gate::denies('user_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($user->id == \Auth::user()->id) {
            return redirect()->route('admin.users.index')->with('error', trans('global.forbidden'));
        }

        DB::beginTransaction();

        try {
            $user->status = User::VERIFIED_ID;
            $user->save();

            $userStatusHistory = new UserStatusHistory;
            $userStatusHistory->user_id = $user->id;
            $userStatusHistory->status = User::VERIFIED_ID;
            $userStatusHistory->save();

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('admin.users.index')->with('error', trans('cruds.user.failed_verified'));
        }

        return redirect()->route('admin.users.index')->with('message', trans('cruds.user.success_verified'));
    }

    public function reject(Request $request, User $user)
    {
        abort_if(Gate::denies('user_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($user->id == \Auth::user()->id) {
            return redirect()->route('admin.users.index')->with('error', trans('global.forbidden'));
        }

        $request->validate([
            'reason' => 'required'
        ]);

        DB::beginTransaction();

        try {
            $user->status = User::REJECTED_ID;
            $user->save();

            $userStatusHistory = new UserStatusHistory;
            $userStatusHistory->user_id = $user->id;
            $userStatusHistory->reason = $request->reason ? $request->reason : '';
            $userStatusHistory->status = User::REJECTED_ID;
            $userStatusHistory->save();

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('admin.users.index')->with('error', trans('cruds.user.failed_reject'));
        }

        return redirect()->route('admin.users.index')->with('message', trans('cruds.user.success_reject'));
    }

    public function block(Request $request, User $user)
    {
        abort_if(Gate::denies('user_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($user->id == \Auth::user()->id) {
            return redirect()->route('admin.users.index')->with('error', trans('global.forbidden'));
        }

        $request->validate([
            'reason' => 'required'
        ]);

        DB::beginTransaction();

        try {
            $user->status = User::BLOCK_ID;
            $user->save();

            $userStatusHistory = new UserStatusHistory;
            $userStatusHistory->user_id = $user->id;
            $userStatusHistory->reason = $request->reason ? $request->reason : '';
            $userStatusHistory->status = User::BLOCK_ID;
            $userStatusHistory->save();

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('admin.users.index')->with('error', trans('cruds.user.failed_block'));
        }

        return redirect()->route('admin.users.index')->with('message', trans('cruds.user.success_block'));
    }

    public function activated(User $user)
    {
        abort_if(Gate::denies('user_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($user->id == \Auth::user()->id) {
            return redirect()->route('admin.users.index')->with('error', trans('global.forbidden'));
        }

        DB::beginTransaction();

        try {
            $user->status = User::VERIFIED_ID;
            $user->save();

            $userStatusHistory = new UserStatusHistory;
            $userStatusHistory->user_id = $user->id;
            $userStatusHistory->status = User::VERIFIED_ID;
            $userStatusHistory->save();

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('admin.users.index')->with('error', trans('cruds.user.failed_activated'));
        }

        return redirect()->route('admin.users.index')->with('message', trans('cruds.user.success_activated'));
    }

    public function show(User $user)
    {
        abort_if(Gate::denies('user_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $user->load('roles', 'userOrders', 'userStatusHistories');

        return view('admin.users.show', compact('user'));
    }

    public function retrieveMedia($mediaId, $fileName) 
    {
        abort_if(Gate::denies('user_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return Storage::download('private/' . $mediaId . '/' . $fileName);
    }

    public function retrieveMediaConversion($mediaId, $fileName) 
    {
        abort_if(Gate::denies('user_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return Storage::download('private/' . $mediaId . '/conversions//' . $fileName);
    }

    public function destroy(User $user)
    {
        abort_if(Gate::denies('user_delete') || $user->id == \Auth::user()->id, Response::HTTP_FORBIDDEN, '403 Forbidden');

        // soft delete dengan mengubah email dan student number
        $now = date('Y-m-d H:i:s');
        $user->email = '[Deleted] - ' . $user->email . ' - ' . $user->id;
        $user->student_number = '[Deleted] - ' . $user->student_number . ' - ' . $user->id;
        $user->deleted_at = $now;
        $user->save();

        return back()->with('message', trans('cruds.user.success_delete'));
    }

    public function massDestroy(MassDestroyUserRequest $request)
    {
        $users = User::whereIn('id', request('ids'))->get();

        $isFailed = false;
        $authUser = \Auth::user();
        foreach ($users as $user) {
            if ($user->id == $authUser->id) {
                $isFailed = true;
                break;
            }
        }

        if ($isFailed) {
            Session::flash('error', trans('cruds.user.failed_delete'));
        } else {
            // soft delete dengan mengubah email dan student number
            $now = date('Y-m-d H:i:s');
            User::whereIn('id', request('ids'))->update([
                'student_number' => DB::raw('concat("[Deleted] - ", student_number, " - ", id)'),
                'email' => DB::raw('concat("[Deleted] - ", email, " - ", id)'),
                'deleted_at' => $now
            ]);
            Session::flash('message', trans('cruds.user.success_delete'));
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function storeCKEditorImages(Request $request)
    {
        abort_if(Gate::denies('user_create') && Gate::denies('user_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $model         = new User();
        $model->id     = $request->input('crud_id', 0);
        $model->exists = true;
        $media         = $model->addMediaFromRequest('upload')->toMediaCollection('ck-media');

        return response()->json(['id' => $media->id, 'url' => $media->getUrl()], Response::HTTP_CREATED);
    }
}
