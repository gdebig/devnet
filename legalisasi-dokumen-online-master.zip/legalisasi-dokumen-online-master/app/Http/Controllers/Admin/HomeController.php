<?php

namespace App\Http\Controllers\Admin;

use App\Order;
use App\OrderItem;
use App\Http\Controllers\Controller;

use Gate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

class HomeController extends Controller
{
    const CHART_COLORS = [
        'rgba(255, 99, 132, 0.2)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)',
        'rgba(153, 102, 255, 0.2)',
        'rgba(255, 159, 64, 0.2)'
    ];

    const CHART_BORDER_COLORS = [
        'rgba(255, 99, 132)',
        'rgba(54, 162, 235)',
        'rgba(255, 206, 86)',
        'rgba(75, 192, 192)',
        'rgba(153, 102, 255)',
        'rgba(255, 159, 64)'
    ];

    public function index()
    {
        $alreadyPaidOrder = Order::where('status', Order::PAID_ID)->count();

        return view('admin.home', compact('alreadyPaidOrder'));
    }

    public function getTrenChartData(Request $request)
    {
        abort_if(Gate::denies('dashboard_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $query = OrderItem::selectRaw('count(*) as total, date(created_at) as label')
                ->groupBy('label');

        $startDate = null;
        if ($request->startDate) {
            $query = $query->where('created_at', '>=', $request->startDate . ' 00:00:00');
            $startDate = date_create_from_format('Y-m-d H:i:s', $request->startDate . ' 00:00:00');
        } else {
            $orderItem = OrderItem::selectRaw('min(date(created_at)) as min_date')->first();
            $startDate = date_create_from_format('Y-m-d H:i:s', $orderItem->min_date . ' 00:00:00');
        }

        $endDate = null;
        if ($request->endDate) {
            $query = $query->where('created_at', '<=', $request->endDate . ' 23:59:59');
            $endDate = date_create_from_format('Y-m-d H:i:s', $request->endDate . ' 00:00:00');
        } else {
            $orderItem = OrderItem::selectRaw('max(date(created_at)) as max_date')->first();
            $endDate = date_create_from_format('Y-m-d H:i:s', $orderItem->max_date . ' 00:00:00');
        }

        $orderItems = $query->get();

        $orderItemDatas = [];
        foreach ($orderItems as $orderItem) {
            $orderItemDatas[$orderItem->label] = $orderItem->total;
        }

        $datas = [
            'labels' => [],
            'totals' => []
        ];
        $index = 0;
        while ($startDate <= $endDate) {
            $dateStr = date_format($startDate, 'Y-m-d');
            $datas['labels'][$index] = $dateStr;
            if (array_key_exists($dateStr, $orderItemDatas)) {
                $datas['totals'][$index] = $orderItemDatas[$dateStr];
            } else {
                $datas['totals'][$index] = 0;
            }
            $startDate->add(new \DateInterval('P1D'));
            ++$index;
        }

        return response()->json($datas, 200);
    }

    public function getOrderByTypeData(Request $request)
    {
        abort_if(Gate::denies('dashboard_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $query = OrderItem::with(['document_type'])
                ->selectRaw('count(*) as total, document_type_id')
                ->groupBy('document_type_id');

        if ($request->startDate) {
            $query = $query->where('created_at', '>=', $request->startDate . ' 00:00:00');
        }

        if ($request->endDate) {
            $query = $query->where('created_at', '<=', $request->endDate . ' 23:59:59');
        }

        $orderItems = $query->get();

        $datas = [
            'labels' => [],
            'totals' => [],
            'colors' => [],
            'borders' => []
        ];

        $index = 0;
        $chartColorsSize = sizeof(HomeController::CHART_COLORS);
        foreach ($orderItems as $orderItem) {
            $datas['labels'][$index] = $orderItem->document_type->name;
            $datas['totals'][$index] = $orderItem->total;
            $datas['colors'][$index] = HomeController::CHART_COLORS[$index % $chartColorsSize];
            $datas['borders'][$index] = HomeController::CHART_BORDER_COLORS[$index % $chartColorsSize];
            ++$index;
        }

        return response()->json($datas, 200);
    }

    public function getSLAData(Request $request)
    {
        abort_if(Gate::denies('dashboard_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $query = OrderItem::with(['document_type'])
                ->selectRaw('count(*) as total, sum(amount) as total_amount, sum(total) as total_rev, document_type_id')
                ->whereHas('order', function ($query) {
                    $query->where('status', Order::FINISH_ID);
                })
                ->groupBy('document_type_id');

        if ($request->startDate) {
            $query = $query->where('created_at', '>=', $request->startDate . ' 00:00:00');
        }

        if ($request->endDate) {
            $query = $query->where('created_at', '<=', $request->endDate . ' 23:59:59');
        }

        $orderItems = $query->get();

        $datas = [
            'grand_total_order' => 0,
            'grand_total_exemplar' => 0,
            'grand_total_rev' => 0,
            'data' => []
        ];
        $index = 0;
        $grandTotalOrder = 0;
        $grandTotalExemplar = 0;
        $grandTotalRev = 0;
        foreach ($orderItems as $orderItem) {
            $sla = $this->getSLAMaxMinAvg($orderItem, $request->startDate, $request->endDate);
            
            $datas['data'][$index] = [
                'document_type' => $orderItem->document_type->name,
                'total' => $orderItem->total,
                'total_amount' => $orderItem->total_amount,
                'total_rev' => 'Rp ' . preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', (int) $orderItem->total_rev . ""),
                'max' => $sla['max'] . ' hari',
                'min' => $sla['min'] . ' hari',
                'avg' => $sla['avg'] . ' hari',
            ];
            $grandTotalOrder += $orderItem->total;
            $grandTotalExemplar += $orderItem->total_amount;
            $grandTotalRev += $orderItem->total_rev;
            ++$index;
        }

        $datas['grand_total_rev'] = 'Rp ' . preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', (int) $grandTotalRev . "");
        $datas['grand_total_exemplar'] = $grandTotalExemplar . ' eksemplar';
        $datas['grand_total_order'] = $grandTotalOrder . ' pesanan';

        return response()->json($datas, 200);
    }

    private function getSLAMaxMinAvg($orderItem, $startDate, $endDate)
    {
        $query = Order::selectRaw('hour(max(timediff(delivered_at, paid_at))) as max, hour(min(timediff(delivered_at, paid_at))) as min, avg(timediff(delivered_at, paid_at)) as avg')
                ->where('status', Order::FINISH_ID)
                ->whereHas('orderItems', function ($query) use ($orderItem) {
                    $query->where('document_type_id', $orderItem->document_type_id);
                });
        
        if ($startDate) {
            $query = $query->where('created_at', '>=', $startDate . ' 00:00:00');
        }

        if ($endDate) {
            $query = $query->where('created_at', '<=', $endDate . ' 23:59:59');
        }

        $order = $query->first();

        $sla = [
            'max' => ceil($order->max / 24),
            'min' => ceil($order->min / 24),
            'avg' => ceil($order->avg / (24 * 10000))
        ];

        return $sla;
    }
}
