<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyRoleRequest;
use App\Http\Requests\StoreRoleRequest;
use App\Http\Requests\UpdateRoleRequest;
use App\Permission;
use App\Role;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class RolesController extends Controller
{
    public function index(Request $request)
    {
        abort_if(Gate::denies('role_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = Role::with(['permissions'])->select(sprintf('%s.*', (new Role)->table));
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate      = 'role_show';
                $editGate      = 'role_edit';
                $deleteGate    = $row->id == 1 ? '' : 'role_delete';
                $crudRoutePart = 'roles';

                return view('partials.datatablesActions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->editColumn('title', function ($row) {
                return $row->title ? $row->title : "";
            });
            $table->editColumn('permissions', function ($row) {
                $labels = [];

                foreach ($row->permissions as $permission) {
                    $labels[] = sprintf('<span class="badge badge-info">%s</span>', $permission->name);
                }

                return implode(' ', $labels);
            });

            $table->rawColumns(['actions', 'placeholder', 'permissions']);

            return $table->make(true);
        }

        return view('admin.roles.index');
    }

    public function create()
    {
        abort_if(Gate::denies('role_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $permissions = Permission::all()->pluck('name', 'id');

        return view('admin.roles.create', compact('permissions'));
    }

    public function store(StoreRoleRequest $request)
    {
        $role = Role::create($request->all());
        $role->permissions()->sync($request->input('permissions', []));

        return redirect()->route('admin.roles.index')->with('message', trans('cruds.role.success_create'));
    }

    public function edit(Role $role)
    {
        abort_if(Gate::denies('role_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $permissions = Permission::all()->pluck('name', 'id');

        $role->load('permissions');

        return view('admin.roles.edit', compact('permissions', 'role'));
    }

    public function update(UpdateRoleRequest $request, Role $role)
    {
        $role->update($request->all());
        $role->permissions()->sync($request->input('permissions', []));

        return redirect()->route('admin.roles.index')->with('message', trans('cruds.role.success_edit'));
    }

    public function show(Role $role)
    {
        abort_if(Gate::denies('role_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $role->load('permissions');

        return view('admin.roles.show', compact('role'));
    }

    public function destroy(Role $role)
    {
        abort_if(Gate::denies('role_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $users = $role->users;
        if ($users && sizeof($users) > 0) {
            return back()->with('error', trans('cruds.role.failed_delete'));    
        }

        // soft delete dengan mengubah title
        $now = date('Y-m-d H:i:s');
        $role->delete();
        $role->title = '[Deleted] - ' . $role->title . ' - ' . $role->id;
        $role->deleted_at = $now;
        $role->save();

        return back()->with('message', trans('cruds.role.success_delete'));
    }

    public function massDestroy(MassDestroyRoleRequest $request)
    {
        $roles = Role::whereIn('id', request('ids'))->get();

        $isFailed = false;
        foreach ($roles as $role) {
            $users = $role->users;
            if ($users && sizeof($users) > 0) {
                $isFailed = true;
                break;
            }
        }

        if ($isFailed) {
            Session::flash('error', trans('cruds.role.failed_delete'));
        } else {
            // soft delete dengan mengubah title
            $now = date('Y-m-d H:i:s');
            Role::whereIn('id', request('ids'))->update([
                'title' => DB::raw('concat("[Deleted] - ", title, " - ", id)'),
                'deleted_at' => $now
            ]);
            Session::flash('message', trans('cruds.role.success_delete'));
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
