<?php

namespace App\Http\Controllers\Admin;

use App\DocumentType;
use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyDocumentTypeRequest;
use App\Http\Requests\StoreDocumentTypeRequest;
use App\Http\Requests\UpdateDocumentTypeRequest;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class DocumentTypesController extends Controller
{
    public function index(Request $request)
    {
        abort_if(Gate::denies('document_type_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = DocumentType::query()->select(sprintf('%s.*', (new DocumentType)->table));
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate      = 'document_type_show';
                $editGate      = 'document_type_edit';
                $deleteGate    = 'document_type_delete';
                $crudRoutePart = 'document-types';

                return view('partials.datatablesActions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->editColumn('name', function ($row) {
                return $row->name ? $row->name : '';
            });
            
            $table->editColumn('price', function ($row) {
                return $row->price ? preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', (int) $row->price . "") : '';
            });

            $table->editColumn('weight', function ($row) {
                return $row->weight ? preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', $row->weight . "") : '';
            });

            $table->editColumn('is_for_student', function ($row) {
                return $row->is_for_student ? 'Ya' : 'Tidak';
            });

            $table->editColumn('is_for_alumni', function ($row) {
                return $row->is_for_alumni ? 'Ya' : 'Tidak';
            });

            $table->rawColumns(['actions', 'placeholder']);

            return $table->make(true);
        }

        return view('admin.documentTypes.index');
    }

    public function create()
    {
        abort_if(Gate::denies('document_type_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.documentTypes.create');
    }

    public function store(StoreDocumentTypeRequest $request)
    {
        $input = $request->all();
        array_key_exists('is_for_student', $input) ? $input['is_for_student'] = 1 : $input['is_for_student'] = 0;
        array_key_exists('is_for_alumni', $input) ? $input['is_for_alumni'] = 1 : $input['is_for_alumni'] = 0;
        $documentType = DocumentType::create($input);

        return redirect()->route('admin.document-types.index')->with('message', trans('cruds.documentType.success_create'));
    }

    public function edit(DocumentType $documentType)
    {
        abort_if(Gate::denies('document_type_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.documentTypes.edit', compact('documentType'));
    }

    public function update(UpdateDocumentTypeRequest $request, DocumentType $documentType)
    {
        $input = $request->all();
        array_key_exists('is_for_student', $input) ? $input['is_for_student'] = 1 : $input = array_merge($input, ['is_for_student' => 0]);
        array_key_exists('is_for_alumni', $input) ? $input['is_for_alumni'] = 1 : $input = array_merge($input, ['is_for_alumni' => 0]);
        $documentType->update($input);

        return redirect()->route('admin.document-types.index')->with('message', trans('cruds.documentType.success_edit'));
    }

    public function show(DocumentType $documentType)
    {
        abort_if(Gate::denies('document_type_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.documentTypes.show', compact('documentType'));
    }

    public function destroy(DocumentType $documentType)
    {
        abort_if(Gate::denies('document_type_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        
        $orderItems = $documentType->orderItems;
        if ($orderItems && sizeof($orderItems) > 0) {
            return back()->with('error', trans('cruds.documentType.failed_delete'));    
        }

        // soft delete dengan mengubah name
        $now = date('Y-m-d H:i:s');
        $documentType->delete();
        $documentType->name = '[Deleted] - ' . $documentType->name . ' - ' . $documentType->id;
        $documentType->deleted_at = $now;
        $documentType->save();

        return back()->with('message', trans('cruds.documentType.success_delete'));
    }

    public function massDestroy(MassDestroyDocumentTypeRequest $request)
    {
        $documentTypes = DocumentType::whereIn('id', request('ids'))->get();

        $isFailed = false;
        foreach ($documentTypes as $documentType) {
            $orderItems = $documentType->orderItems;
            if ($orderItems && sizeof($orderItems) > 0) {
                $isFailed = true;
                break;
            }
        }

        if ($isFailed) {
            Session::flash('error', trans('cruds.documentType.failed_delete'));
        } else {
            // soft delete dengan mengubah name
            $now = date('Y-m-d H:i:s');
            DocumentType::whereIn('id', request('ids'))->update([
                'name' => DB::raw('concat("[Deleted] - ", name, " - ", id)'),
                'deleted_at' => $now
            ]);
            Session::flash('message', trans('cruds.documentType.success_delete'));
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
