<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\ShippingCostTrait;
use App\Http\Requests\UpdateOrderStatusRequest;
use App\Order;
use App\OrderStatusHistory;
use Gate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

use App\Notifications\UpdateOrderStatus;

class OrdersController extends Controller
{
    use ShippingCostTrait;

    public function index(Request $request)
    {
        abort_if(Gate::denies('order_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $startDate = $request->startDate;
            $endDate = $request->endDate;
            $status = $request->status;
            $paymentType = $request->paymentType;
            $courier = $request->courier;

            $query = Order::with(['user', 'orderItems.document_type'])->select(sprintf('%s.*', (new Order)->table));

            if ($startDate) {
                $query->where('created_at', '>=', $startDate . ' 00:00:00');
            }
            
            if ($endDate) {
                $query->where('created_at', '<=', $endDate . ' 23:59:59');
            }

            if ($status) {
                $query->where('status', $status);
            }

            if ($paymentType) {
                $query->where('payment_type', $paymentType);
            }

            if ($courier) {
                $query->where('courier', $courier);
            }

            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->addColumn('document_types', '');

            $table->editColumn('total', function ($row) {
                return preg_replace('/\B(?=(\d{3})+(?!\d))/', '.', (int) $row->total . "");
            });

            $table->addColumn('amount', function ($row) {
                $amount = 0;
                foreach ($row->orderItems as $orderItem) {
                    $amount += $orderItem->amount;
                }

                return $amount;
            });

            $table->editColumn('actions', function ($row) {
                $viewGate      = 'order_show';
                $editGate      = '';
                $deleteGate    = '';
                $crudRoutePart = 'orders';

                $selectableStatus = $this->getSelectableNextStatus($row);
                $statusAction = view('admin.orders.partials.statusAction', compact('row', 'selectableStatus'));

                return view('partials.datatablesActions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                )) . $statusAction;
            });

            $table->editColumn('order_number', function ($row) {
                return $row->order_number ? $row->order_number : '';
            });
            $table->editColumn('document_types', function ($row) {
                $documentTypes = '';
                foreach ($row->orderItems as $item) {
                    if ($item->document_type) {
                        $documentTypes .= '<span class="badge badge-info">' . $item->document_type->name . '</span>&nbsp;';
                    } else {
                        $documentTypes .= '<span class="badge badge-danger">Deleted</span>&nbsp;';
                    }
                }
                return $documentTypes;
            });
            $table->editColumn('shipping_type', function ($row) {
                return $row->shipping_type ? Order::SHIPPING_TYPE_SELECT[$row->shipping_type] : '';
            });
            $table->editColumn('destination_type', function ($row) {
                return $row->destination_type ? Order::DESTINATION_TYPE_SELECT[$row->destination_type] : '';
            });
            $table->editColumn('courier', function ($row) {
                return Order::COURIER_SELECT[$row->courier] ?? '';
            });
            $table->editColumn('payment_type', function ($row) {
                return Order::PAYMENT_TYPE_SELECT[$row->payment_type] ?? '';
            });
            $table->editColumn('status', function ($row) {
                return $row->status ? Order::STATUS_SELECT[$row->status] : '';
            });

            $table->rawColumns(['actions', 'placeholder', 'document_types']);

            return $table->make(true);
        }

        $alreadyPaidOrder = Order::where('status', Order::PAID_ID)->count();

        return view('admin.orders.index', compact('alreadyPaidOrder'));
    }

    public function getAlreadyPaidCount()
    {
        $alreadyPaidOrder = Order::where('status', Order::PAID_ID)->count();
        return response()->json(['count' => $alreadyPaidOrder], 200);
    }

    private function getSelectableNextStatus($order)
    {
        $currentStatus = $order->status;
        $selectableStatus = [];

        if ($currentStatus == Order::PAID_ID) {
            $selectableStatus = [
                Order::PROCESSED_ID => Order::STATUS_SELECT[Order::PROCESSED_ID]
            ];
        } else if ($currentStatus == Order::PROCESSED_ID && $order->shipping_type == Order::DELIVERY_ID) {
            $selectableStatus = [
                Order::ON_DELIVERY_ID => Order::STATUS_SELECT[Order::ON_DELIVERY_ID]
            ];
        } else if ($currentStatus == Order::PROCESSED_ID && $order->shipping_type == Order::PICKUP_ID) {
            $selectableStatus = [
                Order::READY_TO_PICKUP_ID => Order::STATUS_SELECT[Order::READY_TO_PICKUP_ID]
            ];
        } else if ($currentStatus == Order::ON_DELIVERY_ID || $currentStatus == Order::READY_TO_PICKUP_ID) {
            $selectableStatus = [
                Order::FINISH_ID => Order::STATUS_SELECT[Order::FINISH_ID],
                Order::ORDER_PROBLEM_ID => Order::STATUS_SELECT[Order::ORDER_PROBLEM_ID]
            ];
        } else if ($currentStatus == Order::ORDER_PROBLEM_ID) {
            $selectableStatus = [
                Order::FINISH_ID => Order::STATUS_SELECT[Order::FINISH_ID]
            ];
        }

        return $selectableStatus;
    }

    public function updateStatus(UpdateOrderStatusRequest $request, Order $order)
    {
        if (!$this->newStatus($order, $request->status, $request->reason, $request->receipt_number)) {
            return redirect()->route('admin.orders.index')->with('error', trans('cruds.order.failed_update_status'));
        }

        return redirect()->route('admin.orders.index')->with('message', trans('cruds.order.success_update_status'));
    }

    public function undoStatus(Order $order) 
    {
        abort_if(Gate::denies('order_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $prevOrderStatusHistories = OrderStatusHistory::where('order_id', $order->id)->orderBy('created_at', 'desc')->limit(2)->get();
        if ($prevOrderStatusHistories->count() < 2) {
            return redirect()->route('admin.orders.index')->with('error', trans('cruds.order.failed_update_status'));
        }

        $prevStatus = $prevOrderStatusHistories->last()->status;

        if (!$this->newStatus($order, $prevStatus, 'Undo', '', true)) {
            return redirect()->route('admin.orders.index')->with('error', trans('cruds.order.failed_update_status'));
        }

        return redirect()->route('admin.orders.index')->with('message', trans('cruds.order.success_update_status'));
    }

    private function newStatus($order, $nextStatus, $reason, $receiptNumber, $isUndo = false)
    {
        DB::beginTransaction();

        try {
            $order->status = $nextStatus;

            // Terdapat kemajuan status
            if (!$isUndo) {
                $now = date('Y-m-d h:i:s');
                if ($nextStatus == Order::PAID_ID) {
                    $order->paid_at = $now;
                } else if ($nextStatus == Order::PROCESSED_ID) {
                    $order->processed_at = $now;
                } else if ($nextStatus == Order::ON_DELIVERY_ID || $nextStatus == Order::READY_TO_PICKUP_ID) {
                    $order->receipt_number = $receiptNumber ? $receiptNumber : '';
                    $order->delivered_at = $now;
                } else if ($nextStatus == Order::FINISH_ID) {
                    $order->finished_at = $now;
                }
            } else { // Undo
                if ($nextStatus == Order::PAID_ID) {
                    $order->processed_at = null;
                } else if ($nextStatus == Order::PROCESSED_ID) {
                    $order->receipt_number = '';
                    $order->delivered_at = null;
                } else if ($nextStatus == Order::ON_DELIVERY_ID || $nextStatus == Order::READY_TO_PICKUP_ID) {
                    $order->finished_at = null;
                }
            }

            $order->save();

            $orderStatusHistory = new OrderStatusHistory;
            $orderStatusHistory->order_id = $order->id;
            $orderStatusHistory->reason = $reason ? $reason : '';
            $orderStatusHistory->status = $nextStatus;
            $orderStatusHistory->updated_by = \Auth::user()->id;
            $orderStatusHistory->save();

            $order->user->notify(new UpdateOrderStatus($order, $reason));

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return false;
        }

        return true;
    }

    public function show(Order $order)
    {
        abort_if(Gate::denies('order_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $selectableStatus = $this->getSelectableNextStatus($order);

        $order->load('user', 'orderItems', 'orderStatusHistories');

        return view('admin.orders.show', compact('order', 'selectableStatus'));
    }

    public function print(Order $order)
    {
        abort_if(Gate::denies('order_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        
        $countryName = $this->getOneCountry($order->country_id);
        $provinceName = $this->getOneProvince($order->province_id);
        $cityName = $this->getOneCity($order->province_id, $order->city_id);
        $districtName = $this->getOneDistrict($order->city_id, $order->district_id);

        $address = $order->shipping_address;
        if ($order->subdistrict) {
            $address .= (', Kelurahan ' . $order->subdistrict);
        }
        if ($districtName) {
            $address .= (', Kecamatan ' . $districtName);
        }
        if ($cityName) {
            $address .= (', Kota / Kabupaten ' . $cityName);
        }
        if ($countryName) {
            $address .= (', ' . $countryName);
        }
        if ($order->postal_code) {
            $address .= (' ' . $order->postal_code);
        }

        return view('admin.orders.print', compact('order', 'address'));
    }
}
