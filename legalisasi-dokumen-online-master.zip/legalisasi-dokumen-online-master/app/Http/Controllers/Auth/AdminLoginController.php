<?php

namespace App\Http\Controllers\Auth;

use App\User;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class AdminLoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::ADMIN_HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function showLoginForm()
    {
        return view('auth.adminLogin');
    }

    protected function attemptLogin(Request $request)
    {
        if (!$this->isUserAllowed(User::where('email', $request->email)->first())) {
            return false;
        }

        $request->merge(['is_admin' => true]);

        return $this->guard()->attempt(
            $this->credentials($request), $request->filled('remember')
        );
    }

    private function isUserAllowed($user)
    {
        if ($user && $user->is_admin && $user->status == User::VERIFIED_ID) {
            return true;
        }

        return false;
    }

    protected function credentials(Request $request)
    {
        return $request->only($this->username(), 'password', 'is_admin');
    }

    public function logout(Request $request)
    {
        $this->guard()->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        if ($response = $this->loggedOut($request)) {
            return $response;
        }

        return $request->wantsJson()
            ? new Response('', 204)
            : redirect('/ldo-admin/login');
    }
}
