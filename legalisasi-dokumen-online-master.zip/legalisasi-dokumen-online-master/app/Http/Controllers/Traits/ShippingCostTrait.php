<?php

namespace App\Http\Controllers\Traits;

use Illuminate\Http\Request;

use App\Order;

trait ShippingCostTrait
{
    private function rajaOngkirRequest($endpoint, $method, $params = [], $result = 'results')
    {
        $SERVICE_URL = 'https://pro.rajaongkir.com/api';
        $API_KEY = env('COURIER_APIKEY') ?? '';

        $curl = curl_init();

        $queryParam = '';
        $postParam = '';
        if($method == 'GET') {
            $queryParam = '?'.http_build_query($params);
        } elseif($method == 'POST') {
            $postParam = http_build_query($params);
        }
        curl_setopt_array($curl, array(
            CURLOPT_URL => $SERVICE_URL.$endpoint.$queryParam,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => array(
                "key: ".$API_KEY
            ),
            CURLOPT_POSTFIELDS => $postParam
        ));
        if($proxy = env('CURL_PROXY')) curl_setopt($curl, CURLOPT_PROXY, $proxy);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);
        
        if ($err) {
            return null;
        } else {
            // dd($response);
            $res = json_decode($response);
            return $res->rajaongkir->$result ?? null;
        }
    }

    public function getCountry(Request $request)
    {
        $params = ['id' => $request->country_id];
        $res = $this->rajaOngkirRequest('/internationalDestination', 'GET', $params);
        if($res) {
            return response()->json(['data' => $res]);
        };
        return response()->json(['message' => 'Error'], 400);
    }

    public function getOneCountry($id)
    {
        $params = ['id' => $id];
        $res = $this->rajaOngkirRequest('/internationalDestination', 'GET', $params);
        if($res) {
            return $res->country_name ?? '';
        };
        return '';
    }

    public function getProvince(Request $request)
    {
        $params = ['id' => $request->province_id];
        $res = $this->rajaOngkirRequest('/province', 'GET', $params);
        if($res) {
            return response()->json(['data' => $res]);
        };
        return response()->json(['message' => 'Error'], 400);
    }

    public function getOneProvince($id)
    {
        $params = ['id' => $id];
        $res = $this->rajaOngkirRequest('/province', 'GET', $params);
        if($res) {
            return $res->province_name ?? '';
        };
        return '';
    }

    public function getCity(Request $request)
    {
        if(!$request->province_id) {
            return response()->json(['data' => []]);
        }
        $params = ['province' => $request->province_id, 'id' => $request->city_id];
        $res = $this->rajaOngkirRequest('/city', 'GET', $params);
        if($res) {
            return response()->json(['data' => $res]);
        };
        return response()->json(['message' => 'Error'], 400);
    }

    public function getOneCity($provinceId, $cityId)
    {
        $params = ['province' => $provinceId, 'id' => $cityId];
        $res = $this->rajaOngkirRequest('/city', 'GET', $params);
        if($res) {
            return $res->city_name ?? '';
        };
        return '';
    }

    public function getDistrict(Request $request)
    {
        if(!$request->city_id) {
            return response()->json(['data' => []]);
        }
        $params = ['city' => $request->city_id, 'id' => $request->district_id];
        $res = $this->rajaOngkirRequest('/subdistrict', 'GET', $params);
        if($res) {
            return response()->json(['data' => $res]);
        };
        return response()->json(['message' => 'Error'], 400);
    }

    public function getOneDistrict($cityId, $districtId)
    {
        $params = ['city' => $cityId];
        $res = $this->rajaOngkirRequest('/subdistrict', 'GET', $params);
        if($res) {
            foreach ($res as $data) {
                if ($data->subdistrict_id == $districtId) {
                    return $data->subdistrict_name;
                }
            }
        };
        return '';
    }

    public function getLocalCourier(Request $request)
    {
        $originCityID = 115;
        $couriers = Order::COURIER_SELECT;

        if(!$request->district_id) {
            return response()->json(['data' => []]);
        }
        
        $params = [];
        $datas = [];
        foreach($couriers as $key => $courier) {
            $params = [
                'origin' => $originCityID, 
                'originType' => 'city',
                'destination' => $request->district_id, 
                'destinationType' => 'subdistrict',
                'weight' => $request->weight, 
                'courier' => strtolower($courier)
            ];
            $endpoint = '/cost';
            $res = $this->rajaOngkirRequest($endpoint, 'POST', $params);
            if( $res && isset($res[0]) ) {
                foreach($res[0]->costs as $cost)
                {
                    foreach($cost->cost as $costDetail) {
                        $datas[] = [
                            'id' => $key,
                            'code' => $res[0]->code,
                            'service' => $cost->service,
                            'text' => $courier.' - '.$cost->service.' - '.formatRupiah($costDetail->value).' ('.$costDetail->etd.' Hari)',
                            'price' => $costDetail->value
                        ];
                    }
                }
            }
        }

        return response()->json(['data' => $datas]);
    }

    public function getIntlCourier(Request $request)
    {
        $originCityID = 115;
        $couriers = Order::COURIER_SELECT;

        if(!$request->country_id) {
            return response()->json(['data' => []]);
        }
        
        $params = [];
        $datas = [];
        foreach($couriers as $key => $courier) {
            $params = [
                'origin' => $originCityID, 
                'destination' => $request->country_id, 
                'weight' => $request->weight, 
                'courier' => strtolower($courier)
            ];
            $endpoint = '/v2/internationalCost';
            $res = $this->rajaOngkirRequest($endpoint, 'POST', $params);
            if( $res && isset($res[0]) ) {
                // dd($res);
                foreach($res[0]->costs as $cost)
                {
                    $idrCost = $cost->currency === 'IDR' ? $cost->cost : intval($this->getIdrCost($cost->cost));
                    $datas[] = [
                        'id' => $key,
                        'code' => $res[0]->code,
                        'service' => $cost->service,
                        'text' => $courier.' - '.$cost->service.' - '. formatRupiah($idrCost).' ('.$cost->etd.' Hari)',
                        'price' => $idrCost
                    ];
                }
            }
        }

        return response()->json(['data' => $datas]);
    }

    private function getIdrCost($cost)
    {
        $res = $this->rajaOngkirRequest('/currency', 'GET', [], 'result');
        if($res) {
            return $res->value * $cost;
        };
        return null;
    }
}
