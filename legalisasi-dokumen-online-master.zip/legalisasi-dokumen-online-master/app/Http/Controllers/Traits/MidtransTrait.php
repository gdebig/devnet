<?php

namespace App\Http\Controllers\Traits;

use Illuminate\Http\Request;
// use \App\Http\Helpers\Midtrans;
// use Midtrans;
use \App\OrderStatusHistory;

use App\Notifications\UpdateOrderStatus;

trait MidtransTrait
{
    private function checkSignature($signArray)
    {
        return hash('sha512', implode('', $signArray));
    }

    private function updateOrderStatusHistories($order, $reason, $nextStatus, $updatedBy = null)
    {
        $orderStatusHistory = new OrderStatusHistory;
        $orderStatusHistory->order_id = $order->id;
        $orderStatusHistory->reason = $reason ? $reason : '';
        $orderStatusHistory->status = $nextStatus;
        $orderStatusHistory->updated_by = $updatedBy;
        $orderStatusHistory->save();

        $order->user->notify(new UpdateOrderStatus($order));
    }

    private function prepareMidtransPayment($order)
    {
        $SNAP_SANDBOX_BASE_URL = 'https://app.sandbox.midtrans.com/snap/v1';
        $SNAP_PRODUCTION_BASE_URL = 'https://app.midtrans.com/snap/v1';
        $ch = curl_init();
        $midtransURL = env('MIDTRANS_STATE') === 'production' ? $SNAP_SANDBOX_BASE_URL : $SNAP_SANDBOX_BASE_URL;

        // // Set your Merchant Server Key
        // \Midtrans\Config::$serverKey = env('MIDTRANS_KEY');
        // // Set to Development/Sandbox Environment (default). Set to true for Production Environment (accept real transaction).
        // \Midtrans\Config::$isProduction = env('MIDTRANS_STATE') === 'production' ? true : false;
        // // Set sanitization on (default)
        // \Midtrans\Config::$isSanitized = true;
        // // Set 3DS transaction for credit card to true
        // \Midtrans\Config::$is3ds = true;
        $params = array(
            'transaction_details' => array(
                'order_id' => rand().'|'.$order->order_number,
                'gross_amount' => (int) $order->total,
            ),
            'customer_details' => array(
                'first_name' => $order->user->name,
                'last_name' => '',
                'email' => $order->user->email ?? '',
                'phone' => $order->user->phone_number ?? '',
            ),
            'callbacks' =>  array(
                "finish" => route('user.order.payment', ['id' => $order->order_number])
            )
        );

        curl_setopt($ch, CURLOPT_URL, $midtransURL . '/transactions');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
        curl_setopt($ch, CURLOPT_USERPWD, env('MIDTRANS_KEY') . ":");  
        if($proxy = env('CURL_PROXY')) curl_setopt($ch, CURLOPT_PROXY, $proxy);

        $headers = array();
        $headers[] = 'Accept: application/json';
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return '';
            // echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
        if($result) {
            return json_decode($result)->token ?? '';
        }

        // try {
        //     $snapToken = \Midtrans\Snap::getSnapToken($params);
        //     return $snapToken;
        //     // return ['code' => 1 , 'message' => 'success' , 'result' => $snapToken];
        // } catch (\Exception $e) {
        //     return '';
        // }
    }
}
?>