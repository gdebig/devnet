<?php

namespace App\Http\Helpers;

use phpCAS;
use Illuminate\Support\Facades\Storage;

// ------------------------------------------------------------------------
//  Constants
// ------------------------------------------------------------------------

/**
 * CAS server host address
 */
define('CAS_SERVER_HOST', 'sso.ui.ac.id');

/**
 * CAS server uri
 */
define('CAS_SERVER_URI', '/cas2');

/**
 * CAS server port
 */
define('CAS_SERVER_PORT', 443);

// ------------------------------------------------------------------------
//  CAS Initialization
// ------------------------------------------------------------------------

// ONLY DO THIS IF phpCAS EXISTS (i.e. installing via Composer). Thanks to Fariskhi for noticing the bug.
if (class_exists('phpCAS')) {
  /**
   * Create phpCAS client
   */
  phpCAS::client(CAS_VERSION_2_0, CAS_SERVER_HOST, CAS_SERVER_PORT, CAS_SERVER_URI);

  /**
   * Set no validation.
   */
  phpCAS::setNoCasServerValidation();
}

/**
 * The SSO class is a simple phpCAS interface for authenticating using
 * SSO-UI CAS service.
 *
 * @class     SSO
 * @category  Authentication
 * @package   SSO 
 * @author    Bobby Priambodo <bobby.priambodo@gmail.com>
 * @license   MIT
 */
class SSO
{

  /**
   * Authenticate the user.
   *
   * @return bool Authentication
   */
  public static function authenticate() {
    return phpCAS::forceAuthentication();
  }

  /**
   * Check if the user is already authenticated.
   *
   * @return bool Authentication
   */
  public static function check() {
    return phpCAS::checkAuthentication();
  }

  /**
   * Logout from SSO with URL redirection options
   */
  public static function logout($url='') {
    if ($url === '')
      phpCAS::logout();
    else
      phpCAS::logout(['url' => $url]);
  }

  /**
   * Returns the authenticated user.
   *
   * @return Object User
   */
  public static function getUser() {
    $details = phpCAS::getAttributes();

    // Create new user object, initially empty.
    $user = new \stdClass();
    $user->username = phpCAS::getUser();

    $user->name = array_key_exists('nama', $details) ? $details['nama'] : null;
    $user->role = array_key_exists('peran_user', $details) ? $details['peran_user'] : null;

    if ($user->role === 'mahasiswa') {
      $user->npm = $details['npm'];
      $user->org_code = $details['kd_org'];

      $path = 'additional-info.json';
      $orgData = json_decode(Storage::disk('sso')->get($path), true);
      
      if (!array_key_exists($user->org_code, $orgData)) {
        return null;
      }
      $data = $orgData[$user->org_code];

      $user->faculty = $data['faculty'];
      $user->study_program = $data['study_program'];
      $user->educational_program = $data['educational_program'];
      $user->fullname = $data['fullname'];
    }
    else if ($user->role === 'staff') {
      $user->nip = $details['nip'];
    }

    return $user;
  }

}