<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use \DateTimeInterface;

class OrderStatusHistory extends Model
{
    public $table = 'order_status_histories';

    protected $dates = [
        'created_at',
        'updated_at',

    ];

    protected $fillable = [
        'order_id',
        'status',
        'reason',
        'created_at',
        'updated_at',
        'updated_by',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}
