<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use \DateTimeInterface;

use Auth;

class DocumentType extends Model
{
    use SoftDeletes;

    public $table = 'document_types';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'name',
        'price',
        'weight',
        'is_for_student',
        'is_for_alumni',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function scopeFilterUser($query)
    {
        $user = Auth::user();
        if($user->is_student) {
            return $query->where('is_for_student', 1);
        }
        elseif($user->is_alumni) {
            return $query->where('is_for_alumni', 1);
        }
        return $query;
    }
}
